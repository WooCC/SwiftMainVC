//
//  YiNuoTitleWithDescOrArrowButton.swift
//  yinuo
//
//  Created by Rayco on 2018/2/7.
//  Copyright © 2018年 yinuo. All rights reserved.
//  左侧标题，右侧为小标题或箭头的自定义view

import UIKit

class YiNuoTitleWithDescOrArrowButton: UIView {
    
    var leftInset: CGFloat = 15    // 左边距
    var rightInset: CGFloat = 15   // 右边距
    var viewHeight: CGFloat = 50  // 组件高度

    private lazy var photoImageView: UIImageView = {
        let photoImageView = UIImageView()
        photoImageView.layer.cornerRadius = 30
        photoImageView.layer.masksToBounds = true
        return photoImageView
    }()
    
    private lazy var titleLabel = { () -> UILabel in
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16.0)
        label.textColor = UIColor.black
        label.textAlignment = .center
        return label
    }()
    
    private lazy var descLabel = { () -> UILabel in
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16.0)
        label.textColor = UIColor.lightGray
        label.textAlignment = .center
        return label
    }()
    
    private lazy var arrowImageView = { () -> UIImageView in
        let imageView = UIImageView()
        imageView.image = UIImage(named: "arrow")
        return imageView
    }()
    
    private lazy var touchButton = { () -> UIButton in
        let button = UIButton(type: .custom)
        return button
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        //2 初始化视图
        self.frame.size.height = viewHeight
        
        setUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setUI() {
        self.backgroundColor = UIColor.white
        
        self.addSubview(touchButton)
        self.addSubview(titleLabel)
        self.addSubview(descLabel)
        self.addSubview(photoImageView)
        self.addSubview(arrowImageView)
        self.showArrow(show: false)
        self.showPhoto(show: false)
        
        touchButton.snp.makeConstraints { (make) in
            make.width.equalToSuperview()
            make.height.equalTo(viewHeight)
            make.left.right.equalTo(0)
            make.top.bottom.equalTo(0)
        }
        titleLabel.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.left.equalTo(leftInset)
            make.height.equalTo(viewHeight)
        }
        arrowImageView.snp.makeConstraints { (make) in
            make.width.equalTo(8.5)
            make.height.equalTo(14)
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().offset(-rightInset)
        }
        photoImageView.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.width.height.equalTo(60)
            make.right.equalTo(arrowImageView.snp.left).offset(-rightInset / 2)
        }
        descLabel.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.height.equalTo(viewHeight)
            make.right.equalTo(arrowImageView.snp.left).offset(-rightInset / 2)
        }
    }
    
    //3 增加设置图片方法
    func setTitle(title: String?) {
        titleLabel.text = title
    }
    
    func setDesc(desc: String?) {
        descLabel.text = desc;
    }
    
    func getDesc() -> String {
        return descLabel.text!
    }
    
    func setDesc(desc: String?, textColor: UIColor?) {
        descLabel.text = desc;
        descLabel.textColor = textColor
    }
    
    func setImage(image: UIImage?) {
        photoImageView.image = image
    }
    
    func showArrow(show: Bool) {
        arrowImageView.isHidden = !show
        
//        arrowImageView.snp.makeConstraints { (make) in
//            make.right.equalToSuperview().offset(show ? -rightInset : rightInset)
//        }
        descLabel.snp.makeConstraints { (make) in
            if show {
                make.right.equalTo(arrowImageView.snp.left).offset(-rightInset / 2)
            } else {
                 make.right.equalTo(arrowImageView.snp.right).offset(0)
            }
        }
    }
    
    func showPhoto(show: Bool) {
        photoImageView.isHidden = !show
    }
    
    func setViewHight(height : CGFloat) {
        self.frame.size.height = viewHeight
    }
    
    func setPhotoImageViewSize(size : CGSize) {
        photoImageView.layer.cornerRadius = size.width / 2
        photoImageView.snp.makeConstraints { (make) in
            make.width.height.equalTo(size.width / 2)
        }
    }

    open func addTarget(_ target: Any?, action: Selector, for controlEvents: UIControlEvents) {
        touchButton.addTarget(target, action:action, for:controlEvents)
    }
}
