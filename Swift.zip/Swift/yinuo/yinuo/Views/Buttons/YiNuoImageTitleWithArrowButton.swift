//
//  YiNuoImageTitleWithArrowButton.swift
//  yinuo
//
//  Created by Rayco on 2018/2/7.
//  Copyright © 2018年 yinuo. All rights reserved.
//  左侧头像+标题，右侧为箭头的自定义view

import UIKit

class YiNuoImageTitleWithArrowButton: UIView {
    
    var leftInset: CGFloat = 15    // 左边距
    var rightInset: CGFloat = 15   // 右边距
    var viewHeight: CGFloat = 80  // 组件高度

    private lazy var photoImageView: UIImageView = {
        let photoImageView = UIImageView()
        photoImageView.layer.cornerRadius = 30
        photoImageView.layer.masksToBounds = true
        return photoImageView
    }()
    
    private lazy var titleLabel = { () -> UILabel in
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16.0)
        label.textColor = UIColor.black
        label.textAlignment = .center
        return label
    }()
    
    private lazy var arrowImageView = { () -> UIImageView in
        let imageView = UIImageView()
        imageView.image = UIImage(named: "arrow")
        return imageView
    }()
    
    private lazy var touchButton = { () -> UIButton in
        let button = UIButton(type: .custom)
        return button
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        //2 初始化视图
        self.frame.size.height = viewHeight
        
        setUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setUI() {
        self.backgroundColor = UIColor.white
        
        self.addSubview(touchButton)
        self.addSubview(photoImageView)
        self.addSubview(titleLabel)
        self.addSubview(arrowImageView)
    
        touchButton.snp.makeConstraints { (make) in
            make.width.equalToSuperview()
            make.height.equalTo(viewHeight)
            make.left.right.equalTo(0)
            make.top.bottom.equalTo(0)
        }
        photoImageView.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.left.equalTo(leftInset)
            make.width.height.equalTo(60)
        }
        titleLabel.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.left.equalTo(photoImageView.snp.right).offset(leftInset)
            make.height.equalTo(viewHeight)
        }
        arrowImageView.snp.makeConstraints { (make) in
            make.width.equalTo(8.5)
            make.height.equalTo(14)
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().offset(-rightInset)
        }
    }
    
    //3 增加设置图片方法
    func setTitle(title: String?) {
        titleLabel.text = title
    }
    
    func setImage(image: UIImage?) {
        photoImageView.image = image
    }

    open func addTarget(_ target: Any?, action: Selector, for controlEvents: UIControlEvents) {
        touchButton.addTarget(target, action:action, for:controlEvents)
    }
}
