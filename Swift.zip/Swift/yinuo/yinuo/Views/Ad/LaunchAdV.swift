//
//  LaunchAdV.swift
//  yinuo
//
//  Created by tim on 2018/3/16.
//  Copyright © 2018年 yinuo. All rights reserved.
//  启动广告

import UIKit
import RxSwift
import ObjectMapper
import Kingfisher

class LaunchAdV: UIView {

    private lazy var bgImgV: UIImageView = {
        let bgImgV = UIImageView()
        return bgImgV
    }()
    private lazy var contentImgV: UIImageView = {
        let contentImgV = UIImageView()
        contentImgV.contentMode = .scaleAspectFill
        return contentImgV
    }()
    private lazy var jumpBtn: UIButton = {
        let jumpBtn = UIButton()
        jumpBtn.titleLabel?.font = UIFont.systemFont(ofSize: 15.0)
        jumpBtn.titleLabel?.textColor = UIColor.white
        jumpBtn.backgroundColor = UIColor.black
        jumpBtn.setTitle("\(YiNuoConfig.launchAdInSeconds()) 跳过", for: .normal)
        jumpBtn.yinuo_cornerRadius = 15
        jumpBtn.alpha = 0.6
        jumpBtn.addTarget(self, action: #selector(jumpBtnClick), for: .touchUpInside)
        
        return jumpBtn
    }()
    
    private var leftTime: Int = YiNuoConfig.launchAdInSeconds() + 1
    var timer: Timer!
    let disposeBag = DisposeBag()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupLaunchImg()
        setupUI()
        loadAdData()
        
        //获取该计时器的剩余时间
        timer = Timer.scheduledTimer(timeInterval: TimeInterval(1), target: self, selector: #selector(timeChange), userInfo: nil, repeats: true)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        
        addSubview(bgImgV)
        addSubview(contentImgV)
        addSubview(jumpBtn)
        
        contentImgV.snp.makeConstraints { (make) in
            make.left.top.right.equalToSuperview()
            make.bottom.equalTo(-129)
        }
        jumpBtn.snp.makeConstraints { (make) in
            make.top.equalTo(20)
            make.right.equalTo(-20)
            make.width.equalTo(65)
            make.height.equalTo(30)
        }
    }
    
    private func loadAdData() {
       
        
        // 网络请求
        let provider = ApiLaunch.provider
        provider.rx.request(.configure()).filterSuccessfulStatusCodes().mapObject(ResultModel<ConfigureModel>.self).subscribe(onSuccess: { (response) in
            if response.code != 0 {
                YiNuoHUD.inform(response.errorMsg)
            }else {
                let configureData: ConfigureModel = response.data!
                let imgLink = YiNuoConfig.apiURL+"/"+configureData.startupAdImg!
                let imgUrl = URL(string: imgLink)
                self.contentImgV.kf.setImage(with: imgUrl)
            }
        }, onError: { (error) in
            YiNuoHUD.error("网络错误")
        }).disposed(by: disposeBag)
    }
    
    private func setupLaunchImg() {
        
        let statusBarOrientation = UIApplication.shared.statusBarOrientation
        guard let img = getImageForOrientation(statusBarOrientation, size: YiNuoConfig.getScreenRect().size) else {
            return
        }
        bgImgV.frame = YiNuoConfig.getScreenRect()
        bgImgV.image = UIImage(named: img)
        
    }
    
    
    @objc private func jumpBtnClick() {
        
        //播放动画效果，完毕后将其移除
        UIView.animate(withDuration: 1, delay: 1.5, options: .beginFromCurrentState, animations: {
            self.jumpBtn.alpha = 0.0
            self.bgImgV.alpha = 0.0
            self.contentImgV.alpha = 0.0
            self.contentImgV.layer.transform = CATransform3DScale(CATransform3DIdentity, 1.5, 1.5, 1.0)
        }) { (finished) in
            self.removeFromSuperview()
        }
    }
    
    @objc private func timeChange() {
        leftTime -= 1
        jumpBtn.setTitle("\(leftTime) 跳过", for: .normal)
        if leftTime <= 1 {
            //取消定时器
            timer.invalidate()
            jumpBtnClick()
        }
    }
    
    //获取启动图片名（根据设备方向和尺寸）
    func getImageForOrientation(_ orientation: UIInterfaceOrientation, size: CGSize)
        -> String?{
            //获取设备尺寸和方向
            var viewSize = size
            var viewOrientation = "Portrait"
            
            if UIInterfaceOrientationIsLandscape(orientation) {
                viewSize = CGSize(width: size.height, height: size.width)
                viewOrientation = "Landscape"
            }
            
            //遍历资源库中的所有启动图片，找出符合条件的
            guard let infoDict = Bundle.main.infoDictionary else {
                return nil
            }
            guard let imagesArray = infoDict["UILaunchImages"] as? [[String: String]] else {
                return nil
            }
            
            for dict in imagesArray {
                if let sizeString = dict["UILaunchImageSize"], let imageOrientation = dict["UILaunchImageOrientation"] {
                    let imageSize = CGSizeFromString(sizeString)
                    if imageSize.equalTo(viewSize) && viewOrientation == imageOrientation {
                        if let imageName = dict["UILaunchImageName"] {
                            return imageName
                        }
                    }
                }
            }
            
            return nil
    }
    
}
