//
//  GoodsCollectionCell.swift
//  yinuo
//
//  Created by tim on 2018/3/2.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit

class GoodsCollectionCell: UICollectionViewCell {
    
    var imgV: UIImageView!
    var titleL: UILabel!
    var priceL: UILabel!
    var selBtn: UIButton!
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        backgroundColor = UIColor.white
        
        imgV = UIImageView()
        titleL = UILabel()
        titleL.numberOfLines = 2
        titleL.textColor = UIColor.yinuoTextColor()
        titleL.font = UIFont.systemFont(ofSize: 11.0)
        priceL = UILabel()
        priceL.textColor = UIColor.yinuoTextRedColor()
        priceL.font = UIFont.systemFont(ofSize: 16.0)
        selBtn = UIButton()
        selBtn.setImage(UIImage(named: "collect_btn"), for: .normal)
        selBtn.setImage(UIImage(named: "collect_btn_sel"), for: .selected)
        selBtn.addTarget(self, action: #selector(selBtnClick(sender:)), for: .touchUpInside)
        selBtn.isHidden = true
        
        contentView.addSubview(imgV)
        contentView.addSubview(titleL)
        contentView.addSubview(priceL)
        contentView.addSubview(selBtn)
        
        makeConstraints()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    private func makeConstraints() {
        
        imgV.snp.makeConstraints { (make) in
            make.width.height.equalTo(185)
            make.top.left.equalToSuperview()
        }
        titleL.snp.makeConstraints { (make) in
            make.top.equalTo(imgV.snp.bottom).offset(7.5)
            make.left.equalTo(10)
            make.right.equalTo(-10)
        }
        priceL.snp.makeConstraints { (make) in
            make.left.equalTo(titleL)
            make.top.equalTo(titleL.snp.bottom).offset(9)
        }
        selBtn.snp.makeConstraints { (make) in
            make.width.height.equalTo(25)
            make.left.top.equalTo(12)
        }
    }
    @objc private func selBtnClick(sender: UIButton) {
        sender.isSelected = !sender.isSelected
    }
    
    // 赋值
    var goodsModel: GoodsCollectionModel? {
        didSet {
            imgV.image = UIImage(named: (goodsModel?.imgName)!)
            titleL.text = goodsModel?.title
            priceL.text = goodsModel?.price
            selBtn.isHidden = goodsModel!.isHidden
            selBtn.isSelected = goodsModel!.isSelect
        }
    }
}
