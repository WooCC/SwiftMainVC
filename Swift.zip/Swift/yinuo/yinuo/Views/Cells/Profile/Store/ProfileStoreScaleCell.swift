//
//  ProfileStoreScaleCell.swift
//  yinuo
//
//  Created by Rayco on 2018/3/18.
//  Copyright © 2018年 yinuo. All rights reserved.
//  店铺经营范围

import UIKit

class ProfileStoreScaleCell: UITableViewCell {

    var choosed:Bool = false {
        didSet{
            if self.choosed {
                imgV.image = UIImage(named: "checked")
            } else {
                imgV.image = nil
            }
        }
    }
    var imgV : UIImageView!
    var titleL : UILabel!
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        selectedBackgroundView = UIView()
        tintColor = UIColor.yinuoTopicColor()
        
        setupUI()
    }
    
    private func setupUI() {
        imgV = UIImageView()
        titleL = UILabel()
        imgV.image = UIImage(named: "unchecked")
        titleL.textColor = UIColor.yinuoTextColor()
        titleL.font = UIFont.systemFont(ofSize: 16.0)
        titleL.numberOfLines = 1
        
        contentView.addSubview(imgV)
        contentView.addSubview(titleL)
        
        titleL.snp.makeConstraints({ (make) in
            make.left.equalToSuperview().offset(10)
            make.height.equalTo(40)
            make.width.equalToSuperview().offset(-40)
            make.centerY.equalToSuperview()
        })
        imgV.snp.makeConstraints({ (make) in
            make.width.height.equalTo(16)
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().offset(-10)
        })
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // 解决 UITableViewCell被选中或者高亮的时候，它的所有子view的颜色被自动改变
    override func setHighlighted(_ highlighted: Bool, animated: Bool) {
        super.setHighlighted(highlighted, animated: animated)
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
   
}
