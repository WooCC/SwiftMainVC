//
//  ReceiptAddressCell.swift
//  yinuo
//
//  Created by 吴承炽 on 2018/3/20.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit

class ReceiptAddressCell: UITableViewCell {
    
//
    // 默认情况
    private lazy var defaultL: UILabel = {
        let defaultL = UILabel()
        defaultL.textAlignment = .center
        defaultL.backgroundColor = UIColor.red
        defaultL.textColor = UIColor.white
        defaultL.text = "默认"
        return defaultL
    }()
    
    // 显示名字
    private lazy var nameL: UILabel = {
        let nameL = UILabel()
        nameL.textAlignment = .center
        nameL.text = "黄飞鸿"
        return nameL
    }()
    // 显示联系方式
    private lazy var telephoneL: UILabel = {
        let telephoneL = UILabel()
        telephoneL.textAlignment = .center
        telephoneL.text = "13560357399"
        return telephoneL
    }()
    // 显示地址标签
    private lazy var addressTagL: UILabel = {
        let addressTagL = UILabel()
        addressTagL.textAlignment = .center
        addressTagL.text = "家"
        addressTagL.textColor = UIColor.red
        addressTagL.layer.borderColor = UIColor.red.cgColor
        addressTagL.layer.borderWidth = 1
        return addressTagL
    }()
    // 显示详细地址
    private lazy var addressDetailL: UILabel = {
        let addressDetailL = UILabel()
        addressDetailL.textAlignment = .center
        addressDetailL.text = "广东省广州市天河区上社人民街15号"
        addressDetailL.textColor = UIColor.lightGray
        return addressDetailL
    }()
  
        var defaultAddressBtn: UIButton?
        var deleteBtn: UIButton?
        var editBtn: UIButton?

    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
        
        //默认按钮
        defaultAddressBtn = UIButton()
//        defaultAddressBtn?.isUserInteractionEnabled = false
        defaultAddressBtn?.setImage(UIImage(named: "checked"), for: .normal)
        defaultAddressBtn?.setTitleColor(UIColor.yinuoTextRedColor(), for: .normal)
        defaultAddressBtn?.setTitle("默认地址", for: .normal)
        
        // 删除按钮
        deleteBtn = UIButton()
//        deleteBtn?.isUserInteractionEnabled = false
        deleteBtn?.setImage(UIImage(named: "trash"), for: .normal)
        deleteBtn?.setTitleColor(UIColor.yinuoTextLightGrayColor(), for: .normal)
        deleteBtn?.setTitle("删除", for: .normal)
        deleteBtn?.titleLabel?.font = UIFont.systemFont(ofSize: 14)
//        deleteBtn.addTarget(self, action: #selector(deleteBtnClick), for: .touchUpInside)
        
        // 编辑按钮
        editBtn = UIButton()
//        editBtn?.isUserInteractionEnabled = false
        editBtn?.setImage(UIImage(named: "trash"), for: .normal)
        editBtn?.setTitleColor(UIColor.yinuoTextLightGrayColor(), for: .normal)
        editBtn?.setTitle("编辑", for: .normal)
        editBtn?.titleLabel?.font = UIFont.systemFont(ofSize: 14)
//        editBtn?.addTarget(self, action: #selector(editBtnClick), for: .touchUpInside)
        
        setupUI()
        makeConstraints()
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func makeConstraints() {
        defaultL.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(10)
            make.left.equalToSuperview().offset(10)
        }
        nameL.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(10)
            make.left.equalTo(defaultL.snp.right).offset(5)
        }
        telephoneL.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(10)
            make.left.equalTo(nameL.snp.right).offset(5)
        }
        addressTagL.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(10)
            make.left.equalTo(telephoneL.snp.right).offset(5)
        }
        addressDetailL.snp.makeConstraints { (make) in
            make.top.equalTo(telephoneL.snp.bottom).offset(15)
            make.left.equalToSuperview().offset(10)
        }
        defaultAddressBtn?.snp.makeConstraints { (make) in
            make.top.equalTo(addressDetailL.snp.bottom).offset(15)
            make.left.equalToSuperview().offset(10)
            make.width.equalTo(100)
            make.height.equalTo(30)
        }
        deleteBtn?.snp.makeConstraints { (make) in
            make.centerY.equalTo(defaultAddressBtn!)
            make.right.equalToSuperview()
            make.width.equalTo(100)
            make.height.equalTo(30)
        }
        editBtn?.snp.makeConstraints { (make) in
            make.centerY.equalTo(defaultAddressBtn!)
            make.right.equalTo(deleteBtn!.snp.left).offset(5)
            make.width.equalTo(100)
            make.height.equalTo(30)
        }
        
    }
    
    private func setupUI(){
        contentView.addSubview(defaultL)
        contentView.addSubview(nameL)
        contentView.addSubview(telephoneL)
        contentView.addSubview(addressTagL)
        contentView.addSubview(addressDetailL)
        contentView.addSubview(defaultAddressBtn!)
        contentView.addSubview(deleteBtn!)
        contentView.addSubview(editBtn!)
    }
    
    /// 商品模型赋值
    var addressModel: ReceiptAddressModel? {
        didSet {
//            selectBtn.isSelected = (goodsModel?.isSelect)!
//            imgV.image = UIImage(named: (goodsModel?.image)!)
//            titleL.text = goodsModel?.title
//            descL.text = goodsModel?.desc
//            priceL.text = "¥\(goodsModel!.price)"
//            loveBtn.setTitle("+\(goodsModel!.love)", for: .normal)
            
//            defaultL.text = (addressModel?.isDefault)!
            let IsDefault = (addressModel?.isDefault)!
            if  IsDefault{
                print("默认")
            }
            else
            {
                print("非默认")
            }
            nameL.text = addressModel?.name
            telephoneL.text = addressModel?.telephone
            addressTagL.text = addressModel?.tag
            addressDetailL.text = addressModel?.address
            
        }
    }
}

//extension ReceiptAddressCell {
//    @objc private func setDefaulttBtnClick() {
//
//    }
//    @objc private func editBtnClick() {
//        println("===infoDidSelected===")
//    }
//    @objc private func deleteBtnClick() {
//        print("删除")
//    }
//}

