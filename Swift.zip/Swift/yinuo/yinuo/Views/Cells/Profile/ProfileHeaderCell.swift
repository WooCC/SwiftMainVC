//
//  ProfileHeaderCell.swift
//  yinuo
//
//  Created by Tim on 2018/3/7.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit

class ProfileHeaderCell: UICollectionViewCell {
 
    var headerCellDelegate: ProfileHeaderCellDelegate?
    
    private let userInfoH: CGFloat = 110.0                  // 头部用户信息高度(红色弧线起始点)
    private lazy var menuArr  = { () -> [String] in
        let menuNames = ["余额", "爱心", "功德基金"]
        return menuNames
    }()
    
    private lazy var imgV: UIImageView = {
        let imgV = UIImageView()
        imgV.image = UIImage(named: "profileImg")
        imgV.layer.cornerRadius = 40
        imgV.layer.masksToBounds = true
        return imgV
    }()
    
    private lazy var nameL: UILabel = {
        let nameL = UILabel()
        nameL.textColor = UIColor.white
        nameL.font = UIFont.systemFont(ofSize: 17.0)
        nameL.text = "小花爱美丽"
        return nameL
    }()
    
    private lazy var levelL: UILabel = {
        let levelL = UILabel()
        levelL.textColor = UIColor.white
        levelL.font = UIFont.systemFont(ofSize: 13.0)
        levelL.backgroundColor = UIColor.white.withAlphaComponent(0.3)
        levelL.textAlignment = .center
        levelL.layer.cornerRadius = 10.5
        levelL.layer.masksToBounds = true
        levelL.text = "爱心种子"
        return levelL
    }()
    
    private lazy var maxLoveNumL: UILabel = {
        let maxLoveNumL = UILabel()
        maxLoveNumL.textColor = UIColor.white
        maxLoveNumL.font = UIFont.systemFont(ofSize: 12.0)
        maxLoveNumL.text = "当日可得爱心最大限度:1000个"
        return maxLoveNumL
    }()
    
    private lazy var arrowImgV: UIImageView = {
        let arrowImgV = UIImageView(image: UIImage(named: "arrow")?.tint(color: UIColor.white, blendMode: .destinationIn))
        return arrowImgV
    }()
    
    private lazy var lineV: UIView = {
        let lineV = UIView()
        lineV.backgroundColor = UIColor.yinuoViewBackgroundColor()
        return lineV
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        addBgLayer(view: contentView)
        setupUI()
        makeConstraints()
        addMenu(view: contentView)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func makeConstraints() {
        imgV.snp.makeConstraints { (make) in
            make.left.equalTo(10)
            make.top.equalTo(10)
            make.width.height.equalTo(80)
        }
        nameL.snp.makeConstraints { (make) in
            make.left.equalTo(imgV.snp.right).offset(10)
            make.top.equalTo(imgV).offset(5)
        }
        levelL.snp.makeConstraints { (make) in
            make.left.equalTo(nameL)
            make.top.equalTo(nameL.snp.bottom).offset(5)
            make.width.equalTo(80)
            make.height.equalTo(21)
        }
        maxLoveNumL.snp.makeConstraints { (make) in
            make.left.equalTo(nameL)
            make.bottom.equalTo(imgV).offset(-5)
        }
        arrowImgV.snp.makeConstraints { (make) in
            make.centerY.equalTo(imgV)
            make.right.equalToSuperview().offset(-10)
        }
        lineV.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview()
            make.height.equalTo(15)
        }
    }
    
    /// 用户模型
    var userModel: UserModel? {
        didSet{
            imgV.image = UIImage(named: (userModel?.avatar)!)
            nameL.text = userModel?.username
            levelL.text = userModel?.level
            maxLoveNumL.text = "当日可得爱心最大限度:\(String(describing: userModel?.maxLoveNum))个"
        }
    }
    
    
}

extension ProfileHeaderCell {
    private func setupUI() {
        contentView.addSubview(imgV)
        contentView.addSubview(nameL)
        contentView.addSubview(levelL)
        contentView.addSubview(maxLoveNumL)
        contentView.addSubview(arrowImgV)
        contentView.addSubview(lineV)
    }
    // 弧线背景Layer
    private func addBgLayer(view : UIView){
        let aPath = UIBezierPath()
        aPath.move(to: CGPoint(x: 0, y: -1))     // 起点
        aPath.addLine(to: CGPoint(x: 0, y: userInfoH))    // 途径点
        let controlPoint = CGPoint(x: SCREEN_WIDTH/2, y: (userInfoH + 45)) // 弧线控制点
        aPath.addQuadCurve(to: CGPoint(x: SCREEN_WIDTH, y: userInfoH), controlPoint: controlPoint) // 弧线
        aPath.addLine(to: CGPoint(x: SCREEN_WIDTH, y: -1)) // 途径点
        aPath.close()   // 关闭
        
        let shapeLayer = CAShapeLayer()
        shapeLayer.path = aPath.cgPath
        shapeLayer.fillColor = UIColor.yinuoNavBarTintColor().cgColor
        view.layer.addSublayer(shapeLayer)
    }
    
    // 用户信息下方的按钮列表
    private func addMenu(view: UIView)  {
        let lineBtnNum : Int  = 3             // 每行按钮个数
        let btnWH: CGFloat = 42.0       // 按钮宽高
        let marginL: CGFloat = 50.0     // 第一个按钮的左边距
        let marginT: CGFloat = userInfoH + 45.0     // 第一个按钮的上边距
        let spaceW: CGFloat = (SCREEN_WIDTH - marginL * 2 - btnWH * CGFloat(lineBtnNum)) / CGFloat(lineBtnNum - 1)  // 按钮间的横间距
        let menuCount = 3
        
        let infobutton = UIButton()
        infobutton.isUserInteractionEnabled = true
        infobutton.frame = CGRect(x:0, y:0, width: SCREEN_WIDTH, height: userInfoH)
        view.addSubview(infobutton)
        infobutton.addTarget(self, action:#selector(infoButtonAction(sender:)), for:.touchUpInside)
        
        let tbutton = UIButton()
        tbutton.isUserInteractionEnabled = false
        tbutton.frame = CGRect(x:0, y:marginT, width: SCREEN_WIDTH, height: btnWH)
        view.addSubview(tbutton)
        
        
        // 设置格子的间距
        for i in 0..<menuCount {
            let index : NSInteger = i % lineBtnNum;    // 列号
            
            let button = UIButton()
            button.tag = i
            button.isUserInteractionEnabled = true
            button.setImage(UIImage(named: "profile_p\(i+1)_btn"), for: .normal)
            button.setTitle(menuArr[i], for: .normal)
            button.setTitleColor(UIColor.black, for: .normal)
            button.titleLabel?.font = UIFont.systemFont(ofSize: 10.0)
            button.alignVertical(spacing: 5.0)
            
            let x : CGFloat = CGFloat(index) * (btnWH + spaceW) + marginL
            button.frame = CGRect(x:x, y:marginT, width: btnWH, height: btnWH)
            //            button.backgroundColor = UIColor.red
            
            view.addSubview(button)
            
            button.addTarget(self, action:#selector(menuButtonAction(sender:)), for:.touchUpInside)
        }
    }
    
    @objc func infoButtonAction(sender : UIButton?) {
        if headerCellDelegate != nil {
            headerCellDelegate?.infoDidSelected(cell: self)
        }
    }
    
    @objc func menuButtonAction(sender : UIButton?) {
        if headerCellDelegate != nil {
            headerCellDelegate?.menuDidSelected(index: (sender?.tag)!, cell: self)
        }
    }
    
    
}

protocol ProfileHeaderCellDelegate {
    func infoDidSelected(cell : ProfileHeaderCell)
    func menuDidSelected(index: Int, cell : ProfileHeaderCell)
}
