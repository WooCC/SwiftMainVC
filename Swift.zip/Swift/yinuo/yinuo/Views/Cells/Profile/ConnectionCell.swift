//
//  ConnectionCell.swift
//  yinuo
//
//  Created by tim on 2018/3/19.
//  Copyright © 2018年 yinuo. All rights reserved.
//  我的人脉

import UIKit
import Kingfisher

class ConnectionCell: UITableViewCell {

    private lazy var faceImg: UIImageView = {
        let faceImg = UIImageView()
        faceImg.yinuo_cornerRadius = 25.5
        return faceImg
    }()
    private lazy var telL: UILabel = {
        let telL = UILabel()
        telL.textColor = UIColor.yinuoTextColor()
        telL.font = yinuoFont(15.0)
        return telL
    }()
    private lazy var levelL: UILabel = {
        let levelL = UILabel()
        levelL.textColor = UIColor.yinuoTextLightGrayColor()
        levelL.font = yinuoFont(12.0)
        return levelL
    }()
    private lazy var timeL: UILabel = {
        let timeL = UILabel()
        timeL.textColor = UIColor.yinuoTextLightGrayColor()
        timeL.font = yinuoFont(12.0)
        return timeL
    }()
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        self.selectionStyle = .none
        
        contentView.addSubview(faceImg)
        contentView.addSubview(telL)
        contentView.addSubview(levelL)
        contentView.addSubview(timeL)
        
        faceImg.snp.makeConstraints { (make) in
            make.top.equalTo(10)
            make.left.equalTo(12)
            make.width.height.equalTo(51)
        }
        telL.snp.makeConstraints { (make) in
            make.top.equalTo(19)
            make.left.equalTo(faceImg.snp.right).offset(14)
        }
        levelL.snp.makeConstraints { (make) in
            make.top.equalTo(telL.snp.bottom).offset(11)
            make.left.equalTo(telL)
        }
        timeL.snp.makeConstraints { (make) in
            make.right.equalTo(-13)
            make.bottom.equalTo(levelL)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    /// 人脉模型赋值
    var connectionListModel: ConnectionListModel? {
        didSet {
            let imageLink = YiNuoConfig.apiURL + "/" + (connectionListModel?.img)!
            let url = URL(string: imageLink)
            faceImg.kf.setImage(with: url)
            telL.text = connectionListModel?.tel
            levelL.text = connectionListModel?.level
            timeL.text = "加入时间:\(connectionListModel?.time ?? "")"
        }
    }
    
}
