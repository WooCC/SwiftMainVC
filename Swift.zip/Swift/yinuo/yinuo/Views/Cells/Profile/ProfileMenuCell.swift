//
//  ProfileMenuCell.swift
//  yinuo
//
//  Created by tim on 2018/2/26.
//  Copyright © 2018年 yinuo. All rights reserved.
//  功能菜单

import UIKit

class ProfileMenuCell: UICollectionViewCell {
    
    //下标
    var cellIndex : Int?
    
    private lazy var titleL: UILabel = {
        let titleL = UILabel()
        titleL.font = UIFont.systemFont(ofSize: 10.0)
        titleL.textColor = UIColor.black
        titleL.textAlignment = .center
        return titleL
    }()
    private lazy var imgV: UIImageView = {
        let imgV = UIImageView()
        imgV.contentMode = .scaleAspectFit
        return imgV
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        contentView.addSubview(titleL)
        contentView.addSubview(imgV)
        
        makeConstraints()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func makeConstraints() {
        titleL.snp.makeConstraints { (make) in
            make.bottom.centerX.equalToSuperview()
        }
        imgV.snp.makeConstraints { (make) in
            make.top.centerX.equalToSuperview()
            make.width.height.equalTo(21)
        }
    }
    
    /// 个人中心按钮模型
    var profileMenuModel: ProfileMenuModel? {
        didSet{
            titleL.text = profileMenuModel?.title
            imgV.image = UIImage(named: (profileMenuModel?.image)!)
        }
    }
   
}
