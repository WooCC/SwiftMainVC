//
//  ProfileRecommendCell.swift
//  yinuo
//
//  Created by Tim on 2018/1/15.
//  Copyright © 2018年 yinuo. All rights reserved.
//  推荐商品Cell

import UIKit

class ProfileRecommendCell: UICollectionViewCell {
    
    private lazy var imgV: UIImageView = {
        let imgV = UIImageView(image: UIImage(named: "meirijingxuan_image1"))
        imgV.contentMode = .scaleAspectFill
        imgV.clipsToBounds = true
        return imgV
    }()
    private lazy var titleL: UILabel = {
        let titleL = UILabel()
        titleL.text = "专业瑜伽服双线美背瑜伽背心吊带含胸垫一体式弹力修身运动健身服"
        titleL.numberOfLines = 0
        titleL.font = UIFont.systemFont(ofSize: 11.0)
        titleL.textColor = UIColor.yinuoTextColor()
        return titleL
    }()
    private lazy var brandL : UILabel = {
        let brandL = UILabel()
        brandL.text = "品牌"
        brandL.font = UIFont.systemFont(ofSize: 9.0) // 10.0
        brandL.textAlignment = .center
        brandL.textColor = UIColor.yinuoTopicColor()
        brandL.layer.cornerRadius = 7
        brandL.layer.masksToBounds = true
        brandL.layer.borderColor = UIColor.yinuoTopicColor().cgColor
        brandL.layer.borderWidth = 1
        return brandL
    }()
    private lazy var freeDeliveryL: UILabel = {
        let freeDeliveryL = UILabel()
        freeDeliveryL.text = "包邮"
        freeDeliveryL.font = UIFont.systemFont(ofSize: 9.0)
        freeDeliveryL.textAlignment = .center
        freeDeliveryL.textColor = UIColor.yinuoTopicColor()
        freeDeliveryL.layer.cornerRadius = 7
        freeDeliveryL.layer.masksToBounds = true
        freeDeliveryL.layer.borderColor = UIColor.yinuoTopicColor().cgColor
        freeDeliveryL.layer.borderWidth = 1
        return freeDeliveryL
    }()
    private lazy var salesVolumeL: UILabel = {
        // 富文本 添加不同字体大小
        var myMutableString = NSMutableAttributedString()
        myMutableString = NSMutableAttributedString(string: "最近销量:4456" , attributes: [NSAttributedStringKey.font:UIFont.systemFont(ofSize: 9.0)]) //中文字体大小
        myMutableString.addAttribute(NSAttributedStringKey.font, value:UIFont.systemFont(ofSize: 9), range:NSRange(location:0, length:5))
        // 数字字体大小
        let salesVolumeL = UILabel()
        salesVolumeL.attributedText = myMutableString
        salesVolumeL.textColor = UIColor.yinuoTextColor()
        return salesVolumeL
    }()
    private lazy var priceL: UILabel = {
        let priceL = UILabel()
        priceL.text = "¥429.00"
        priceL.font = UIFont.systemFont(ofSize: 16.0)
        priceL.textColor = UIColor.yinuoTopicColor()
        return priceL
    }()
    private lazy var loveNumBtn: UIButton = {
        let loveNumBtn = UIButton()
        loveNumBtn.isUserInteractionEnabled = false
        loveNumBtn.contentHorizontalAlignment = .left
        loveNumBtn.titleEdgeInsets = UIEdgeInsets(top: 3, left: 5, bottom: 0, right: 0)
        loveNumBtn.setImage(UIImage(named: "love"), for: .normal)
        loveNumBtn.setTitle("+2.232", for: .normal)
        loveNumBtn.setTitleColor(UIColor.yinuoTextRedColor(), for: .normal)
        loveNumBtn.titleLabel?.font = UIFont.systemFont(ofSize: 10.0)
        return loveNumBtn
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        backgroundColor = UIColor.white
        
        contentView.addSubview(imgV)
        contentView.addSubview(titleL)
        contentView.addSubview(brandL)
        contentView.addSubview(freeDeliveryL)
        contentView.addSubview(salesVolumeL)
        contentView.addSubview(priceL)
        contentView.addSubview(loveNumBtn)
        
        makeConstraints()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func makeConstraints() {
        
        imgV.snp.makeConstraints({ (make) in
            make.left.right.top.equalToSuperview()
            make.height.equalTo((SCREEN_WIDTH-5)*0.5)
        })
        titleL.snp.makeConstraints({ (make) in
            make.top.equalTo(imgV.snp.bottom)
            make.left.equalTo(imgV).offset(12)
            make.right.equalTo(imgV).offset(-12)
            make.height.equalTo(32)
        })
        brandL.snp.makeConstraints({ (make) in
            make.left.equalTo(titleL)
            make.top.equalTo(titleL.snp.bottom).offset(5)
            make.width.equalTo(33)
            make.height.equalTo(14)
        })
        freeDeliveryL.snp.makeConstraints({ (make) in
            make.left.equalTo(brandL.snp.right).offset(2)
            make.top.equalTo(brandL)
            make.width.height.equalTo(brandL)
        })
        salesVolumeL.snp.makeConstraints({ (make) in
            make.right.equalTo(imgV.snp.right).offset(-12)
            make.bottom.equalTo(brandL)
        })
        priceL.snp.makeConstraints({ (make) in
            make.left.equalTo(brandL)
            make.top.equalTo(brandL.snp.bottom).offset(10)
        })
        loveNumBtn.snp.makeConstraints({ (make) in
            make.left.equalTo(priceL)
            make.top.equalTo(priceL.snp.bottom).offset(5)
            make.width.equalTo(80)
        })
    }
    
}
