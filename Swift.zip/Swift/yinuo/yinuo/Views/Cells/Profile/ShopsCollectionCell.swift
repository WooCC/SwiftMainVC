//
//  ShopsCollectionCell.swift
//  yinuo
//
//  Created by tim on 2018/3/1.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit

class ShopsCollectionCell: UITableViewCell {

    var imgV : UIImageView!
    var nameL : UILabel!
    var descL : UILabel!
    private lazy var lineV = UIView()
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        selectedBackgroundView = UIView()
        tintColor = UIColor.yinuoTopicColor()
        
        setupUI()
    }
    
    private func setupUI() {
        imgV = UIImageView()
        nameL = UILabel()
        nameL.textColor = UIColor.yinuoTextColor()
        nameL.font = UIFont.systemFont(ofSize: 16.0)
        descL = UILabel()
        descL.textColor = UIColor.yinuoTextGrayColor()
        descL.font = UIFont.systemFont(ofSize: 10.0)
        lineV.backgroundColor = UIColor.yinuoLineColor().withAlphaComponent(0.5)
        
        contentView.addSubview(imgV)
        contentView.addSubview(nameL)
        contentView.addSubview(descL)
        contentView.addSubview(lineV)
        
        imgV.snp.makeConstraints({ (make) in
            make.width.height.equalTo(95)
            make.centerY.equalToSuperview()
            make.left.equalToSuperview().offset(18)
        })
        nameL.snp.makeConstraints({ (make) in
            make.left.equalTo(imgV.snp.right).offset(12)
            make.top.equalToSuperview().offset(25)
        })
        descL.snp.makeConstraints({ (make) in
            make.left.equalTo(nameL)
            make.top.equalTo(nameL.snp.bottom).offset(10)
        })
        lineV.snp.makeConstraints { (make) in
            make.left.equalTo(nameL)
            make.bottom.equalTo(imgV)
            make.right.equalToSuperview().offset(-20)
            make.height.equalTo(0.5)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // 解决 UITableViewCell被选中或者高亮的时候，它的所有子view的颜色被自动改变
    override func setHighlighted(_ highlighted: Bool, animated: Bool) {
        super.setHighlighted(highlighted, animated: animated)
        
        lineV.backgroundColor = UIColor.yinuoTextColor().withAlphaComponent(0.5)
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        lineV.backgroundColor = UIColor.yinuoTextColor().withAlphaComponent(0.5)
    }
    
    // Cell间距
    override var frame: CGRect {
        didSet {
            var newFrame = frame
            newFrame.origin.y += 10
            newFrame.size.height -= 10
            super.frame = newFrame
        }
    }
}
