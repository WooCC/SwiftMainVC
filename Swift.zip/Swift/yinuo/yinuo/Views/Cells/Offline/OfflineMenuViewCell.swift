//
//  OfflineMenuViewCell.swift
//  yinuo
//
//  Created by Tim on 2018/1/21.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit

class OfflineMenuViewCell: UICollectionViewCell {

    @IBOutlet weak var menuImgV: UIImageView!
    @IBOutlet weak var menuTitleL: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
