//
//  OfflineCell.swift
//  yinuo
//
//  Created by Tim on 2018/1/21.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit
import Cosmos

class OfflineCell: UITableViewCell {

    @IBOutlet weak var starV: CosmosView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        setupCell()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
        self.selectionStyle = .none
    }
    
}

extension OfflineCell {
    private func setupCell() {
        starV.isUserInteractionEnabled = false
    }
}
