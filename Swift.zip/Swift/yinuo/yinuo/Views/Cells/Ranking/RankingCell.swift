//
//  RankingCell.swift
//  yinuo
//
//  Created by 谭锦添 on 2018/2/7.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit

class RankingCell: UITableViewCell {

    var imgBtn: UIButton?
    var titleL: UILabel?
    var subTitleL: UILabel?
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        selectionStyle = .none
        
        titleL = UILabel()
        titleL?.textColor = UIColor.white
        titleL?.font = UIFont.systemFont(ofSize: 20.0)
        subTitleL = UILabel()
        subTitleL?.textColor = UIColor.white
        subTitleL?.font = UIFont.systemFont(ofSize: 11.0)
        
        imgBtn = UIButton()
        imgBtn?.adjustsImageWhenHighlighted = false
        
        contentView.addSubview(imgBtn!)
        contentView.addSubview(titleL!)
        contentView.addSubview(subTitleL!)
        
        titleL?.snp.makeConstraints({ (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(8)
        })
        subTitleL?.snp.makeConstraints({ (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(titleL!.snp.bottom).offset(3)
        })
        imgBtn?.snp.makeConstraints({ (make) in
            make.left.right.top.bottom.equalToSuperview()
        })
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // Cell间距
    override var frame: CGRect {
        didSet {
            var newFrame = frame
            newFrame.origin.y += 10
            newFrame.size.height -= 10
            super.frame = newFrame
        }
    }
    
}
