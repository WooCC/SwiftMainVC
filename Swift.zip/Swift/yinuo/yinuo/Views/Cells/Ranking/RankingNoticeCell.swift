//
//  RankingNoticeCell.swift
//  yinuo
//
//  Created by Tim on 2018/2/8.
//  Copyright © 2018年 yinuo. All rights reserved.
//  排行榜公告

import UIKit
import SDCycleScrollView

class RankingNoticeCell: UITableViewCell {
    
    private lazy var noticeTitleL = UILabel()
    private lazy var arrowV = UIButton()
    private lazy var noticeScrollV = SDCycleScrollView()
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        selectionStyle = .none
        
        setUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    
    private func setUI() {
        
        noticeTitleL.text = "公告"
        noticeTitleL.textColor = UIColor.white
        noticeTitleL.font = UIFont.systemFont(ofSize: 13.5)
        noticeTitleL.layer.cornerRadius = 10.0
        noticeTitleL.layer.masksToBounds = true
        noticeTitleL.textAlignment = .center
        noticeTitleL.backgroundColor = UIColor.yinuoTopicColor()
        
        noticeScrollV.onlyDisplayText = true // 只显示文字
        noticeScrollV.titlesGroup = ["一诺搭起慈善桥梁，共筑千万学子求学梦，一诺商城","一诺搭起慈善桥梁，共筑千万学子求学梦，一诺商城","一诺搭起慈善桥梁，共筑千万学子求学梦，一诺商城"] // 放显示文字下方，否则不显示滚动内容
        noticeScrollV.titleLabelTextFont = UIFont.systemFont(ofSize: 13.0)
        noticeScrollV.titleLabelTextColor = UIColor.yinuoTextGrayColor()
        noticeScrollV.scrollDirection = .vertical // 垂直滚动
        noticeScrollV.disableScrollGesture()   // 禁用滚动手势
        noticeScrollV.titleLabelBackgroundColor = UIColor.white
        let noticeTapGesture = UITapGestureRecognizer(target: self, action: #selector(noticeTapClick))
        noticeScrollV.addGestureRecognizer(noticeTapGesture)
//        noticeScrollV.isUserInteractionEnabled = true
        
        arrowV.setImage(UIImage(named: "arrow"), for: .normal)
        arrowV.addTarget(self, action: #selector(noticClick), for: .touchUpInside)
        
        contentView.addSubview(noticeTitleL)
        contentView.addSubview(noticeScrollV)
        contentView.addSubview(arrowV)
        
        noticeTitleL.snp.makeConstraints { (make) in
            make.width.equalTo(45)
            make.height.equalTo(21)
            make.centerY.equalToSuperview()
            make.left.equalTo(17)
        }
        noticeScrollV.snp.makeConstraints { (make) in
            make.left.equalTo(noticeTitleL.snp.right).offset(10)
            make.height.equalToSuperview()
            make.centerY.equalToSuperview()
            make.right.equalTo(arrowV.snp.left).offset(-10)
        }
        arrowV.snp.makeConstraints { (make) in
            make.width.equalTo(8.5)
            make.height.equalTo(14)
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().offset(-17.5)
        }
        
    }

}

extension RankingNoticeCell {
    @objc private func noticClick() {
        println("notic click")
    }
    @objc private func noticeTapClick() {
        println("tap click")
    }
}
