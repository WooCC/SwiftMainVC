//
//  HomeMenuCollectionViewCell.swift
//  yinuo
//
//  Created by tim on 2018/3/9.
//  Copyright © 2018年 yinuo. All rights reserved.
//  首页菜单 CollectionViewCell

import UIKit

class HomeMenuCollectionViewCell: UICollectionViewCell {
    private lazy var imgV: UIImageView = {
        let imgV = UIImageView()
        return imgV
    }()
    
    private lazy var titleL: UILabel = {
        let titleL = UILabel()
        titleL.font = yinuoFont(14.0)
        titleL.textColor = UIColor.yinuoTextColor()
        return titleL
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        contentView.addSubview(imgV)
        contentView.addSubview(titleL)
        imgV.snp.makeConstraints { (make) in
            make.width.height.equalTo(45)
            make.top.centerX.equalToSuperview()
        }
        titleL.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(imgV.snp.bottom).offset(7)
        }
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    /// 模型赋值
    var homeMenuModel: HomeMenuModel? {
        didSet {
            imgV.image = UIImage(named: (homeMenuModel?.image)!)
            titleL.text = homeMenuModel?.title
        }
    }
    
    
}
