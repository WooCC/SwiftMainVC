//
//  HomeMenuCell.swift
//  yinuo
//
//  Created by tim on 2018/3/9.
//  Copyright © 2018年 yinuo. All rights reserved.
//  首页菜单TableViewCell

import UIKit
import ObjectMapper

// 定义闭包
typealias HomeMenuReturnBlock = (_ selectIndex: Int) -> Void

class HomeMenuCell: UITableViewCell {
    
    var resultRespontBlock: HomeMenuReturnBlock?
    
    /// 模型数组
    var dataObjArr: [HomeMenuModel]?
    
    private lazy var menuCollectionView = { () -> UICollectionView in
        let menuRect = CGRect(x: 0, y: 0, width: SCREEN_WIDTH, height: YiNuoConfig.Home.menuH)
        let layout = UICollectionViewFlowLayout()
        let itemH = (YiNuoConfig.Home.menuH - 20*2 - 15) * 0.5
        layout.itemSize = CGSize(width: 50, height: itemH)
        layout.minimumInteritemSpacing = 23
        layout.minimumLineSpacing = 15
        layout.sectionInset = UIEdgeInsetsMake(20, 25, 20, 25)
        let menuCollectionView = UICollectionView(frame: menuRect, collectionViewLayout: layout)
        menuCollectionView.delegate = self
        menuCollectionView.dataSource = self
        menuCollectionView.backgroundColor = UIColor.white
        menuCollectionView.registerClassOf(HomeMenuCollectionViewCell.self)
        
        return menuCollectionView
    }()
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        selectionStyle = .none
        backgroundColor = UIColor.white
        addSubview(menuCollectionView)
        getTestData()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func getTestData() {
        let items = [
            ["title":"分类","image":"home_icon1_btn"],
            ["title":"流量包","image":"home_icon2_btn"],
            ["title":"车险","image":"home_icon3_btn"],
            ["title":"注册码","image":"home_icon4_btn"],
            ["title":"每日精选","image":"home_icon5_btn"],
            ["title":"口碑好店","image":"home_icon6_btn"]
            ]
        dataObjArr = Mapper<HomeMenuModel>().mapArray(JSONArray: items)
    }
    
}

extension HomeMenuCell : UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        println("collect num:\(dataObjArr!.count)")
        return dataObjArr!.count;
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell: HomeMenuCollectionViewCell = collectionView.dequeueReusableCell(forIndexPath: indexPath)
        cell.homeMenuModel = dataObjArr?[indexPath.row]
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        println("点击了")
        
        guard let postValueBlock = resultRespontBlock else { return }
        postValueBlock(indexPath.row)
    }
    
}

