//
//  HomeCell.swift
//  yinuo
//
//  Created by Tim on 2018/1/16.
//  Copyright © 2018年 yinuo. All rights reserved.
//  首页主广告 TableViewCell

import UIKit

class HomeCell: UITableViewCell {

    var emptyPlaceV: UIView?
    var img: UIImageView?
    var titleL: UILabel?
    var subTitleL: UILabel?

    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        self.selectionStyle = .none
        
        emptyPlaceV = UIView()
        emptyPlaceV?.backgroundColor = UIColor.yinuoViewBgGrapColor()
        img = UIImageView(image: UIImage(named: "cellImg"))
        titleL = UILabel()
        titleL?.text = "2018元旦嘉年华提前送"
        titleL?.font = yinuoFont(12)
        titleL?.textColor = UIColor.yinuoTopicColor()
        subTitleL = UILabel()
        subTitleL?.text = "活动时间：2018年1月1日-2018年1月3日"
        subTitleL?.textColor = UIColor.yinuoTopicColor()
        subTitleL?.font = yinuoFont(9)
        
        contentView.addSubview(emptyPlaceV!)
        contentView.addSubview(img!)
        contentView.addSubview(titleL!)
        contentView.addSubview(subTitleL!)
        
        emptyPlaceV?.snp.makeConstraints({ (make) in
            make.left.right.top.equalToSuperview()
            make.height.equalTo(10)
        })
        img?.snp.makeConstraints({ (make) in
            make.left.equalTo(0)
            make.top.equalTo(10)
        })
        titleL?.snp.makeConstraints { (make) in
            make.left.equalTo(12)
            make.top.equalTo(img!.snp.bottom).offset(7)
        }
        subTitleL?.snp.makeConstraints({ (make) in
            make.left.equalTo(titleL!)
            make.top.equalTo(titleL!.snp.bottom).offset(6)
        })
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    

}
