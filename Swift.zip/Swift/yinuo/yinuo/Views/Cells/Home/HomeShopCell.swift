//
//  HomeShopCell.swift
//  yinuo
//
//  Created by tim on 2018/3/9.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit

class HomeShopCell: UITableViewCell {

    private lazy var shopTitleL = { () -> UILabel in
        let shopTitleL = UILabel()
        shopTitleL.text = "口碑好店"
        shopTitleL.textColor = UIColor.yinuoTopicColor()
        shopTitleL.font = yinuoFont(12)
        
        return shopTitleL
    }()
    
    private lazy var shopCollectionV = { () -> UICollectionView in
        
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: 110, height: YiNuoConfig.Home.shopH)
        layout.scrollDirection = .horizontal
        
        let shopRect = CGRect(x: YiNuoConfig.Home.shopTitleL, y: YiNuoConfig.Home.shopTitleH, width: SCREEN_WIDTH - YiNuoConfig.Home.shopTitleL * 2, height: YiNuoConfig.Home.shopH)
        let shopCollectionV = UICollectionView(frame: shopRect, collectionViewLayout: layout)
        shopCollectionV.delegate = self
        shopCollectionV.dataSource = self
        shopCollectionV.backgroundColor = UIColor.white
        shopCollectionV.showsHorizontalScrollIndicator = false
        shopCollectionV.registerClassOf(HomeShopCollectionViewCell.self)
        
        return shopCollectionV
    }()
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        setupUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        
        
        addSubview(shopTitleL)
        addSubview(shopCollectionV)
        
        shopTitleL.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.left.equalTo(YiNuoConfig.Home.shopTitleL)
            make.height.equalTo(YiNuoConfig.Home.shopTitleH)
        }
    }

}

extension HomeShopCell: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell: HomeShopCollectionViewCell = collectionView.dequeueReusableCell(forIndexPath: indexPath)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        println("click")
    }
    
}
