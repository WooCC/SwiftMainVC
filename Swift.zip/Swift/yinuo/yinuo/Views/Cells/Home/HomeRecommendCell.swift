//
//  HomeRecommendCell.swift
//  yinuo
//
//  Created by Tim on 2018/3/9.
//  Copyright © 2018年 yinuo. All rights reserved.
//  首页推荐 TableViewCell

import UIKit

class HomeRecommendCell: UITableViewCell {
    
    
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        setupUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        
    }
}
