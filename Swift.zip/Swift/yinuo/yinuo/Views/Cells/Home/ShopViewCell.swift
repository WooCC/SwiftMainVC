//
//  ShopViewCell.swift
//  yinuo
//
//  Created by Tim on 2018/1/20.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit

class ShopViewCell: UICollectionViewCell {

    @IBOutlet weak var shopImgV: UIImageView!
    @IBOutlet weak var shopTitleL: UILabel!
    @IBOutlet weak var shopTypeL: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        setupShopViewCell()
    }

    
}

extension ShopViewCell {
    private func setupShopViewCell() {
        shopTypeL.layer.borderWidth = 1
        shopTypeL.layer.borderColor = UIColor.yinuoTopicColor().cgColor
        shopTypeL.layer.cornerRadius = 4
    }
}


