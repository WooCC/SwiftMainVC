//
//  HomeSliderCell.swift
//  yinuo
//
//  Created by tim on 2018/3/9.
//  Copyright © 2018年 yinuo. All rights reserved.
//  首页轮播 TableViewCell

import UIKit
import SDCycleScrollView

class HomeSliderCell: UITableViewCell {

    private lazy var sliderView = { () -> SDCycleScrollView in
        let sliderView = SDCycleScrollView()
        sliderView.imageURLStringsGroup = ["homeSlider", "homeSlider","homeSlider"]
        sliderView.currentPageDotColor = UIColor.yinuoTopicColor()
        sliderView.pageDotColor = UIColor.white
        return sliderView
    }()
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        setupUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        addSubview(sliderView)
        sliderView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(YiNuoConfig.Home.sliderH)
        }
    }

}
