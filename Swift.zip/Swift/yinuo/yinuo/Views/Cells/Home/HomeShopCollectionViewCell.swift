//
//  HomeShopCollectionViewCell.swift
//  yinuo
//
//  Created by tim on 2018/3/9.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit

class HomeShopCollectionViewCell: UICollectionViewCell {
    
    private lazy var imgV: UIImageView = {
        let imgV = UIImageView()
        return imgV
    }()
    
    private lazy var nameL: UILabel = {
        let nameL = UILabel()
        return nameL
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        backgroundColor = UIColor.purple
        
        contentView.addSubview(imgV)
        contentView.addSubview(nameL)
        imgV.snp.makeConstraints { (make) in
            make.width.height.equalTo(45)
            make.centerX.equalToSuperview()
            make.top.equalTo(12)
        }
        nameL.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(imgV.snp.bottom).offset(5)
        }
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
