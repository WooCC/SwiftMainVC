//
//  CartCell.swift
//  yinuo
//
//  Created by tim on 2018/3/6.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit

class CartCell: UITableViewCell {

    // 选择按钮
    private lazy var selectBtn: UIButton = {
        let selectBtn = UIButton(type: .custom)
        selectBtn.setImage(UIImage(named: "cart_y"), for: .selected)
        selectBtn.setImage(UIImage(named: "cart_n"), for: .normal)
        selectBtn.addTarget(self, action: #selector(selectBtnClick), for: .touchUpInside)
        selectBtn.sizeToFit()
        return selectBtn
    }()
    
    // 商品图片
    private lazy var imgV: UIImageView = {
        let imgV = UIImageView()
        imgV.layer.cornerRadius = 5
        imgV.layer.masksToBounds = true
        return imgV
    }()
    
    // 商品标题
    private lazy var titleL: UILabel = {
        let titleL = UILabel()
        titleL.textColor = UIColor.yinuoTextColor()
        titleL.font = UIFont.systemFont(ofSize: 11.0)
        titleL.numberOfLines = 2
        return titleL
    }()
    
    // 商品描述
    private lazy var descL: UILabel = {
        let descL = UILabel()
        descL.textColor = UIColor.yinuoTextGrayColor()
        descL.font = UIFont.systemFont(ofSize: 10)
        return descL
    }()
    
    // 商品价格
    private lazy var priceL: UILabel = {
        let priceL = UILabel()
        priceL.textColor = UIColor.yinuoTextRedColor()
        priceL.font = UIFont.systemFont(ofSize: 16)
        return priceL
    }()
    
    // 商品爱心数量
    private lazy var loveBtn: UIButton = {
        let loveBtn = UIButton()
        loveBtn.isUserInteractionEnabled = false
        loveBtn.setImage(UIImage(named: "love"), for: .normal)
        loveBtn.setTitleColor(UIColor.yinuoTextRedColor(), for: .normal)
        return loveBtn
    }()
    
    // 商品加减数量总控件
    private lazy var addAndsubtractionV: UIView = {
        let addAndsubtractionV = UIView()
        addAndsubtractionV.backgroundColor = UIColor(white: 0.9, alpha: 0.8)
        addAndsubtractionV.layer.borderWidth = 1
        addAndsubtractionV.layer.borderColor = UIColor.yinuoLineColor().cgColor
        addAndsubtractionV.backgroundColor = UIColor.yinuoInputTextColor()
        return addAndsubtractionV
    }()
    
    // 商品加号
    private lazy var addBtn: UIButton = {
        let addBtn = UIButton()
        addBtn.setImage(UIImage(named: "add_icon"), for: .normal)
        addBtn.addTarget(self, action: #selector(addBtnClick), for: .touchUpInside)
        return addBtn
    }()
    
    // 商品减号
    private lazy var subtractionBtn: UIButton = {
        let subtractionBtn = UIButton()
        subtractionBtn.setImage(UIImage(named: "subtraction_icon"), for: .normal)
        subtractionBtn.addTarget(self, action: #selector(subtractionBtnClick), for: .touchUpInside)
        return subtractionBtn
    }()
    
    // 显示数量
    private lazy var goodsCountL: UILabel = {
        let goodsCountL = UILabel()
        goodsCountL.textAlignment = .center
        return goodsCountL
    }()
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        selectionStyle = .none
        
        setupUI()
        makeConstraints()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func makeConstraints() {
        
        selectBtn.snp.makeConstraints { (make) in
            make.left.equalTo(12)
            make.centerY.equalToSuperview()
            make.width.height.equalTo(14)
        }
        imgV.snp.makeConstraints { (make) in
            make.width.height.equalTo(100)
            make.left.equalTo(selectBtn.snp.right).offset(12)
            make.bottom.equalToSuperview()
        }
        titleL.snp.makeConstraints { (make) in
            make.left.equalTo(imgV.snp.right).offset(12)
            make.right.equalToSuperview().offset(-50)
        }
        descL.snp.makeConstraints { (make) in
            make.left.equalTo(titleL)
            make.top.equalTo(titleL.snp.bottom).offset(5)
            make.right.equalTo(titleL)
        }
        loveBtn.snp.makeConstraints { (make) in
            make.left.equalTo(titleL)
            make.bottom.equalToSuperview().offset(-10)
        }
        priceL.snp.makeConstraints { (make) in
            make.left.equalTo(titleL)
            make.bottom.equalTo(loveBtn.snp.top).offset(-6)
        }
        addAndsubtractionV.snp.makeConstraints { (make) in
            make.width.equalTo(71)
            make.height.equalTo(20)
            make.right.equalToSuperview().offset(-12)
            make.bottom.equalToSuperview().offset(-10)
        }
    }
    
    private func setupUI(){
        contentView.addSubview(selectBtn)
        contentView.addSubview(imgV)
        contentView.addSubview(titleL)
        contentView.addSubview(descL)
        contentView.addSubview(priceL)
        contentView.addSubview(loveBtn)
        contentView.addSubview(addAndsubtractionV)
        addAndsubtractionV.addSubview(addBtn)
        addAndsubtractionV.addSubview(goodsCountL)
        addAndsubtractionV.addSubview(subtractionBtn)
    }
    
    /// 商品模型赋值
    var goodsModel: GoodsCartModel? {
        didSet {
            selectBtn.isSelected = (goodsModel?.isSelect)!
            imgV.image = UIImage(named: (goodsModel?.image)!)
            titleL.text = goodsModel?.title
            descL.text = goodsModel?.desc
            priceL.text = "¥\(goodsModel!.price)"
            loveBtn.setTitle("+\(goodsModel!.love)", for: .normal)
        }
    }
}

extension CartCell {
    @objc private func selectBtnClick() {
        
    }
    @objc private func addBtnClick() {
        
    }
    @objc private func subtractionBtnClick() {
        
    }
}
