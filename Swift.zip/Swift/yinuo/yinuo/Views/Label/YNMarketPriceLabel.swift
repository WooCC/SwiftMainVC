//
//  YNMarketPriceLabel.swift
//  yinuo
//
//  Created by Tim on 2018/3/4.
//  Copyright © 2018年 yinuo. All rights reserved.
//  价格删除线

import UIKit

class YNMarketPriceLabel: UILabel {

    override func draw(_ rect: CGRect) {
        super.draw(rect)
        
        // 绘制中划线
        let ctx = UIGraphicsGetCurrentContext()
        ctx?.move(to: CGPoint(x: 0, y: rect.size.height * 0.5))
        ctx?.addLine(to: CGPoint(x: rect.size.width, y: rect.size.height * 0.5))
        ctx?.strokePath()
    }

}
