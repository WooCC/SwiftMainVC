//
//  RankingFooterView.swift
//  yinuo
//
//  Created by 谭锦添 on 2018/2/7.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit

class RankingFooterView: UIView {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        backgroundColor = UIColor.white
        
        let btn1 = RankingFooterButton()
        btn1.titleL.text = "爱心排行榜"
        btn1.subTitleL.text = "TOP 前200 >"
        btn1.setImage(UIImage(named: "rankingClass1"), for: .normal)
        btn1.addTarget(self, action: #selector(footBtn1Click), for: .touchUpInside)
        
        let btn2 = RankingFooterButton()
        btn2.titleL.text = "平台角色类型"
        btn2.subTitleL.text = "角色介绍 >"
        btn2.setImage(UIImage(named: "rankingClass2"), for: .normal)
        btn2.addTarget(self, action: #selector(footBtn2Click), for: .touchUpInside)
        
        let lineV = UIView()
        lineV.backgroundColor = UIColor.yinuoLineColor()
        
        addSubview(btn1)
        addSubview(btn2)
        addSubview(lineV)
        
        lineV.snp.makeConstraints { (make) in
            make.width.equalTo(0.5)
            make.centerX.equalToSuperview()
            make.top.equalToSuperview()
            make.bottom.equalToSuperview()
        }
        let btnW = SCREEN_WIDTH/2-10*2
        btn1.snp.makeConstraints { (make) in
            make.width.equalTo(btnW)
            make.height.equalTo(btnW/2)
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview().multipliedBy(0.5)
        }
        btn2.snp.makeConstraints { (make) in
            make.width.height.equalTo(btn1)
            make.centerX.equalToSuperview().multipliedBy(1.5)
            make.top.equalTo(btn1)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

extension RankingFooterView {
    @objc private func footBtn1Click() {
        println("foot btn1 click")
    }
    
    @objc private func footBtn2Click() {
        println("foot btn2 click")
    }
}
