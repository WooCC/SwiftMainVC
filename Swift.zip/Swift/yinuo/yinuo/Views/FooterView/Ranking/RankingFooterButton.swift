//
//  RankingFooterButton.swift
//  yinuo
//
//  Created by Tim on 2018/2/8.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit

class RankingFooterButton: UIButton {

    lazy var titleL = UILabel()
    lazy var subTitleL = UILabel()
    
    override var adjustsImageWhenHighlighted: Bool {
        get{
            return false
        }
        set{}
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setUI(){
        
        titleL.font = UIFont.systemFont(ofSize: 15.0)
        titleL.textColor = UIColor.white
        subTitleL.font = UIFont.systemFont(ofSize: 12.0)
        subTitleL.textColor = UIColor.white
    
        addSubview(titleL)
        addSubview(subTitleL)
        
        titleL.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
//            make.top.equalToSuperview().offset(26)
            make.centerY.equalToSuperview().offset(-10)
        }
        
        subTitleL.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
//            make.top.equalTo(titleL.snp.bottom).offset(10)
            make.centerY.equalToSuperview().offset(8)
        }
    }
    
    
   

}
