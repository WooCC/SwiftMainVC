//
//  YINupDescriTextView.swift
//  yinuo
//
//  Created by 吴承炽 on 2018/3/22.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit

class YINupDescriTextView: UIView {
    
//    var delegate : YiNuoTitleInputIconTextFieldDelegate?
    
    let leftInset: CGFloat = 20    // 左边距
    let rightInset: CGFloat = 20   // 右边距
    let marginInset : CGFloat = 5  // 内部间距
    let iconWidth : CGFloat = 80  // 右侧图标宽度
    let iconHeight : CGFloat = 50 // 右侧图标高度
    let viewHeight: CGFloat = 50  // 组件高度
    let titleWidth : CGFloat = 100 // 标题宽度

    public lazy var inputTextView = { () -> UITextView in
        let textView = UITextView()
        textView.font = UIFont.systemFont(ofSize: 16.0)
        textView.textColor = UIColor.black
        textView.layer.borderColor = UIColor.lightGray.cgColor
        textView.layer.borderWidth = 1
        return textView
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.frame.size.height = viewHeight
        
        setUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setUI() {
        self.backgroundColor = UIColor.white
        
        self.addSubview(inputTextView)

        inputTextView.snp.makeConstraints { (make) in
            make.left.equalTo(leftInset)
            make.right.equalTo(-leftInset)
            make.top.equalTo(leftInset)
            make.bottom.equalTo(-leftInset)
        }
        
    }
    
    func setContent(text : String) {
        inputTextView.text = text
    }

}


