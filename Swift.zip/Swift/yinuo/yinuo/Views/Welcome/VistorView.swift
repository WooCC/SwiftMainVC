//
//  VistorView.swift
//  yinuo
//
//  Created by Tim on 2018/1/11.
//  Copyright © 2018年 yinuo. All rights reserved.
//  访客视图

import UIKit

class VistorView: UIView {
    
    // xib创建布局界面
    class func vistorView() ->VistorView {
        return Bundle.main.loadNibNamed("VistorView", owner: nil, options: nil)!.first as! VistorView
    }
    
    // MARK:- 控件的属性
    @IBOutlet weak var iconView: UIImageView!   // 图标
    @IBOutlet weak var tipLabel: UILabel!       // 提示文字
    @IBOutlet weak var loginBtn: UIButton!      // 登录按钮
    
    
    // MARK:- 自定义函数
    func setupVistorViewInfo(iconName : String, title : String){
        iconView.image = UIImage(named: iconName)
        tipLabel.text = title
    }
    

}
