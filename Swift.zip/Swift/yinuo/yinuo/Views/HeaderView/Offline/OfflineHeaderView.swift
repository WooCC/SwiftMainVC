//
//  OfflineHeaderView.swift
//  yinuo
//
//  Created by Tim on 2018/1/21.
//  Copyright © 2018年 yinuo. All rights reserved.
//  线下-头部

import UIKit
import SDCycleScrollView

class OfflineHeaderView: UIView {

    // 轮播
    private lazy var sliderView = { () -> SDCycleScrollView in
        let sliderView = SDCycleScrollView()
        sliderView.imageURLStringsGroup = ["homeSlider", "homeSlider","homeSlider"]
        sliderView.currentPageDotColor = UIColor.yinuoTopicColor()
        sliderView.pageDotColor = UIColor.white
        return sliderView
    }()
    
    // 菜单
    private lazy var menuView = { () -> UICollectionView in
        let menuRect = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 140)
        let menuView = OfflineMenuView(frame: menuRect, collectionViewLayout: OfflineMenuLayout())
        return menuView
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        let sliderViewH = 134
        let menuViewH = 140
        let headerViewH = sliderViewH + menuViewH
        
        bounds = CGRect(x: 0, y: 0, width: 0, height: headerViewH)
        addSubview(sliderView)
        addSubview(menuView)
        
        sliderView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(sliderViewH)
        }
        menuView.snp.makeConstraints { (make) in
            make.top.equalTo(sliderView.snp.bottom)
            make.left.right.equalToSuperview()
            make.height.equalTo(menuViewH)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    

}
