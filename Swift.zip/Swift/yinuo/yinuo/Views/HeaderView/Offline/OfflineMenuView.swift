//
//  OfflineMenuView.swift
//  yinuo
//
//  Created by Tim on 2018/1/21.
//  Copyright © 2018年 yinuo. All rights reserved.
//  线下-菜单

import UIKit

class OfflineMenuView: UICollectionView {

    private lazy var menuImgArr  = { () -> [String] in
        let menuNames = ["美食", "百货", "生活", "娱乐", "旅游", "服装", "酒店", "数码", "教育", "全部分类"]
        return menuNames
    }()
    
    override init(frame: CGRect, collectionViewLayout layout: UICollectionViewLayout) {
        super.init(frame: frame, collectionViewLayout: layout)
        
        backgroundColor = UIColor.white
        delegate = self
        dataSource = self
        showsHorizontalScrollIndicator = false
        register(UINib.init(nibName: "OfflineMenuViewCell", bundle: nil), forCellWithReuseIdentifier: "OfflineMenuCell")
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}

extension OfflineMenuView : UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    // DataSource
    //返回多少个cell
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 10;
    }
    //返回自定义的cell
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "OfflineMenuCell", for: indexPath) as! OfflineMenuViewCell
        cell.menuImgV.image = UIImage(named: "menu" + "\(indexPath.row + 1)")
        cell.menuTitleL.text = menuImgArr[indexPath.row]
        return cell
    }
    
    // Delegate
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        println("点击了" + menuImgArr[indexPath.row])
    }
    
    // cell左右间距
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
}
