//
//  OfflineMenuLayout.swift
//  yinuo
//
//  Created by Tim on 2018/1/21.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit

class OfflineMenuLayout: UICollectionViewFlowLayout {
    
    override init() {
        super.init()
        
        let itemW = UIScreen.main.bounds.width / 5
        itemSize = CGSize(width: itemW, height: 70)
        //设置最小间距
        minimumLineSpacing = 0
        minimumInteritemSpacing = 0
        scrollDirection = .horizontal
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
