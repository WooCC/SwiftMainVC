//
//  RankingHeaderView.swift
//  yinuo
//
//  Created by Tim on 2018/2/7.
//  Copyright © 2018年 yinuo. All rights reserved.
//  排行榜头部

import UIKit

class RankingHeaderView: UIView {

    
    private lazy var bgImgV = UIImageView()
    private lazy var shopsTitleBtn = UIButton()
    private lazy var shopsNumL = UILabel()
    private lazy var seedTitleBtn = UIButton()
    private lazy var seedNumL = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        bgImgV.image = UIImage(named: "rankingBg")
        shopsTitleBtn.setTitle("功德商家", for: .normal)
        shopsTitleBtn.titleLabel?.textColor = UIColor.white
        shopsTitleBtn.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        shopsNumL.text = "27897"
        shopsNumL.textColor = UIColor.white
        shopsNumL.font = UIFont.systemFont(ofSize: 14)
        seedTitleBtn.setTitle("爱心种子", for: .normal)
        seedTitleBtn.titleLabel?.textColor = UIColor.white
        seedTitleBtn.titleLabel?.font = UIFont.systemFont(ofSize: 20)
        seedNumL.text = "1234322"
        seedNumL.textColor = UIColor.white
        seedNumL.font = UIFont.systemFont(ofSize: 14)
        
        addSubview(bgImgV)
        addSubview(shopsTitleBtn)
        addSubview(shopsNumL)
        addSubview(seedTitleBtn)
        addSubview(seedNumL)
        
        bgImgV.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(155)
        }
        shopsTitleBtn.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(78)
            make.centerX.equalToSuperview().multipliedBy(0.5)
        }
        shopsNumL.snp.makeConstraints { (make) in
            make.top.equalTo(shopsTitleBtn.snp.bottom).offset(11)
            make.centerX.equalTo(shopsTitleBtn)
        }
        seedTitleBtn.snp.makeConstraints { (make) in
            make.top.equalTo(shopsTitleBtn)
            make.centerX.equalToSuperview().multipliedBy(1.5)
        }
        seedNumL.snp.makeConstraints { (make) in
            make.top.equalTo(shopsNumL)
            make.centerX.equalTo(seedTitleBtn)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
