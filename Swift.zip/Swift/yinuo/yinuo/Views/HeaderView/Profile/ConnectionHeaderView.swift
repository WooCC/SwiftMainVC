//
//  ConnectionHeaderView.swift
//  yinuo
//
//  Created by tim on 2018/3/19.
//  Copyright © 2018年 yinuo. All rights reserved.
//  我的人脉

import UIKit

// 定义闭包
typealias ConnectionReturnBlock = (_ tag: Int) -> Void

class ConnectionHeaderView: UIView {
    
    var resultRespontBlock: ConnectionReturnBlock?

    private lazy var headerBgImgV: UIImageView = {
        let headerBgImgV = UIImageView()
        headerBgImgV.image = UIImage(named: "connection_bg")
        
        return headerBgImgV
    }()
    private lazy var title1L: UILabel = {
        let title1L = UILabel()
        title1L.text = "一度人脉"
        title1L.textColor = UIColor.yinuoTextColor()
        title1L.font = UIFont.systemFont(ofSize: 23.0)
        return title1L
    }()
    private lazy var title2L: UILabel = {
        let title2L = UILabel()
        title2L.text = "二度人脉"
        title2L.textColor = UIColor.yinuoTextColor()
        title2L.font = UIFont.systemFont(ofSize: 23.0)
        return title2L
    }()
    private lazy var oneBtn: UIButton = {
        let oneBtn = UIButton()
        oneBtn.adjustsImageWhenHighlighted = false
        oneBtn.tag = 1
        oneBtn.setImage(UIImage(named: "collection_icon1"), for: .normal)
        oneBtn.addTarget(self, action: #selector(btnClick(_:)), for: .touchUpInside)
        
        return oneBtn
    }()
    private lazy var twoBtn: UIButton = {
        let twoBtn = UIButton()
        twoBtn.adjustsImageWhenHighlighted = false
        twoBtn.tag = 2
        twoBtn.setImage(UIImage(named: "collection_icon2"), for: .normal)
        twoBtn.addTarget(self, action: #selector(btnClick(_:)), for: .touchUpInside)
        return twoBtn
    }()
    var num1L: UILabel = {
        let num1L = UILabel()
        num1L.textColor = UIColor.yinuoTextRedColor()
        num1L.font = UIFont.systemFont(ofSize: 18.0)
        return num1L
    }()
    var num2L: UILabel = {
        let num2L = UILabel()
        num2L.textColor = UIColor.yinuoTextRedColor()
        num2L.font = UIFont.systemFont(ofSize: 18.0)
        return num2L
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupUI() {
        
        addSubview(headerBgImgV)
        addSubview(title1L)
        addSubview(title2L)
        addSubview(oneBtn)
        addSubview(twoBtn)
        addSubview(num1L)
        addSubview(num2L)
        
        headerBgImgV.snp.makeConstraints { (make) in
            make.left.right.top.equalToSuperview()
            make.height.equalTo(170)
        }
        title1L.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview().multipliedBy(0.5)
            make.top.equalTo(25)
        }
        title2L.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview().multipliedBy(1.5)
            make.top.equalTo(title1L)
        }
        oneBtn.snp.makeConstraints { (make) in
            make.centerX.equalTo(title1L)
            make.top.equalTo(title1L.snp.bottom).offset(14)
        }
        twoBtn.snp.makeConstraints { (make) in
            make.centerX.equalTo(title2L)
            make.bottom.equalTo(oneBtn.snp.bottom)
        }
        num1L.snp.makeConstraints { (make) in
            make.centerX.equalTo(title1L)
            make.top.equalTo(oneBtn.snp.bottom).offset(23)
        }
        num2L.snp.makeConstraints { (make) in
            make.centerX.equalTo(title2L)
            make.top.equalTo(num1L)
        }
    }
    
    
    @objc private func btnClick(_ button: UIButton) {
        guard let postValueBlock = self.resultRespontBlock else { return }
        postValueBlock(button.tag)
        
    }

}
