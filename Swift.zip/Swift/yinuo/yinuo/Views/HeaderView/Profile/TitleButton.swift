//
//  TitleButton.swift
//  yinuo
//
//  Created by tim on 2018/2/28.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit

class TitleButton: UIButton {

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        titleLabel?.font = UIFont.systemFont(ofSize: 17.0)
        setTitleColor(UIColor.yinuoTextRedColor(), for: .normal)
        setTitleColor(UIColor.yinuoSubmitColor(), for: .selected)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // 处理按钮长按时，选中与高亮同时存在时，状态变回nomal状态
    override var isHighlighted: Bool {
        set{
            
        }
        get {
            return false
        }
    }

}
