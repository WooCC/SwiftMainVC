//
//  ProfileMenuView.swift
//  yinuo
//
//  Created by tim on 2018/2/26.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit

class ProfileMenuView: UIView {

    private lazy var titleL = UILabel()
    private lazy var lineV = UIView()
    private lazy var menuV = UIView()
    private let lineBtnNum  = 4                // 每行按钮个数
    private let btnWH: CGFloat = 39.0       // 按钮宽高
    private let marginL: CGFloat = 36.0     // 第一个按钮的左边距
    private let marginT: CGFloat = 15.0     // 第一个按钮的上边距
    private let spaceH: CGFloat = 20.0      // 按钮间的竖间距
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        titleL.text = "功能菜单"
        titleL.textColor = UIColor.black
        titleL.font = UIFont.systemFont(ofSize: 14.0)
        
        lineV.backgroundColor = UIColor.yinuoLineColor()
        
//        menuV.backgroundColor = UIColor.red
        
        addSubview(titleL)
        addSubview(lineV)
        addSubview(menuV)
        
        titleL.snp.makeConstraints { (make) in
            make.top.equalTo(11)
            make.left.equalTo(10)
        }
        lineV.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalTo(titleL.snp.bottom)
            make.height.equalTo(1)
        }
        menuV.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalTo(lineV.snp.bottom)
            make.height.equalTo(marginT * 2 + btnWH * 3 + spaceH * (3-1))
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}


