//
//  RecommendView.swift
//  yinuo
//
//  Created by Tim on 2018/1/20.
//  Copyright © 2018年 yinuo. All rights reserved.
//  推荐商品(每日精选/好物馆)

import UIKit

class RecommendView: UIView {
    

}

extension RecommendView {
    // 快速创建的类方法
    static func customView() -> RecommendView {
        return Bundle.main.loadNibNamed("RecommendView", owner: nil, options: nil)?.first as! RecommendView
    }
}

extension RecommendView {
    @IBAction func recommendClick(_ sender: UIButton) {
        if sender.tag == 11 {
            println("r1 click")
        }else if sender.tag == 12 {
            println("r2 click")
        }
    }
}


