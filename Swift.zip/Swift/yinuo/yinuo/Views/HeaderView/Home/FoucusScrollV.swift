//
//  FoucusScrollV.swift
//  yinuo
//
//  Created by Tim on 2018/1/16.
//  Copyright © 2018年 yinuo. All rights reserved.
//  头条滚动区

import UIKit

class FoucusScrollV: UIScrollView {
    

    var hotTitleL : UILabel?
    var bestTitleL : UILabel?
    var hotL : UILabel?
    var bestL : UILabel?
    var bgImgV : UIImageView?

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        hotTitleL = UILabel()
        hotTitleL?.text = "热点"
        hotTitleL?.font = UIFont.systemFont(ofSize: 10.0)
        hotTitleL?.textColor = UIColor.yinuoTextColor()
        hotTitleL?.layer.borderColor = UIColor.yinuoTextColor().cgColor
        hotTitleL?.layer.borderWidth = 1
        hotTitleL?.layer.cornerRadius = 3
        hotTitleL?.textAlignment = .center
        
        bestTitleL = UILabel()
        bestTitleL?.text = "精选"
        bestTitleL?.font = UIFont.systemFont(ofSize: 10.0)
        bestTitleL?.textColor = UIColor.yinuoTextColor()
        bestTitleL?.layer.borderColor = UIColor.yinuoTextColor().cgColor
        bestTitleL?.layer.borderWidth = 1
        bestTitleL?.layer.cornerRadius = 3
        bestTitleL?.textAlignment = .center
        
        hotL = UILabel()
        hotL?.text = "一诺商城在感恩节正式开业了，欢迎欢迎欢迎欢迎欢迎欢迎欢迎欢迎"
        hotL?.textColor = UIColor.yinuoTextGrayColor()
        hotL?.font = UIFont.systemFont(ofSize: 10.0)
        bestL = UILabel()
        bestL?.text = "一诺商城在感恩节正式开业了，欢迎..."
        bestL?.textColor = UIColor.yinuoTextGrayColor()
        bestL?.font = UIFont.systemFont(ofSize: 10.0)
        
        bgImgV = UIImageView(image: UIImage(named: "foucusBg"))
        bgImgV?.contentMode = .right
        
        addSubview(bgImgV!)
        addSubview(hotTitleL!)
        addSubview(bestTitleL!)
        addSubview(hotL!)
        addSubview(bestL!)
        
        
        hotTitleL?.snp.makeConstraints({ (make) in
            make.width.equalTo(25)
            make.height.equalTo(15)
            make.left.equalTo(10)
            make.top.equalToSuperview().offset(5)
        })
        bestTitleL?.snp.makeConstraints({ (make) in
            make.left.width.height.equalTo(hotTitleL!)
            make.top.equalTo(hotTitleL!.snp.bottom).offset(5)
        })
        hotL?.snp.makeConstraints({ (make) in
            make.left.equalTo(hotTitleL!.snp.right).offset(10)
            make.centerY.equalTo(hotTitleL!)
            make.width.equalTo(190)
        })
        bestL?.snp.makeConstraints({ (make) in
            make.left.equalTo(hotL!)
            make.centerY.equalTo(bestTitleL!)
            make.width.equalTo(hotL!)
        })
        bgImgV?.snp.makeConstraints({ (make) in
            make.width.height.top.left.equalToSuperview()
//            make.width.equalToSuperview()
        })
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
