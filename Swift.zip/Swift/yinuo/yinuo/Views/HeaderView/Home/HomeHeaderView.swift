//
//  HomeHeaderView.swift
//  yinuo
//
//  Created by Tim on 2018/1/20.
//  Copyright © 2018年 yinuo. All rights reserved.
//  首页TableView头部

import UIKit


// 定义闭包
typealias HomeHeaderReturnBlock = (_ index: Int) -> Void

class HomeHeaderView: UIView {
    
    var resultRespontBlock: HomeHeaderReturnBlock?
    
    // 轮播
//    private lazy var sliderView = { () -> SDCycleScrollView in
//        let sliderView = SDCycleScrollView()
//        sliderView.imageURLStringsGroup = ["homeSlider", "homeSlider","homeSlider"]
//        sliderView.currentPageDotColor = UIColor.yinuoTopicColor()
//        sliderView.pageDotColor = UIColor.white
//        return sliderView
//    }()
    
    // 菜单
//    private lazy var menuView = { () -> UICollectionView in
//        let menuRect = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.width, height: 89)
//        let menuView = MenuView(frame: menuRect, collectionViewLayout: MenuLayout())
//
//        menuView.resultRespontBlock = { selectIndex in
//
//
//            guard let postValueBlock = self.resultRespontBlock else { return }
//            postValueBlock(selectIndex)
//        }
//
//
//        return menuView
//    }()
    
    // 文字广告
//    private lazy var textAdView = { () -> UIView in
//        let textAdView = TextAdView()
//        return textAdView
//    }()
//    
//    // 推荐
//    private lazy var recommendView = { () -> UIView in
//        let recommendView = RecommendView.customView()
//        return recommendView
//    }()
//    
//    // 口碑好店
//    private lazy var shopView = { () -> UIView in
//        return ShopView()
//    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        let sliderViewH = 135
        let menuViewH = 89
        let topMargin = 8
        let textAdViewH = 45
        let recommendViewH = 115
        let shopViewH = 22 + 135 // 标题22+ cell高135
        let headerViewH = sliderViewH + topMargin + menuViewH + topMargin + textAdViewH + recommendViewH + shopViewH
        
//        bounds = CGRect(x: 0, y: 0, width: 0, height: headerViewH)
//        addSubview(sliderView)
//        addSubview(menuView)
//        addSubview(textAdView)
//        addSubview(recommendView)
//        addSubview(shopView)
//
//        sliderView.snp.makeConstraints { (make) in
//            make.top.left.right.equalToSuperview()
//            make.height.equalTo(sliderViewH)
//        }
//        menuView.snp.makeConstraints { (make) in
//            make.top.equalTo(sliderView.snp.bottom).offset(topMargin)
//            make.left.right.equalToSuperview()
//            make.height.equalTo(menuViewH)
//        }
//
//        textAdView.snp.makeConstraints { (make) in
//            make.top.equalTo(menuView.snp.bottom).offset(topMargin)
//            make.left.right.equalToSuperview()
//            make.height.equalTo(textAdViewH)
//        }
//        recommendView.snp.makeConstraints { (make) in
//            make.top.equalTo(textAdView.snp.bottom).offset(topMargin)
//            make.left.right.equalToSuperview()
//            make.height.equalTo(recommendViewH)
//        }
//        shopView.snp.makeConstraints { (make) in
//            make.top.equalTo(recommendView.snp.bottom)
//            make.left.right.equalToSuperview()
//            make.height.equalTo(shopViewH)
//        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
}
