//
//  YiNuoTitleInputIconTextField.swift
//  yinuo
//
//  Created by Rayco on 2018/2/7.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit

class YiNuoTitleInputIconTextField: UIView {
    
    var delegate : YiNuoTitleInputIconTextFieldDelegate?
    
    let leftInset: CGFloat = 10    // 左边距
    let rightInset: CGFloat = 10   // 右边距
    let marginInset : CGFloat = 5  // 内部间距
    let iconWidth : CGFloat = 80  // 右侧图标宽度
    let iconHeight : CGFloat = 50 // 右侧图标高度
    let viewHeight: CGFloat = 50  // 组件高度
    let titleWidth : CGFloat = 100 // 标题宽度
    
    private lazy var titleLabel = { () -> UILabel in
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16.0)
        label.textColor = UIColor.black
        label.textAlignment = .left
        label.backgroundColor = UIColor.clear
        label.numberOfLines = 2
        return label
    }()
    
    public lazy var inputTextField = { () -> UITextField in
        let textField = UITextField()
        textField.font = UIFont.systemFont(ofSize: 16.0)
        textField.textColor = UIColor.black
        return textField
    }()
    
    private lazy var iconButton = { () -> UIButton in
        let button = UIButton(type: .custom)
        return button
    }()
    
    private lazy var touchButton = { () -> UIButton in
        let button = UIButton(type: .custom)
        return button
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.frame.size.height = viewHeight
        
        setUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setUI() {
        self.backgroundColor = UIColor.white
        
        self.addSubview(titleLabel)
        self.addSubview(inputTextField)
        self.addSubview(iconButton)
        self.addSubview(touchButton)
        
        touchButton.isHidden = true
        
        touchButton.snp.makeConstraints { (make) in
            make.width.equalToSuperview()
            make.height.equalTo(viewHeight)
            make.left.right.equalTo(0)
            make.top.bottom.equalTo(0)
        }
        titleLabel.snp.makeConstraints { (make) in
            make.height.equalTo(viewHeight)
            make.width.equalTo(titleWidth)
            make.left.equalTo(leftInset)
            make.top.bottom.equalTo(0)
        }
        iconButton.snp.makeConstraints { (make) in
            make.height.equalTo(iconHeight)
            make.width.equalTo(iconWidth)
            make.right.equalToSuperview().offset(0)
            make.centerY.equalToSuperview()
        }
        inputTextField.snp.makeConstraints { (make) in
            make.height.equalTo(viewHeight)
            make.left.equalTo(titleLabel.snp.right).offset(marginInset)
            make.right.equalTo(iconButton.snp.left).offset(-marginInset)
            make.top.bottom.equalTo(0)
        }
        
        iconButton.addTarget(self, action:#selector(iconButtonAction(sender:)), for:.touchUpInside)
        
    }
    
    func setTitle(text : String) {
        titleLabel.text = text
    }
    
    func setPlaceholder(text : String) {
        inputTextField.placeholder = text
    }
    
    func setContent(text : String) {
        inputTextField.text = text
    }
    
    func getContent() -> String? {
        return inputTextField.text
    }
    
    func isIconShowing() -> Bool {
        return !iconButton.isHidden
    }
    
    func showIcon(show : Bool) {
        iconButton.isHidden = !show
        
        if show {
            inputTextField.snp.makeConstraints { (make) in
                make.height.equalTo(viewHeight)
                make.left.equalTo(titleLabel.snp.right).offset(marginInset)
                make.right.equalTo(iconButton.snp.left).offset(-marginInset)
                make.top.bottom.equalTo(0)
            }
        } else {
            inputTextField.snp.makeConstraints { (make) in
                make.height.equalTo(viewHeight)
                make.left.equalTo(titleLabel.snp.right).offset(marginInset)
                make.right.equalToSuperview().offset(rightInset)
                make.top.bottom.equalTo(0)
            }
        }
    }
    
    func setIcon(image : UIImage) {
        iconButton.setImage(image, for: .normal)
    }
    
    func setIcon(image : UIImage, state: UIControlState) {
        iconButton.setImage(image, for: state)
    }
    
    func isIconSelected() -> Bool {
        return iconButton.isSelected
    }
    
    func setIconSelected(selected : Bool) {
        iconButton.isSelected = selected
    }
    
    func setIconSize(size : CGSize, margin: CGFloat) {
        iconButton.snp.makeConstraints { (make) in
            make.height.equalTo(size.height)
            make.width.equalTo(size.width)
            make.right.equalToSuperview().offset(-margin)
            make.centerY.equalToSuperview()
        }
    }
    
    func setEnableInput(enable: Bool) {
        inputTextField.isEnabled = enable
    }
    
    func setContentColor(color : UIColor) {
        inputTextField.textColor = color
    }
    
    @objc func iconButtonAction(sender : UIButton?) {
       println("==点击了图标==")
        
        if (delegate != nil) {
            delegate?.iconDidClick(view : self)
        }
    }
    
    open func addIconTarget(_ target: Any?, action: Selector, for controlEvents: UIControlEvents) {
        iconButton.addTarget(target, action:action, for:controlEvents)
    }
    
    open func addTarget(_ target: Any?, action: Selector, for controlEvents: UIControlEvents) {
        touchButton.isHidden = false
        touchButton.addTarget(target, action:action, for:controlEvents)
    }
}

protocol YiNuoTitleInputIconTextFieldDelegate {
    func iconDidClick(view : UIView)
}
