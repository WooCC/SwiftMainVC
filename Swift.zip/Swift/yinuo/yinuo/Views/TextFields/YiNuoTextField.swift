//
//  YiNuoTextField.swift
//  yinuo
//
//  Created by 谭锦添 on 2018/2/7.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit

class YiNuoTextField: UITextField {
    
    var leftInset: CGFloat = 0                               // 左边距
    var rightInset: CGFloat = 0                              // 右边距
    private var clearBtnWH: CGFloat = 16
    
    
    override func textRect(forBounds bounds: CGRect) -> CGRect {
        return CGRect(x: leftInset, y: 0, width: bounds.width - (leftInset + rightInset + clearBtnWH), height: bounds.height)
    }
    
    override func editingRect(forBounds bounds: CGRect) -> CGRect {
        return textRect(forBounds: bounds)
    }
    
    override func clearButtonRect(forBounds bounds: CGRect) -> CGRect {
        return CGRect(x: bounds.width - (rightInset + clearBtnWH), y: (bounds.height - clearBtnWH)/2, width: clearBtnWH, height: clearBtnWH)
    }
}
