//
//  UnderLineTextField.swift
//  yinuo
//
//  Created by Tim on 2018/1/26.
//  Copyright © 2018年 yinuo. All rights reserved.
//  带下划线输入框

import UIKit

@IBDesignable
final class UnderLineTextField: YiNuoTextField {
    
    @IBInspectable var underLineColor: UIColor = UIColor.yinuoLineColor()   // 下划线颜色
    @IBInspectable var underLineWidth: CGFloat = 0.65
    
    lazy var underlineLayer: CAShapeLayer = {
        let layer = CAShapeLayer()
        layer.lineWidth = self.underLineWidth
        layer.strokeColor = self.underLineColor.cgColor
        return layer
    }()
    
    override func didMoveToSuperview() {
        super.didMoveToSuperview()
        
        backgroundColor = UIColor.clear
        layer.addSublayer(underlineLayer)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        let path = UIBezierPath()
        path.move(to: CGPoint(x: 0, y: bounds.height))
        path.addLine(to: CGPoint(x: bounds.width, y: bounds.height))
        
        underlineLayer.path = path.cgPath
    }
    
}
