//
//  YiNuoJustInputTextField.swift
//  yinuo
//
//  Created by Rayco on 2018/2/7.
//  Copyright © 2018年 yinuo. All rights reserved.
//  白色背景的文本输入框

import UIKit

class YiNuoJustInputTextField: UIView {
    
    let leftInset: CGFloat = 10    // 左边距
    let rightInset: CGFloat = 10   // 右边距
    let viewHeight: CGFloat = 50  // 组件高度

    private lazy var inputTextField = { () -> UITextField in
        let textField = UITextField()
        textField.font = UIFont.systemFont(ofSize: 16.0)
        textField.textColor = UIColor.black
        return textField
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.frame.size.height = viewHeight
        
        setUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setUI() {
        self.backgroundColor = UIColor.white
        
        self.addSubview(inputTextField)
 
        inputTextField.snp.makeConstraints { (make) in
            make.height.equalTo(viewHeight)
            make.left.equalTo(leftInset)
            make.right.equalTo(rightInset)
            make.top.bottom.equalTo(0)
        }
    }
    
    func setPlaceholder(text : String) {
        inputTextField.placeholder = text
    }
    
    func setContent(text : String) {
        inputTextField.text = text
    }
    
    func getContent() -> String? {
        return inputTextField.text
    }
   
}
