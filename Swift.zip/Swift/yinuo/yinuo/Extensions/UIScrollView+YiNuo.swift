//
//  UIScrollView+YiNuo.swift
//  yinuo
//
//  Created by tim on 2018/3/8.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit

extension UIScrollView {
    
    // 返回顶部
    public func scrollToTop() {
        if let tableView = self as? UITableView,
            tableView.numberOfSections > 0 && tableView.numberOfRows(inSection: 0) > 0 {
            
            tableView.scrollToRow(at: .init(row: 0, section: 0), at: .top, animated: true)
        } else {
            self.setContentOffset(CGPoint(x: 0.0, y: -self.contentInset.top), animated: true)
        }
    }
}
