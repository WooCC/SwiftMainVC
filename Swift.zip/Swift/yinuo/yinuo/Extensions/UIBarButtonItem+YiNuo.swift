//
//  UIBarButtonItem+YiNuo.swift
//  yinuo
//
//  Created by Tim on 2018/1/11.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit

extension UIBarButtonItem {
    // 便利构造函数
    convenience init(imageName : String) {
        
        let btn = UIButton()
        btn.setImage(UIImage(named: imageName), for: .normal)
        btn.sizeToFit()
        
        self.init(customView: btn)
    }
}
