//
//  UIDevice+YiNuo.swift
//  yinuo
//
//  Created by Tim on 2018/1/26.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import Foundation
import DeviceKit

extension UIDevice {
    var isIphoneX:Bool {
        get {
            let device = Device()
            if device.isOneOf([.iPhoneX, Device.simulator(.iPhoneX)]) {
                return true
            }
            return false
        }
    }
}
