//
//  UICollectionView+YiNuo.swift
//  yinuo
//
//  Created by Tim on 2018/1/26.
//  Copyright © 2018年 yinuo. All rights reserved.
//  泛型优化重用ID(直接使用类名作为重用标示符)

import UIKit

extension UICollectionView {
    
    // 注册cell
    func registerClassOf<T: UICollectionViewCell>(_: T.Type) {
        register(T.self, forCellWithReuseIdentifier: T.yinuo_reuseIdentifier)
    }
    
    // 注册header
    func registerHeaderClassOf<T: UICollectionReusableView>(_: T.Type) {
        register(T.self, forSupplementaryViewOfKind: UICollectionElementKindSectionHeader, withReuseIdentifier: T.yinuo_reuseIdentifier)
    }
    
    // 注册footer
    func registerFooterClassOf<T: UICollectionReusableView>(_: T.Type) {
        register(T.self, forSupplementaryViewOfKind: UICollectionElementKindSectionFooter, withReuseIdentifier: T.yinuo_reuseIdentifier)
    }
    
    // xib方式注册cell
    func registerNibOf<T: UICollectionViewCell>(_: T.Type) {
        let nib = UINib(nibName: T.yinuo_nibName, bundle: nil)
        register(nib, forCellWithReuseIdentifier: T.yinuo_reuseIdentifier)
    }
    
    // xib方式注册header
    func registerHeaderNibOf<T: UICollectionReusableView>(_: T.Type) {
        let nib = UINib(nibName: T.yinuo_nibName, bundle: nil)
        register(nib, forSupplementaryViewOfKind: UICollectionElementKindSectionHeader, withReuseIdentifier: T.yinuo_reuseIdentifier)
    }
    
    // 获取cell
    func dequeueReusableCell<T: UICollectionViewCell>(forIndexPath indexPath: IndexPath) -> T {
        guard let cell = dequeueReusableCell(withReuseIdentifier: T.yinuo_reuseIdentifier, for: indexPath) as? T else {
            fatalError("获取Cell失败,ID: \(T.yinuo_reuseIdentifier)")
        }
        
        return cell
    }
    
    // 获取段头段尾
    func dequeueReusableSupplementaryView<T: UICollectionReusableView>(ofKind kind: String, forIndexPath indexPath: IndexPath) -> T {
        guard let view = dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: T.yinuo_reuseIdentifier, for: indexPath) as? T else {
            fatalError("获取头/尾示图失败,ID: \(T.yinuo_reuseIdentifier), 类型: \(kind)")
        }
        
        return view
    }
}
