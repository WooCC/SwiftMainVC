//
//  UIFont+YiNuo.swift
//  yinuo
//
//  Created by Tim on 2018/1/26.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit

extension UIFont {
    
    class func homeTextFont() -> UIFont {
        return UIFont.systemFont(ofSize: 16)
    }
    
    class func homeHeaderFont() -> UIFont {
        return UIFont.systemFont(ofSize: 17)
    }
    
    class func homeHeaderMenuLabelsFont() -> UIFont {
        return UIFont.systemFont(ofSize: 14)
    }
    
    class func homeTimeFont() -> UIFont {
        return UIFont.systemFont(ofSize: 12)
    }
}

extension UIFont {
    
    class func offlineTextFont() -> UIFont {
        return UIFont.systemFont(ofSize: 11)
    }
    
    class func offlineButtonFont() -> UIFont {
        return UIFont.systemFont(ofSize: 16)
    }
}

extension UIFont {
    class func barButtonFont() -> UIFont {
        return UIFont.systemFont(ofSize: 14)
    }
    
    class func navigationBarTitleFont() -> UIFont {
        return UIFont.boldSystemFont(ofSize: 17)
    }
}
