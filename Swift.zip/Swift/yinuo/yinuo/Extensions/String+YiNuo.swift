//
//  String+YiNuo.swift
//  yinuo
//
//  Created by Tim on 2018/1/26.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import Foundation

extension String {
    
    enum TrimmingType {
        case Whitespace // 空格
        case WhitespaceAndNewline // 空格和换行
    }
    
    // 删除两端的特殊符号
    func yinuo_trimming(trimmingType: TrimmingType) -> String {
        switch trimmingType {
        case .Whitespace:
            return trimmingCharacters(in: .whitespaces)
        case .WhitespaceAndNewline:
            return trimmingCharacters(in: .whitespacesAndNewlines)
        }
    }
    
    // 删除所有空格
    var yinuo_removeAllWhitespaces: String {
        return self.replacingOccurrences(of: " ", with: "") //字符串替换，后者替换前者
    }
    
    // 删除所有换行
    var yinuo_removeAllNewLines: String {
        return self.components(separatedBy: .newlines).joined(separator: "") // 字符串连接
    }
    
    // 截取
    func yinuo_truncate(length: Int, trailing: String? = nil) -> String {
        if self.count > length {
            return String(self[..<self.index(self.startIndex, offsetBy: length)]) + (trailing ?? "")
        } else {
            return self
        }
    }
    
}
