//
//  String+Trans.swift
//  yinuo
//
//  Created by Tim on 2018/1/26.
//  Copyright © 2018年 yinuo. All rights reserved.
//  国际化

import Foundation

extension String {
    
    static var trans_titleLogin: String {
        return NSLocalizedString("title.login", comment: "")
    }
    static var trans_titleSignUp: String {
        return NSLocalizedString("title.signup", comment: "")
    }
    static var trans_titleCart: String {
        return NSLocalizedString("title.cart", comment: "")
    }
    
    static var trans_titleProfile: String {
        return NSLocalizedString("title.profile", comment: "")
    }
    
    
    static var trans_Login: String {
        return NSLocalizedString("btn.login", comment: "")
    }
    static var trans_Logout: String {
        return NSLocalizedString("btn.logout", comment: "")
    }
    static var trans_Next: String {
        return NSLocalizedString("btn.next", comment: "")
    }
    
    static var trans_Submit: String {
        return NSLocalizedString("btn.submit", comment: "")
    }
    
}
