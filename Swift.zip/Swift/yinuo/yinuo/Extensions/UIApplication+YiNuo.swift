//
//  UIApplication+YiNuo.swift
//  yinuo
//
//  Created by Tim on 2018/1/26.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import Foundation

extension UIApplication {
    
    func yinuo_reviewOnTheAppStore() {
        
        let appID = "xxxxxx"
        
        guard let appURL = NSURL(string: "http://itunes.apple.com/?id=\(appID)") else {
            return
        }
        
        if canOpenURL(appURL as URL) {
            openURL(appURL as URL)
        }
    }
}
