//
//  UIView+YiNuo.swift
//  yinuo
//
//  Created by Tim on 2018/1/26.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import Foundation

extension UIView {
    
    /// 宽度
    var yinuo_width: CGFloat {
        return frame.size.width
    }
    
    /// 高度
    var yinuo_height: CGFloat {
        return frame.size.height
    }
    
    /// Y
    var yinuo_X: CGFloat {
        set(newValue){
            frame.origin.x = newValue
        }get{
            return frame.origin.x
        }
    }
    
    /// Y
    var yinuo_Y: CGFloat {
        set(newValue){
            frame.origin.y = newValue
        }get{
            return frame.origin.y
        }
    }
    
    /// centerX
    var yinuo_centerX: CGFloat {
        return center.x
    }
    
    /// centerY
    var yinuo_centerY: CGFloat {
        return center.y
    }
    
    /// size
    var yinuo_size: CGSize {
        set(newValue){
            frame.size = newValue
        }get{
            return bounds.size
        }
    }
    
    /// 圆角半径
    var yinuo_cornerRadius: CGFloat {
        get{
            return 0.0
        }set(newValue){
            layer.masksToBounds = true;
            layer.cornerRadius = newValue;
        }
    }
    
    /// 阴影颜色
    func yinuo_shadow(color: UIColor, opacity: Float, offsetX: CGFloat, offsetY: CGFloat, radius: CGFloat) {
        layer.shadowColor = color.cgColor
        layer.shadowOpacity = opacity
        layer.shadowOffset = CGSize(width: offsetX, height: offsetY)
        layer.shadowRadius = radius
    }
    
    /// 设置阴影跟圆角
    func yinuo_shadowAndCorner(){
        layer.cornerRadius = 5
        yinuo_shadow(color: UIColor(white: 0, alpha: 0.25), opacity: 6, offsetX: 0, offsetY: 4, radius: 4)
    }
    
    
    /// 变量
    func yinuo_border(borderWidth: CGFloat, borderColor: UIColor) {
        layer.borderWidth = borderWidth
        layer.borderColor = borderColor.cgColor
    }
    
    /// 屏幕截图
    func yinuo_screenshot() -> UIImage? {
        
        UIGraphicsBeginImageContextWithOptions(self.bounds.size, true, 0);
        
        self.drawHierarchy(in: self.bounds, afterScreenUpdates: false);
        let snapshotImage = UIGraphicsGetImageFromCurrentImageContext();
        
        UIGraphicsEndImageContext();
        
        return snapshotImage;
    }
}
