//
//  UIColor+YiNuo.swift
//  yinuo
//
//  Created by Tim on 2018/1/11.
//  Copyright © 2018年 yinuo. All rights reserved.
//  颜色扩展

import UIKit


func colorWithRGB(r: CGFloat, g: CGFloat, b: CGFloat) -> UIColor {
    return UIColor(red: r/255.0, green: g/255.0, blue: b/255.0, alpha: 255)
}
func colorWithRGBA(r: CGFloat, g: CGFloat, b: CGFloat, a: CGFloat) -> UIColor {
    return UIColor(red: r/255.0, green: g/255.0, blue: b/255.0, alpha: a/255)
}

extension UIColor {
    
    // 导航背景色
    class func yinuoNavBarTintColor() -> UIColor {
        return colorWithRGB(r: 205, g: 0, b: 1)
    }
    
    // 导航标题字颜色
//    class func yinuoNavgationBarTitleColor() -> UIColor {
//        return UIColor(red: 0.247, green: 0.247, blue: 0.247, alpha: 1.0)
//    }
    
    // 示图背景色
    class func yinuoViewBackgroundColor() -> UIColor {
        return colorWithRGB(r: 244, g: 244, b: 244) // #F4F4F4
    }
    
    // 示图背景色(灰)
    class func yinuoViewBgGrapColor() -> UIColor {
        return colorWithRGB(r: 204, g: 204, b: 204) // #CCCCCC
    }
    
    // 主题颜色(红)
    class func yinuoTopicColor() -> UIColor {
        return colorWithRGB(r: 211, g: 0, b: 0)     // #D30000
    }
    
    // 主题颜色(黄)
    class func yinuoYellowColor() -> UIColor {
        return colorWithRGB(r: 253, g: 239, b: 193)     // #FDEFC1
    }
    
    // 文字颜色(默认黑)
    class func yinuoTextColor() -> UIColor {
        return colorWithRGB(r: 43, g: 43, b: 43)    // #2B2B2B
    }
    // 文字颜色(浅灰)
    class func yinuoTextLightGrayColor() -> UIColor {
        return UIColor.lightGray // #666666
    }
    // 文字颜色(浅浅灰)
    class func yinuoTextLightLightGrayColor() -> UIColor {
        return colorWithRGB(r: 204, g: 204, b: 204) // #CCCCCC
    }
    // 文字颜色(灰)
    class func yinuoTextGrayColor() -> UIColor {
        return colorWithRGB(r: 102, g: 102, b: 102) // #666666
    }
    // 文字颜色(红)
    class func yinuoTextRedColor() -> UIColor {
        return colorWithRGB(r: 211, g: 0, b: 0)     // #D30000
    }
    // 文字颜色(蓝)
    class func yinuoTextBlueColor() -> UIColor {
        return colorWithRGB(r: 80, g: 136, b: 230)     // #D30000
    }
    // 通知小红点背景颜色
    class func yinuoNoticePointColor() -> UIColor {
        return colorWithRGB(r: 207, g: 70, b: 71)
    }
    // 线条颜色
    class func yinuoLineColor() -> UIColor {
        return colorWithRGB(r: 204, g: 204, b: 204)
    }
    
    // 确定按钮颜色
    class func yinuoSubmitColor() -> UIColor {
        return  colorWithRGB(r: 211, g: 0, b: 0)
    }
    
    // 输入框颜色
    class func yinuoInputTextColor() -> UIColor {
        return colorWithRGB(r: 43, g: 43, b: 43)
    }
    
    // 输入框提示文字颜色
    class func yinuoInputPlaceholderTextColor() -> UIColor {
        return colorWithRGB(r: 170, g: 170, b: 170)
    }
    
    
    
}
