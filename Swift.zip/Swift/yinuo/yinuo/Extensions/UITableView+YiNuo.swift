//
//  UITableView+YiNuo.swift
//  yinuo
//
//  Created by Tim on 2018/1/26.
//  Copyright © 2018年 yinuo. All rights reserved.
//  泛型优化重用ID(直接使用类名作为重用标示符)

import Foundation

extension UITableView {
    
    // 注册cell
    func registerClassOf<T: UITableViewCell>(_: T.Type) {
        
        register(T.self, forCellReuseIdentifier: T.yinuo_reuseIdentifier)
    }
    
    // xib注册cell
    func registerNibOf<T: UITableViewCell>(_: T.Type) {
        
        let nib = UINib(nibName: T.yinuo_nibName, bundle: nil)
        register(nib, forCellReuseIdentifier: T.yinuo_reuseIdentifier)
    }
    
    // 注册头尾
    func registerHeaderFooterClassOf<T: UITableViewHeaderFooterView>(_: T.Type) {
        
        register(T.self, forHeaderFooterViewReuseIdentifier: T.yinuo_reuseIdentifier)
    }
    
    // 获取cell
    func dequeueReusableCell<T: UITableViewCell>() -> T {
        
        guard let cell = dequeueReusableCell(withIdentifier: T.yinuo_reuseIdentifier) as? T else {
            fatalError("获取Cell失败,ID: \(T.yinuo_reuseIdentifier)")
        }
        return cell
    }
    
    // 获取头尾
    func dequeueReusableHeaderFooter<T: UITableViewHeaderFooterView>() -> T {
        
        guard let view = dequeueReusableHeaderFooterView(withIdentifier: T.yinuo_reuseIdentifier) as? T else {
            fatalError("获取头/尾示图失败,ID: \(T.yinuo_reuseIdentifier)")
        }
        
        return view
    }
}

extension UITableView {
    // 关闭自动调整高度Self-Sizing
    func cancelEstimatedHeight(){
        self.estimatedRowHeight = 0
        self.estimatedSectionFooterHeight = 0
        self.estimatedSectionHeaderHeight = 0
    }
    
    // 隐藏多余的分割线
    func hideTableViewExtraCellLineHidden(tableView : UITableView){
        let view = UIView()
        view.backgroundColor = UIColor.clear
        tableView.tableFooterView = view
        tableView.tableHeaderView = view
    }
}



