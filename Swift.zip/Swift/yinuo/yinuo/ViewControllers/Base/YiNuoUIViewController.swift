//
//  YiNuoUIViewController.swift
//  yinuo
//
//  Created by Tim on 2018/1/11.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit

class YiNuoUIViewController: UIViewController {

    lazy var vistorView = VistorView.vistorView()
    var isLogin : Bool = true
    
    override func loadView() {
        isLogin ? super.loadView() : setupVistorView()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupNavigationBarStyle()
    }

}

// MARK:- 设置UI界面
extension YiNuoUIViewController {
    
    private func setupNavigationBarStyle() {
        self.navigationController?.navigationBar.barStyle = .black       //状态栏颜色
        self.navigationController?.navigationBar.barTintColor = UIColor.yinuoNavBarTintColor()       // 导航颜色
        self.navigationController?.navigationBar.tintColor = UIColor.white   //item颜色
        let item = UIBarButtonItem(title: "", style: .plain, target: self, action: nil)
        self.navigationController?.navigationItem.backBarButtonItem = item
    }
    
    /// 设置访客视图
    private func setupVistorView() {
        view = vistorView
        
        vistorView.loginBtn.addTarget(self, action: #selector(loginClick), for: .touchUpInside)
    }
    
}

// MARK:- 事件监听
extension YiNuoUIViewController {
    @objc private func loginClick() {
        let loginVc = LoginVC()
        let loginNav = UINavigationController(rootViewController: loginVc)
        present(loginNav, animated: true, completion: nil)
    }
}
