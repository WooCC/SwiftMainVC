//
//  YiNuoTabBarController.swift
//  yinuo
//
//  Created by Tim on 2018/1/10.
//  Copyright © 2018年 yinuo. All rights reserved.
//  自定义TabBar

import UIKit
import SwiftyJSON
import SnapKit

class YiNuoTabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        //设置全局颜色
        UITabBar.appearance().tintColor = UIColor.yinuoTopicColor()
        
        //代码方式创建TabBar
//        addChildViewController("HomeViewController", title: "线上", imageName: "home_btn")
//        addChildViewController("OfflineViewController", title: "线下", imageName: "offline_btn")
//        addChildViewController("RankingViewController", title: "排行榜", imageName: "ranking_btn")
//        addChildViewController("CartViewController", title: "购物车", imageName: "cart_btn")
//        addChildViewController("ProfileViewController", title: "我的", imageName: "profile_btn")
    
        // Json配置文件方式创建TabBar，便于后期通过接口控制TabBar显示
        guard let jsonPath = Bundle.main.path(forResource: "YiNuoTabBarControllerSettings", ofType: "json") else {
            println("没有获取到导航配置文件的路径")
            return
        }
        guard let jsonData = try? Data(contentsOf: URL(fileURLWithPath: jsonPath)) else {
            println("获取Json数据出错")
            return
        }
        guard let vcJson = try? JSON(data: jsonData) else {
            println("转换Json出错")
            return
        }
        
        for subJSON in vcJson {
            //获取元组中的json数据
            let json = subJSON.1
            addChildViewController(json["vcName"].stringValue, title: json["title"].stringValue, imageName: json["imageName"].stringValue)
        }
        
        
    }
    
    private func addChildViewController(_ childVCName: String, title: String, imageName: String) {
   
        // 1.获取命名空间
        guard let nameSpace = Bundle.main.infoDictionary!["CFBundleExecutable"] as? String else {
            println("没有获取到命名空间")
            return
        }
        
        // 2.字符串创建控制器
        guard let ChildVcClass = NSClassFromString(nameSpace + "." + childVCName) else {
            println("没有获取到字符串对应的Class")
            return
        }
        
        // 3.AnyObject构成控制器的类型
        guard let childVcType = ChildVcClass as? UIViewController.Type else {
            println("没有获取对应的控制器类型")
            return
        }
        
        // 4.创建对应的控制器对象
        let childVc = childVcType.init()
        
        // 5.设置子控制器属性
        childVc.title = title
        
        tabBar.backgroundColor = UIColor.white
        childVc.tabBarItem.image = UIImage(named: imageName)?.withRenderingMode(.alwaysOriginal)
        childVc.tabBarItem.selectedImage = UIImage(named: imageName + "_sel")?.withRenderingMode(.alwaysOriginal)
        
        // 6.包装导航控制器
        let childNav = YiNuoNavigationViewController(rootViewController: childVc)

        // 7.添加控制器
        addChildViewController(childNav)
    }

}
