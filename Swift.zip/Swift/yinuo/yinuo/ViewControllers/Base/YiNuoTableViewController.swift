//
//  YiNuoTableViewController.swift
//  yinuo
//
//  Created by Tim on 2018/1/26.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit

class YiNuoTableViewController: UITableViewController {

    lazy var vistorView = VistorView.vistorView()
    
    override func loadView() {
        YiNuoUser.sharedInstance.isLogin ? super.loadView() : setupVistorView()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupNav()
        
    }
    

}

extension YiNuoTableViewController {
    
    /// 设置访客视图
    private func setupVistorView() {
        view = vistorView
        vistorView.loginBtn.addTarget(self, action: #selector(loginClick), for: .touchUpInside)
    }
    
    /// 设置导航栏左右的Item
    private func setupNav() {
        
    }
    
}

extension YiNuoTableViewController {
    @objc private func loginClick() {
        let loginNav = YiNuoNavigationViewController(rootViewController: LoginVC())
        present(loginNav, animated: true, completion: nil)
    }
}
