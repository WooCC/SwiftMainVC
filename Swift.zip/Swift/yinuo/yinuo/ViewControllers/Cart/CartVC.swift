//
//  CartViewController.swift
//  yinuo
//
//  Created by Tim on 2018/1/10.
//  Copyright © 2018年 yinuo. All rights reserved.
//  购物车

import UIKit
import ObjectMapper

private let reuseIdentifier = "CartCell"

class CartVC: UITableViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupNav()
        setupView()
        getData()
    }

}

extension CartVC {
    private func setupNav() {
        
    }
    private func setupView() {
        view.backgroundColor = UIColor.yinuoViewBackgroundColor()
        tableView.separatorStyle = .none
        tableView.showsVerticalScrollIndicator = false
        tableView.rowHeight = 105
    }
    private func getData() {
       
    }
}

extension CartVC {
   
}
