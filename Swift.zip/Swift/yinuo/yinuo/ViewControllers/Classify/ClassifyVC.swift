//
//  ClassifyVC.swift
//  yinuo
//
//  Created by Tim on 2018/3/21.
//  Copyright © 2018年 yinuo. All rights reserved.
//  分类

import UIKit

class ClassifyVC: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }


}
