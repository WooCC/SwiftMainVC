//
//  NewFeatureVC.swift
//  yinuo
//
//  Created by tim on 2018/3/22.
//  Copyright © 2018年 yinuo. All rights reserved.
//  引导页

import UIKit

class NewFeatureVC: UIViewController {

    let newFeatureCount = 4
    private lazy var scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.frame = view.bounds
        scrollView.contentSize = CGSize(width: CGFloat(newFeatureCount) * scrollView.yinuo_width, height: 0)
        scrollView.bounces = false
        scrollView.isPagingEnabled = true
        scrollView.delegate = self
        scrollView.showsHorizontalScrollIndicator = false
        
        return scrollView
    }()
    private lazy var pageControl: UIPageControl = {
        let pageControll = UIPageControl()
        pageControll.numberOfPages = newFeatureCount
        pageControll.pageIndicatorTintColor = UIColor.white
        pageControll.currentPageIndicatorTintColor = UIColor.yinuoTopicColor()
        pageControll.isUserInteractionEnabled = false
        return pageControll
    }()
    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
    }
    
    private func setupUI() {
        view.addSubview(scrollView)
        view.addSubview(pageControl)
        
        for i in 0...newFeatureCount {
            let imgV = UIImageView()
            imgV.yinuo_size = scrollView.yinuo_size
            imgV.yinuo_Y = 0
            imgV.yinuo_X = CGFloat(i) * scrollView.yinuo_width
            imgV.image = UIImage(named: "launch\(i+1)")
            scrollView.addSubview(imgV)
            
            // 最后一个界面添加其它控件
            if i == newFeatureCount-1 {
                setupLastImageView(imgV)
            }
        }
        
        pageControl.snp.makeConstraints { (make) in
            make.width.equalTo(100)
            make.height.equalTo(10)
            make.centerX.equalToSuperview()
            make.bottom.equalToSuperview().offset(-34)
        }
        
    }
    
    private func setupLastImageView(_ lastImageView: UIImageView) {
        lastImageView.isUserInteractionEnabled = true
        
        let startBtn = UIButton()
        startBtn.frame = CGRect(x: 0, y: 100, width: 100, height: 50)
        startBtn.setTitle("立即体验", for: .normal)
        startBtn.setTitleColor(UIColor.yinuoTopicColor(), for: .normal)
        startBtn.titleLabel?.font = yinuoFont(14.0)
        startBtn.backgroundColor = UIColor.white
        startBtn.yinuo_cornerRadius = 5
        startBtn.addTarget(self, action: #selector(startBtnClick), for: .touchUpInside)
        lastImageView.addSubview(startBtn)
        
        startBtn.snp.makeConstraints { (make) in
            make.width.equalTo(85)
            make.height.equalTo(23)
            make.bottom.equalTo(pageControl.snp.top).offset(-50)
            make.centerX.equalToSuperview()
        }
    }
    
    @objc private func startBtnClick() {
        let window = UIApplication.shared.keyWindow
        window?.rootViewController = YiNuoTabBarController()
    }

}

extension NewFeatureVC: UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let page = scrollView.contentOffset.x / SCREEN_WIDTH
        let currentPage = lroundf(Float(page))  // 四舍五入
        pageControl.currentPage = currentPage
    }
}
