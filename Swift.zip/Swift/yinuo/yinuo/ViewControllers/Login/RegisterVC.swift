//
//  RegisterVC.swift
//  yinuo
//
//  Created by Tim on 2018/1/14.
//  Copyright © 2018年 yinuo. All rights reserved.
//  注册

import UIKit
import SVProgressHUD
import RxSwift
import Moya
import ObjectMapper

class RegisterVC: UIViewController {

    private lazy var referrerPhoneTF = UnderLineTextField()
    private lazy var phoneTF = UnderLineTextField()
    private lazy var codeTF = UnderLineTextField()
    private lazy var codeBtn = UIButton()
    private lazy var submitBtn = UIButton()
    private lazy var agreeBtn = UIButton()
    private lazy var protocolBtn = UIButton()
    private var leftTime: Int = YiNuoConfig.callMeInSeconds()
    private let codeLen = YiNuoConfig.verifyCodeLength()
    var timer: Timer!
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupNav()
        setupView()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        referrerPhoneTF.becomeFirstResponder()
    }

    
}

// MARK:- 设置UI
extension RegisterVC {
    
    private func setupNav() {
        title = String.trans_titleSignUp
    }
    
    private func setupView() {
        
        // 测试数据
        referrerPhoneTF.text = "15555555555"
        phoneTF.text = "15521080127"
        codeTF.text = "1234"
        
        view.backgroundColor = UIColor.white
        
        referrerPhoneTF.placeholder = "请输入推荐人的手机号(选填)"
        referrerPhoneTF.keyboardType = .numberPad
        referrerPhoneTF.clearButtonMode = .whileEditing
        referrerPhoneTF.borderStyle = .none
        referrerPhoneTF.leftView = UIImageView(image: UIImage(named:"referee"))
        referrerPhoneTF.leftViewMode = .always
        referrerPhoneTF.leftInset = YiNuoConfig.Login.leftInset
        referrerPhoneTF.delegate = self
        
        phoneTF.placeholder = "请输入您的手机号"
        phoneTF.keyboardType = .numberPad
        phoneTF.clearButtonMode = .whileEditing
        phoneTF.borderStyle = .none
        phoneTF.leftView = UIImageView(image: UIImage(named:"phone"))
        phoneTF.leftViewMode = .always
        phoneTF.leftInset = YiNuoConfig.Login.leftInset
        phoneTF.delegate = self
        
        codeTF.placeholder = "请输入验证码"
        codeTF.keyboardType = .numberPad
        codeTF.clearButtonMode = .whileEditing
        codeTF.borderStyle = .none
        codeTF.leftView = UIImageView(image: UIImage(named:"code"))
        codeTF.leftViewMode = .always
        codeTF.leftInset = YiNuoConfig.Login.leftInset
        codeTF.rightInset = YiNuoConfig.Login.rightInset
        codeTF.delegate = self
        
        codeBtn.setTitle("获取验证码", for: .normal)
        codeBtn.setTitleColor(UIColor.yinuoSubmitColor(), for: .normal)
        codeBtn.titleLabel?.font = UIFont.systemFont(ofSize: 17.0)
        codeBtn.backgroundColor = UIColor.yinuoTopicColor()
        codeBtn.setTitleColor(UIColor.white, for: .normal)
        codeBtn.layer.cornerRadius = 14.5
        codeBtn.addTarget(self, action: #selector(codeBtnClick), for: .touchUpInside)
        
        submitBtn.layer.cornerRadius = 24.5
        submitBtn.setTitle("下一步", for: .normal)
        submitBtn.backgroundColor = UIColor.yinuoSubmitColor()
        submitBtn.addTarget(self, action: #selector(submitBtnClick), for: .touchUpInside)
        
        agreeBtn.setImage(UIImage(named: "check"), for: .normal)
        agreeBtn.setImage(UIImage(named: "checked"), for: .selected)
        agreeBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14.0)
        agreeBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 9, 0, 0)
        agreeBtn.setTitle("我已经阅读并同意", for: .normal)
        agreeBtn.setTitleColor(UIColor.yinuoTextLightGrayColor(), for: .normal)
        agreeBtn.contentHorizontalAlignment = .left
        agreeBtn.adjustsImageWhenHighlighted = false
        agreeBtn.titleLabel?.adjustsFontSizeToFitWidth = true
        agreeBtn.titleLabel?.font = UIFont.systemFont(ofSize: 16.0)
        agreeBtn.addTarget(self, action: #selector(agreeBtnClick(sender:)), for: .touchUpInside)
        agreeBtn.isSelected = true
        
        protocolBtn.setTitle("【用户注册协议】", for: .normal)
        protocolBtn.setTitleColor(UIColor.yinuoTopicColor(), for: .normal)
        protocolBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14.0)
        protocolBtn.addTarget(self, action: #selector(protocolBtnClick), for: .touchUpInside)
        
        view.addSubview(referrerPhoneTF)
        view.addSubview(phoneTF)
        view.addSubview(codeTF)
        view.addSubview(codeBtn)
        view.addSubview(submitBtn)
        view.addSubview(agreeBtn)
        view.addSubview(protocolBtn)
        
        makeConstraints()
    }
    
    private func makeConstraints() {
        // 约束
        referrerPhoneTF.snp.makeConstraints { (make) in
            make.top.equalTo(74)
            make.left.equalTo(12)
            make.right.equalTo(-12)
            make.height.equalTo(60)
        }
        phoneTF.snp.makeConstraints { (make) in
            make.top.equalTo(referrerPhoneTF.snp.bottom)
            make.left.right.height.equalTo(referrerPhoneTF)
        }
        codeTF.snp.makeConstraints { (make) in
            make.left.width.height.equalTo(referrerPhoneTF)
            make.top.equalTo(phoneTF.snp.bottom)
        }
        codeBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(codeTF)
            make.width.equalTo(120)
            make.height.equalTo(29)
            make.right.equalTo(referrerPhoneTF)
        }
        submitBtn.snp.makeConstraints { (make) in
            make.left.equalTo(12)
            make.right.equalTo(-12)
            make.top.equalTo(codeTF.snp.bottom).offset(99)
            make.height.equalTo(49)
        }
        agreeBtn.snp.makeConstraints { (make) in
            make.left.equalTo(submitBtn).offset(16.5)
            make.top.equalTo(submitBtn.snp.bottom).offset(12.5)
        }
        protocolBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(agreeBtn)
            make.left.equalTo(agreeBtn.snp.right)
        }
    }
}

// MARK:- 监听方法
extension RegisterVC {
    // 关闭界面
    @objc private func closeItemClick() {
        dismiss(animated: true, completion: nil)
    }
    @objc private func submitBtnClick() {
        
        var referrerPhone = ""
        var phone: String
        var code: String
        
        if let len = referrerPhoneTF.text?.count , len > 0{
            referrerPhone = self.referrerPhoneTF.text!;
            guard referrerPhoneTF.text! =~ isPhoneNum else {
                YiNuoInform("请输入正确的推荐人手机号")
                referrerPhoneTF.becomeFirstResponder()
                return
            }
        }
        
        
        if let len = phoneTF.text?.count , len > 0{
            phone = self.phoneTF.text!;
        }else {
            phoneTF.becomeFirstResponder()
            return;
        }
        guard phoneTF.text! =~ isPhoneNum else {
            YiNuoInform("请输入正确的个人手机号")
            return
        }
        
        if let len = codeTF.text?.count , len > 0{
            code = self.codeTF.text!;
        }else {
            codeTF.becomeFirstResponder()
            return;
        }
        guard codeTF.text! =~ isCode else {
            YiNuoInform("请输入正确的验证码")
            return
        }
        
        guard agreeBtn.isSelected else {
            YiNuoInform("请先同意协议")
            return
        }
        
        // 网络请求
        let provider = ApiUser.provider
        provider.rx.request(.checkReg(referrerPhone: referrerPhone, phone: phone, code: code)).filterSuccessfulStatusCodes().mapObject(ResultModel<UserModel>.self).subscribe(onSuccess: { (response) in
            if response.code != 0 {
                YiNuoHUD.inform(response.errorMsg)
            }else {
                // 界面跳转
                println("检验成功")
                let regPassVC = RegisterPassVC()
                regPassVC.phone = phone
                regPassVC.referrerPhone = referrerPhone
                self.navigationController?.pushViewController(regPassVC, animated: true)
            }
        }, onError: { (error) in
            YiNuoHUD.error("网络错误")
        }).disposed(by: disposeBag)
        
    }
    @objc private func agreeBtnClick(sender: UIButton) {
        sender.isSelected = sender.isSelected ? false : true
    }
    @objc private func protocolBtnClick() {
        navigationController?.pushViewController(ProtocolVC(), animated: true)
    }
    @objc private func codeBtnClick() {
        
        var phone: String
        if let len = phoneTF.text?.count , len > 0{
            phone = self.phoneTF.text!
        }else {
            phoneTF.becomeFirstResponder()
            return
        }
        guard phoneTF.text! =~ isPhoneNum else {
            YiNuoInform("请输入正确的手机号")
            return
        }
        
        YiNuoBeginLoading()
        
        // 网络请求
        let provider = ApiCode.provider
        provider.rx.request(.sendCode(phone: phone, type: YiNuoConstants.TYPE_CODE_REG)).filterSuccessfulStatusCodes().mapObject(ResultModel<DefaultModel>.self).subscribe(onSuccess: { (response) in

            if response.code != 0 {
                YiNuoHUD.inform(response.errorMsg)
            }else{
                YiNuoHUD.success("验证码发送成功!")
                self.codeBtn.isEnabled = false
                self.timer = Timer.scheduledTimer(timeInterval: TimeInterval(1), target: self, selector: #selector(self.timeDown), userInfo: nil, repeats: true)
            }
        }, onError: { (error) in
            YiNuoHUD.error("网络错误")
        }).disposed(by: disposeBag)
        
    }
    @objc private func timeDown() {
        //将剩余时间减少1秒
        leftTime -= 1
        codeBtn.setTitle("重新获取\(leftTime)秒", for: .disabled)
        if leftTime <= 0 {
            //取消定时器
            timer.invalidate()
            codeBtn.isEnabled = true
            leftTime = YiNuoConfig.callMeInSeconds()
            codeBtn.setTitle("重新获取", for: .normal)
        }
    }
}

// MARK:- TextField代理
extension RegisterVC: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        guard let text = textField.text else{
            return true
        }
        
        if textField == phoneTF || textField == referrerPhoneTF {
            let textLength = text.count + string.count - range.length
            return textLength <= 11
        }else if textField == codeTF {
            let textLength = text.count + string.count - range.length
            return textLength <= codeLen
        }
        
        return true
        
    }
}
