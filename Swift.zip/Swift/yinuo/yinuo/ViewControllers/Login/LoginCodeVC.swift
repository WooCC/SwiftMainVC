//
//  LoginCodeVC.swift
//  yinuo
//
//  Created by 谭锦添 on 2018/2/7.
//  Copyright © 2018年 yinuo. All rights reserved.
//  手机短信登录

import UIKit
import Moya
import RxSwift
import SVProgressHUD

class LoginCodeVC: UIViewController {

    private lazy var phoneTF = UnderLineTextField()
    private lazy var codeBtn = UIButton()
    private lazy var codeTF = UnderLineTextField()
    private lazy var submitBtn = UIButton()
    private lazy var passLoginBtn = UIButton()
    private var leftTime: Int = YiNuoConfig.callMeInSeconds()
    private let codeLen = YiNuoConfig.verifyCodeLength()
    var timer: Timer!
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupNav()
        setupUI()
    }

}

extension LoginCodeVC {
    // 设置导航栏
    private func setupNav() {
        
        //状态栏颜色
        navigationController?.navigationBar.barStyle = .black
        // 导航颜色
        navigationController?.navigationBar.barTintColor = UIColor.yinuoNavBarTintColor()
        
        //item颜色
        navigationController?.navigationBar.tintColor = UIColor.white
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "注册", style: .plain, target: self, action: #selector(registerItemClick))
        
        title = String.trans_titleLogin
    }
    
    // 登录界面
    private func setupUI() {
        
        view.backgroundColor = UIColor.white
        
        let logoImgV = UIImageView(image: UIImage(named: "loginLogo"))
        
        phoneTF.placeholder = "请输入手机号"
        phoneTF.setValue(UIColor.yinuoInputPlaceholderTextColor(), forKeyPath: "_placeholderLabel.textColor")
        phoneTF.font = UIFont.systemFont(ofSize: 17.0)
        phoneTF.textColor = UIColor.yinuoInputTextColor()
        phoneTF.keyboardType = .numberPad
        phoneTF.clearButtonMode = .whileEditing
        phoneTF.borderStyle = .none
        phoneTF.delegate = self
        phoneTF.leftView = UIImageView(image: UIImage(named:"phone"))
        phoneTF.leftViewMode = .always
        phoneTF.leftInset = YiNuoConfig.Login.leftInset
        phoneTF.rightInset = YiNuoConfig.Login.rightInset
        
        codeBtn.setTitle("获取动态密码", for: .normal)
        codeBtn.setTitleColor(UIColor.white, for: .normal)
        codeBtn.backgroundColor = UIColor.yinuoTopicColor()
        codeBtn.titleLabel?.font = UIFont.systemFont(ofSize: 17.0)
        codeBtn.addTarget(self, action: #selector(codeBtnClick), for: .touchUpInside)
        codeBtn.layer.cornerRadius = 4.0
        
        codeTF.placeholder = "请输入验证码"
        codeTF.setValue(UIColor.yinuoInputPlaceholderTextColor(), forKeyPath: "_placeholderLabel.textColor")
        codeTF.font = UIFont.systemFont(ofSize: 17.0)
        codeTF.textColor = UIColor.yinuoInputTextColor()
        codeTF.keyboardType = .numberPad
        codeTF.clearButtonMode = .whileEditing
        codeTF.borderStyle = .none
        codeTF.delegate = self
        codeTF.leftView = UIImageView(image: UIImage(named:"pass"))
        codeTF.leftViewMode = .always
        codeTF.leftInset = YiNuoConfig.Login.leftInset
        codeTF.rightInset = YiNuoConfig.Login.rightInset
        
        submitBtn.layer.cornerRadius = 24.5
        submitBtn.backgroundColor = UIColor.yinuoSubmitColor()
        submitBtn.setTitle("登录", for: .normal)
        submitBtn.addTarget(self, action: #selector(submitBtnClick), for: .touchUpInside)
        
        
        passLoginBtn.setTitle("使用一诺账号登录", for: .normal)
        passLoginBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14.0)
        passLoginBtn.setTitleColor(UIColor.yinuoInputPlaceholderTextColor(), for: .normal)
        passLoginBtn.addTarget(self, action: #selector(passLoginClick), for: .touchUpInside)
        
        view.addSubview(logoImgV)
        view.addSubview(phoneTF)
        view.addSubview(codeBtn)
        view.addSubview(codeTF)
        view.addSubview(submitBtn)
        view.addSubview(passLoginBtn)
        
        // 约束
        logoImgV.snp.makeConstraints { (make) in
            make.width.height.equalTo(93)
            make.centerX.equalTo(view.snp.centerX)
            make.top.equalTo(139)
        }
        phoneTF.snp.makeConstraints { (make) in
            make.top.equalTo(logoImgV.snp.bottom).offset(30)
            make.left.equalToSuperview().offset(12)
            make.right.equalToSuperview().offset(-12)
            make.height.equalTo(59)
        }
        codeBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(phoneTF)
            make.right.equalToSuperview().offset(-17)
            make.width.equalTo(130)
            make.height.equalTo(30)
        }
        codeTF.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(12)
            make.right.equalToSuperview().offset(-12)
            make.top.equalTo(phoneTF.snp.bottom)
            make.height.equalTo(phoneTF)
        }
        
        
        submitBtn.snp.makeConstraints { (make) in
            make.left.equalTo(12)
            make.right.equalTo(-12)
            make.height.equalTo(49)
            make.top.equalTo(codeTF.snp.bottom).offset(35)
        }
        passLoginBtn.snp.makeConstraints { (make) in
            make.top.equalTo(submitBtn.snp.bottom).offset(10)
            make.left.equalTo(submitBtn).offset(10)
        }
        
    }
}

// MARK:- 事件监听
extension LoginCodeVC {
    
    // 注册
    @objc private func registerItemClick() {
        let registerVC = RegisterVC()
        navigationController?.pushViewController(registerVC, animated: true)
    }
    
    @objc private func codeBtnClick() {
        println("code")
        guard phoneTF.text?.count == 11 else {
            YiNuoInform("请输入11位手机号")
            return
        }
        codeBtn.setTitle("重新获取\(leftTime)秒", for: .disabled)
        codeBtn.isEnabled = false
        //获取该计时器的剩余时间
        timer = Timer.scheduledTimer(timeInterval: TimeInterval(1), target: self, selector: #selector(timeDown), userInfo: nil, repeats: true)
        
    }
    
    // 密码方式登录
    @objc private func passLoginClick() {
        navigationController?.popViewController(animated: true)
    }
    
    
    // 提交
    @objc private func submitBtnClick() {
        
        var phone: String
        var code: String
        
        if let len = phoneTF.text?.count , len > 0{
            phone = self.phoneTF.text! ;
        }else {
            phoneTF.becomeFirstResponder()
            return;
        }
        guard phoneTF.text! =~ isPhoneNum else {
            YiNuoInform("请输入正确的手机号")
            return
        }
        
        if let len =  codeTF.text?.count , len > 0  {
            code = codeTF.text!
        }else {
            codeTF.becomeFirstResponder()
            return;
        }
        guard codeTF.text! =~ isCode else {
            YiNuoInform("请输入正确的验证码")
            return
        }
        
        // 登录
        println("登录成功")
        
        
        
    }
    
    @objc private func timeDown() {
        //将剩余时间减少1秒
        leftTime -= 1
        codeBtn.setTitle("重新获取\(leftTime)秒", for: .disabled)
        if leftTime <= 0 {
            //取消定时器
            timer.invalidate()
            codeBtn.isEnabled = true
            leftTime = YiNuoConfig.callMeInSeconds()
            codeBtn.setTitle("获取动态密码", for: .normal)
        }
    }
    
    
}

// MARK:- 输入框代理
extension LoginCodeVC: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        //        eyeBtn.isHidden = false
        
        guard let text = textField.text else{
            return true
        }
        
        if textField == phoneTF {
            let textLength = text.count + string.count - range.length
            return textLength <= 11
        }else if textField == codeTF {
            let textLength = text.count + string.count - range.length
            return textLength <= codeLen
        }
        
        return true
        
    }
    
}
