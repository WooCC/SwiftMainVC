//
//  RegisterPassVC.swift
//  yinuo
//
//  Created by tim on 2018/3/22.
//  Copyright © 2018年 yinuo. All rights reserved.
//  注册-填写密码

import UIKit
import Moya
import RxSwift

class RegisterPassVC: UIViewController {

    private lazy var passTF: UnderLineTextField = {
        let passTF = UnderLineTextField()
        passTF.placeholder = "请输入您的密码"
        passTF.clearButtonMode = .whileEditing
        passTF.borderStyle = .none
        passTF.leftView = UIImageView(image: UIImage(named:"pass"))
        passTF.leftViewMode = .always
        passTF.leftInset = YiNuoConfig.Login.leftInset
        return passTF
    }()
    private lazy var repeatPassTF: UnderLineTextField = {
        let repeatPassTF = UnderLineTextField()
        repeatPassTF.placeholder = "请确认您的密码"
        repeatPassTF.clearButtonMode = .whileEditing
        repeatPassTF.borderStyle = .none
        repeatPassTF.leftView = UIImageView(image: UIImage(named:"pass"))
        repeatPassTF.leftViewMode = .always
        repeatPassTF.leftInset = YiNuoConfig.Login.leftInset
        return repeatPassTF
    }()
    private lazy var warnBtn: UIButton = {
        let warnBtn = UIButton()
        warnBtn.isUserInteractionEnabled = false
        warnBtn.setImage(UIImage(named: "warn"), for: .normal)
        warnBtn.setTitle("密码由8-20英文字母和数字组成", for: .normal)
        warnBtn.setTitleColor(UIColor.yinuoTextLightLightGrayColor(), for: .normal)
        warnBtn.titleLabel?.font = yinuoFont(14.0)
        warnBtn.contentHorizontalAlignment = .left
        warnBtn.titleEdgeInsets = UIEdgeInsets(top: 0, left: 5, bottom: 0, right: 0)
        return warnBtn
    }()
    private lazy var submitBtn: UIButton = {
        let submitBtn = UIButton()
        submitBtn.setTitle("确定", for: .normal)
        submitBtn.titleLabel?.font = yinuoFont(20.0)
        submitBtn.titleLabel?.textColor = UIColor.white
        submitBtn.backgroundColor = UIColor.yinuoTopicColor()
        submitBtn.yinuo_cornerRadius = 24.5
        submitBtn.addTarget(self, action: #selector(submitBtnClick), for: .touchUpInside)
        return submitBtn
    }()
    
    var phone: String?                  // 注册手机号
    var referrerPhone: String?          // 推荐人手机号
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
    }
    
    private func setupUI() {
        view.backgroundColor = UIColor.white
        
        view.addSubview(passTF)
        view.addSubview(repeatPassTF)
        view.addSubview(warnBtn)
        view.addSubview(submitBtn)
        
        passTF.snp.makeConstraints { (make) in
            make.top.equalTo(74)
            make.left.equalTo(12)
            make.right.equalTo(-12)
            make.height.equalTo(60)
        }
        repeatPassTF.snp.makeConstraints { (make) in
            make.width.height.left.equalTo(passTF)
            make.top.equalTo(passTF.snp.bottom)
        }
        warnBtn.snp.makeConstraints { (make) in
            make.left.right.equalTo(passTF)
            make.top.equalTo(repeatPassTF.snp.bottom).offset(8)
            make.height.equalTo(17)
        }
        submitBtn.snp.makeConstraints { (make) in
            make.left.equalTo(12)
            make.right.equalTo(-12)
            make.height.equalTo(49)
            make.top.equalTo(warnBtn.snp.bottom).offset(86)
        }
    }
    
    @objc private func submitBtnClick() {
        var pass: String
        var repeatPass: String
        
        if let len = passTF.text?.count , len > 0{
            pass = self.passTF.text!;
        }else {
            passTF.becomeFirstResponder()
            return;
        }
        guard passTF.text! =~ isPassword else {
            YiNuoInform("请输入正确的用户密码")
            return
        }
        if let len = repeatPassTF.text?.count , len > 0{
            repeatPass = self.repeatPassTF.text!;
        }else {
            repeatPassTF.becomeFirstResponder()
            return;
        }
        guard repeatPassTF.text! =~ isPassword else {
            YiNuoInform("请输入正确的重复密码")
            return
        }
        guard pass == repeatPass else {
            YiNuoInform("2次密码输入不一致")
            return
        }
        
        // 网络请求
        let provider = ApiUser.provider
        provider.rx.request(.register(refPhone: referrerPhone!, phone: phone!, password: pass)).filterSuccessfulStatusCodes().mapObject(ResultModel<DefaultModel>.self).subscribe(onSuccess: { (response) in
            if response.code != 0 {
                YiNuoHUD.inform(response.errorMsg)
            }else {
                YiNuoSuccess("注册成功!")
                self.navigationController?.popToRootViewController(animated: true)
            }
        }, onError: { (error) in
            YiNuoHUD.error("网络错误")
        }).disposed(by: disposeBag)
        
    }

}
