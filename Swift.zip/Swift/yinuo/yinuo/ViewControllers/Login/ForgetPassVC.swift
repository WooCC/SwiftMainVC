//
//  ForgetPassVC.swift
//  yinuo
//
//  Created by Tim on 2018/1/14.
//  Copyright © 2018年 yinuo. All rights reserved.
//  忘记密码

import UIKit
import SVProgressHUD

class ForgetPassVC: UIViewController {
    
    var leftTime: Int = YiNuoConfig.callMeInSeconds()
    private let codeLen = YiNuoConfig.verifyCodeLength()
    
    var timer: Timer!

    private lazy var phoneTF = UnderLineTextField()
    private lazy var codeTF = UITextField()
    private lazy var codeBtn = UIButton()
    private lazy var submitBtn = UIButton()
    private lazy var lineV = UIView()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupNav()
        setupView()
    }


}

// MARK:- UI界面
extension ForgetPassVC {
    
    // 设置导航栏
    private func setupNav() {
        title = "忘记密码"
    }
    
    private func setupView() {
        
        view.backgroundColor = UIColor.white
        
        phoneTF.keyboardType = .numberPad
        phoneTF.placeholder = "请输入手机号"
        phoneTF.clearButtonMode = .whileEditing
        phoneTF.textColor = UIColor.yinuoInputTextColor()
        phoneTF.borderStyle = .none
        phoneTF.delegate = self
        
        codeTF.placeholder = "请输入\(codeLen)位验证码"
        codeTF.keyboardType = .numberPad
        codeTF.clearButtonMode = .whileEditing
        codeTF.borderStyle = .none
        codeTF.delegate = self
        
        codeBtn.setTitle("获取验证码", for: .normal)
        codeBtn.setTitleColor(UIColor.yinuoTopicColor(), for: .normal)
        codeBtn.titleLabel?.font = UIFont.systemFont(ofSize: 17.0)
        codeBtn.layer.borderColor = UIColor.yinuoSubmitColor().cgColor
        codeBtn.layer.borderWidth = 1
        codeBtn.layer.cornerRadius = 14.5
        codeBtn.addTarget(self, action: #selector(codeBtnClick), for: .touchUpInside)
        
        lineV.backgroundColor = UIColor.yinuoLineColor()
        
        submitBtn.setTitle("下一步", for: .normal)
        submitBtn.backgroundColor = UIColor.yinuoSubmitColor()
        submitBtn.layer.cornerRadius = 24.5
        submitBtn.addTarget(self, action: #selector(submitBtnClick), for: .touchUpInside)
        
        
        
        view.addSubview(phoneTF)
        view.addSubview(codeTF)
        view.addSubview(codeBtn)
        view.addSubview(lineV)
        view.addSubview(submitBtn)
        
        makeConstraints()
        
    }
    
    private func makeConstraints() {
        phoneTF.snp.makeConstraints { (make) in
            make.left.equalTo(12)
            make.right.equalTo(-12)
            make.top.equalTo(74)
            make.height.equalTo(60)
        }
        codeTF.snp.makeConstraints { (make) in
            make.left.height.equalTo(phoneTF)
            make.width.equalTo(170)
            make.top.equalTo(phoneTF.snp.bottom)
        }
        codeBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(codeTF)
            make.width.equalTo(120)
            make.height.equalTo(29)
            make.right.equalTo(phoneTF.snp.right).offset(-10)
        }
        lineV.snp.makeConstraints { (make) in
            make.left.right.equalTo(phoneTF)
            make.top.equalTo(codeTF.snp.bottom)
            make.height.equalTo(1)
        }
        submitBtn.snp.makeConstraints { (make) in
            make.left.equalTo(12)
            make.right.equalTo(-12)
            make.top.equalTo(lineV.snp.bottom).offset(99)
            make.height.equalTo(49)
        }
    }
}

// MARK:- 监听方法
extension ForgetPassVC {
    
    @objc private func codeBtnClick() {
        println("code")
        guard phoneTF.text?.count == 11 else {
            SVProgressHUD.showInfo(withStatus: "请输入11位手机号")
            return
        }
        codeBtn.setTitle("重新获取\(leftTime)秒", for: .disabled)
        codeBtn.isEnabled = false
//        //获取该计时器的剩余时间
        timer = Timer.scheduledTimer(timeInterval: TimeInterval(1), target: self, selector: #selector(timeDown), userInfo: nil, repeats: true)
        
    }
    @objc private func submitBtnClick() {
        guard phoneTF.text?.count == 11 else {
            SVProgressHUD.showInfo(withStatus: "请输入11位手机号")
            return
        }
        guard codeTF.text?.count == codeLen else {
            SVProgressHUD.showInfo(withStatus: "请输入\(codeLen)位验证码")
            return
        }
        SVProgressHUD.showInfo(withStatus: "成功找回密码")
    }
    
    @objc private func timeDown() {
        //将剩余时间减少1秒
        leftTime -= 1
        codeBtn.setTitle("重新获取\(leftTime)秒", for: .disabled)
        if leftTime <= 0 {
            //取消定时器
            timer.invalidate()
            codeBtn.isEnabled = true
            codeBtn.setTitle("重新获取", for: .normal)
        }
    }
}

// MARK:- TextField代理
extension ForgetPassVC: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        guard let text = textField.text else{
            return true
        }
        
        if textField == phoneTF {
            let textLength = text.count + string.count - range.length
            return textLength <= 11
        }else if textField == codeTF {
            let textLength = text.count + string.count - range.length
            return textLength <= codeLen
        }
        
        return true
        
    }
}
