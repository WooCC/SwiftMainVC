//
//  LoginViewController.swift
//  yinuo
//
//  Created by Tim on 2018/1/13.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit

class LoginVC: UIViewController {

    private lazy var phoneTF = UnderLineTextField()
    private lazy var passTF = UnderLineTextField()
    private lazy var eyeBtn = UIButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupNav()
        setupUI()
        
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        phoneTF.becomeFirstResponder()
    }

}

// MARK:- 设置UI界面
extension LoginVC {
    
    // 设置导航栏
    private func setupNav() {
        
        //状态栏颜色
        navigationController?.navigationBar.barStyle = .black
        // 导航颜色
        navigationController?.navigationBar.barTintColor = UIColor.yinuoNavBarTintColor()
        
        //item颜色
        navigationController?.navigationBar.tintColor = UIColor.white
        
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "关闭", style: .plain, target: self, action: #selector(closeItemClick))
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "注册", style: .plain, target: self, action: #selector(registerItemClick))
        
        title = String.trans_titleLogin
    }
    
    // 登录界面
    private func setupUI() {
        
        view.backgroundColor = UIColor.white
        
        let logoImgV = UIImageView(image: UIImage(named: "loginLogo"))

        eyeBtn.isHidden = true
        eyeBtn.adjustsImageWhenHighlighted = false
        eyeBtn.setImage(UIImage(named: "eye_open"), for: .normal)
        eyeBtn.setImage(UIImage(named: "eye_close"), for: .selected)
        eyeBtn.addTarget(self, action: #selector(eyeClick(sender:)), for: .touchUpInside)
        
        phoneTF.placeholder = "请输入手机号码"
        //字体大小
        phoneTF.setValue(UIColor.yinuoInputPlaceholderTextColor(), forKeyPath: "_placeholderLabel.textColor")
        phoneTF.font = UIFont.systemFont(ofSize: 17.0)
        phoneTF.textColor = UIColor.yinuoInputTextColor()
        phoneTF.keyboardType = .numberPad
        phoneTF.clearButtonMode = .whileEditing
        phoneTF.borderStyle = .none
        phoneTF.delegate = self
        phoneTF.leftView = UIImageView(image: UIImage(named:"phone"))
        phoneTF.leftViewMode = .always
        phoneTF.leftInset = YiNuoConfig.Login.leftInset
        
        passTF.placeholder = "请输入登录密码"
        passTF.setValue(UIColor.yinuoInputPlaceholderTextColor(), forKeyPath: "_placeholderLabel.textColor")
        passTF.font = UIFont.systemFont(ofSize: 17.0)
        passTF.isSecureTextEntry = true
        passTF.clearButtonMode = .whileEditing
        passTF.borderStyle = .none
        passTF.delegate = self
        passTF.leftView = UIImageView(image: UIImage(named:"pass"))
        passTF.leftViewMode = .always
        passTF.leftInset = YiNuoConfig.Login.leftInset
        passTF.rightInset = 50
        
        let submitBtn = UIButton()
        submitBtn.layer.cornerRadius = 24.5
        submitBtn.backgroundColor = UIColor.yinuoSubmitColor()
        submitBtn.setTitle("登录", for: .normal)
        submitBtn.addTarget(self, action: #selector(submitBtnClick), for: .touchUpInside)
        
        let forgetPassBtn = UIButton()
        forgetPassBtn.contentHorizontalAlignment = .left
        forgetPassBtn.setTitle("忘记密码?", for: .normal)
        forgetPassBtn.setTitleColor(UIColor.yinuoInputPlaceholderTextColor(), for: .normal)
        forgetPassBtn.titleLabel?.font = UIFont(name: "PingFang-SC-Regular", size: 14.0)!
        forgetPassBtn.addTarget(self, action: #selector(forgetPassBtnClick), for: .touchUpInside)
        
        let codeLoginBtn = UIButton()
        codeLoginBtn.setTitle("使用手机动态码登录", for: .normal)
        codeLoginBtn.titleLabel?.font = UIFont.systemFont(ofSize: 14.0)
        codeLoginBtn.setTitleColor(UIColor.yinuoInputPlaceholderTextColor(), for: .normal)
        codeLoginBtn.addTarget(self, action: #selector(codeLoginClick), for: .touchUpInside)
        
        view.addSubview(logoImgV)
        view.addSubview(phoneTF)
        view.addSubview(passTF)
        view.addSubview(eyeBtn)
        view.addSubview(submitBtn)
        view.addSubview(forgetPassBtn)
        view.addSubview(codeLoginBtn)
 
        // 约束
        logoImgV.snp.makeConstraints { (make) in
            make.width.height.equalTo(93)
            make.centerX.equalTo(view.snp.centerX)
            make.top.equalTo(139)
        }
        phoneTF.snp.makeConstraints { (make) in
            make.top.equalTo(logoImgV.snp.bottom).offset(30)
            make.left.equalToSuperview().offset(12)
            make.right.equalToSuperview().offset(-12)
            make.height.equalTo(59)
        }
        passTF.snp.makeConstraints { (make) in
            make.left.right.equalTo(phoneTF)
            make.top.equalTo(phoneTF.snp.bottom)
            make.height.equalTo(phoneTF)
        }
        eyeBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(passTF)
            make.right.equalTo(passTF).offset(-10)
        }
        
        submitBtn.snp.makeConstraints { (make) in
            make.left.equalTo(12)
            make.right.equalTo(-12)
            make.height.equalTo(49)
            make.top.equalTo(passTF.snp.bottom).offset(35)
        }
        forgetPassBtn.snp.makeConstraints { (make) in
            make.top.equalTo(submitBtn.snp.bottom).offset(10)
            make.left.equalTo(submitBtn).offset(10)
        }
        codeLoginBtn.snp.makeConstraints { (make) in
            make.top.equalTo(forgetPassBtn)
            make.right.equalTo(submitBtn).offset(-10)
        }
        
    }
}

// MARK:- 事件监听
extension LoginVC {
    
    // 关闭界面
    @objc private func closeItemClick() {
        dismiss(animated: true, completion: nil)
    }
    
    // 注册
    @objc private func registerItemClick() {
        let registerVC = RegisterVC()
        navigationController?.pushViewController(registerVC, animated: true)
    }
    
    // 忘记密码点击
    @objc private func forgetPassBtnClick() {
        let forgetPassVC = ForgetPassVC()
        navigationController?.pushViewController(forgetPassVC, animated: true)
    }
    
    // 手机短信登录
    @objc private func codeLoginClick() {
        let loginCodeVC = LoginCodeVC()
        navigationController?.pushViewController(loginCodeVC, animated: true)
    }
    
    // 提交
    @objc private func submitBtnClick() {

        var phone: String
        var pass: String
        
        if let len = phoneTF.text?.count , len > 0{
            phone = self.phoneTF.text!
        }else {
            phoneTF.becomeFirstResponder()
            return
        }
        guard phoneTF.text! =~ isPhoneNum else {
            YiNuoInform("请输入正确的手机号")
            return
        }
        
        if let len =  passTF.text?.count , len > 0  {
            pass = passTF.text!
        }else {
            passTF.becomeFirstResponder()
            return;
        }
        guard passTF.text! =~ isPassword else {
            YiNuoInform("请输入正确的账号密码")
            return
        }
        
        // 登录
        ApiUser.provider.request(.login(phone: phone, password: pass)) { (result) in
            
            switch result {
            case let .success(moyaResponse):
                
                
                do {
                    
                    let any = try moyaResponse.mapJSON()
                    let data = moyaResponse.data
                    let statusCode = moyaResponse.statusCode
                    println("any:\(any) data:\(data) code:\(statusCode)")
                    // 保存帐号到偏好设置
                    YiNuoSettings.sharedInstance["userPhone"] = phone
                    // 帐号和密码保存到keychain(安全保存,keychain可保存到沙盒外，上传至iCloud)
                    YiNuoUsersKeychain.sharedInstance.addUser(phone, password: pass)
                    
                    // 获取用户信息
//                    UserModel.getUserInfoByPhone(phone, completionHandler: nil)
                    
                    YiNuoSuccess("登录成功")
                    self.dismiss(animated: true, completion: nil)
                    
                } catch {
                    
                }
            case let .failure(error):
                println(error)
                YiNuoError(error.errorDescription)
            }
            
            // 获取用户信息
            ApiUser.provider.request(.getUserInfo(phone: phone), completion: { (result) in
                
                
                
            })
            
            YiNuoSuccess("登录成功")
            
            
            
        }
        
        
        
    }
    
    // 密码明文
    @objc private func eyeClick(sender: UIButton) {
        sender.isSelected = sender.isSelected ? false : true
        passTF.isSecureTextEntry = !passTF.isSecureTextEntry
        
        let content = passTF.text
        passTF.text = passTF.text
        
        // 密文转明文,二次编辑不会出现清空现象
        // 明文转密文,二次编辑会出现清空现象,进行判断,如果切换后此时输入框是密文状态,就保存原有内容并赋值给输入框,这样就不会出现清空现象了
        if passTF.isSecureTextEntry {
            passTF.insertText(content!)
        }
    }
    
}

// MARK:- 输入框代理
extension LoginVC: UITextFieldDelegate {
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        guard let text = textField.text else{
            return true
        }
        
        if textField == phoneTF {
            let textLength = text.count + string.count - range.length
            return textLength <= 11
        }
        
        if textField == passTF {
            eyeBtn.isHidden = false
            let textLength = text.count + string.count - range.length
            if textLength == 0 {
                eyeBtn.isHidden = true
            }
            return textLength <= 16
        }
        
        return true
        
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        eyeBtn.isHidden = true
        return true
    }
    
}
