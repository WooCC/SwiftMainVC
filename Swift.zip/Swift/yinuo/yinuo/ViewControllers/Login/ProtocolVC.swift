//
//  ProtocolVC.swift
//  yinuo
//
//  Created by Tim on 2018/1/14.
//  Copyright © 2018年 yinuo. All rights reserved.
//  注册协议

import UIKit

class ProtocolVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        setupNavBar()
        setupProtocolView()
    }
}

extension ProtocolVC {
    private func setupNavBar() {
        title = "注册协议"
    }
    private func setupProtocolView() {
        
        view.backgroundColor = UIColor.white
        
        let scrollV  = UIScrollView()
        scrollV.showsVerticalScrollIndicator = true
        scrollV.showsHorizontalScrollIndicator = false
        scrollV.bounces = false
//        scrollV.layer.borderColor = UIColor.green.cgColor//边框颜色
        scrollV.layer.borderWidth = 2//边框宽度
        
        let protocolLabel = UILabel()
        protocolLabel.numberOfLines = 0
//        protocolLabel.textColor = UIColor.darkGray
        protocolLabel.font = UIFont.systemFont(ofSize: 14)
        protocolLabel.lineBreakMode = .byWordWrapping; //设置换行模式 切断尾巴，按"开头..."显示
        protocolLabel.text = "欢迎您来到简书请您仔细阅读以下条款，如果您对本协议的任何条款表示异议，您可以选择不进入简书。当您注册成功，无论是进入简书，还是在知简书上发布任何内容，或者是直接或通过各类方式（如站外API引用等）间接使用简书网服务和数据的行为，都将被视作已无条件接受本声明所涉全部内容。若您对本声明的任何条款有异议，请停止使用简书网所提供的全部服务。\n使用规则\n1、用户注册成功后，简书将给予每个用户一个用户帐号及相应的密码，该用户帐号和密码由用户负责保管；用户应当对以其用户帐号进行的所有活动和事件负法律责任。\n2、用户须对在简书的注册信息的真实性、合法性、有效性承担全部责任，用户不得冒充他人；不得利用他人的名义发布任何信息；不得恶意使用注册帐号导致其他用户误认； 任何机构或个人注册和使用的互联网用户账号名称，不得有下列情形：\n一）违反宪法或法律法规规定的；\n（二）危害国家安全，泄露国家秘密，颠覆国家政权，破坏国家统一的；\n三）损害国家荣誉和利益的，损害公共利益的；\n（四）煽动民族仇恨、民族歧视，破坏民族团结的；\n（五）破坏国家宗教政策，宣扬邪教和封建迷信的；\n（六）散布谣言，扰乱社会秩序，破坏社会稳定的；\n（七）散布淫秽、色情、赌博、暴力、凶杀、恐怖或者教唆犯罪的；\n（八）侮辱或者诽谤他人，侵害他人合法权益的；\n（九）含有法律、行政法规禁止的其他内容的。\n关于用户名的管理\n请勿以党和国家领导人或其他名人的真实姓名、字、号、艺名、笔名、头衔等注册和使用昵 称（如确为本人，需要提交相关证据并通过审核方可允许使用）；\n请勿以国家组织机构或其他组织机构的名称等注册和使用昵称（如确为该机构，需要提交相关证据并通过审核方可允许使用）；\n请勿注册和使用与其他网友相同、相仿的名字或昵称；\n请勿注册和使用不文明、不健康的ID和昵称；\n请勿注册和使用易产生歧义、引起他人误解或带有各种奇形怪状符号的ID和昵称。\n用户以虚假信息骗取账号名称注册，或账号头像、简介等注册信息存在违法和不良信息的，简书将暂停或注销。\n用户连续一年没有在简书上更新动态，简书有权收回该用户昵称。\n3、简书是一个信息分享及传播的平台。用户通过简书发表的信息为公开的信息，其他第三方均可以通过简书获取用户发表的信息，用户对任何信息的发表即认可该信息为公开的信息，并单独对此行为承担法律责任；任何用户不愿被其他第三人获知的信息都不应该在简书上进行发表。\n4、用户承诺不得以任何方式利用简书直接或间接从事违反中国法律、以及社会公德的行为，简书有权对违反上述承诺的内容予以删除。\n5、简书用户不得利用简书服务制作、上载、复制、发布、传播或者转载如下内容：\n· 反对宪法所确定的基本原则的；\n· 危害国家安全，泄露国家秘密，颠覆国家政权，破坏国家统一的；\n· 损害国家荣誉和利益的；\n6、简书有权对用户使用简书的情况进行审查和监督，如用户在使用简书时违反任何上述规定，简书或其授权的人有权要求用户改正或直接采取一切必要的措施（包括但不限于更改或删除用户张贴的内容、暂停或终止用户使用简书的权利）以减轻用户不当行为造成的影响。\n知识产权\n简书是一个信息获取、分享及传播的平台，我们尊重和鼓励简书用户创作的内容，认识到保护知识产权对简书生存与发展的重要性，承诺将保护知识产权作为简书运营的基本原则之一。\n1、用户在简书上发表的全部原创内容，著作权均归用户本人所有。用户可授权第三方以任何方式使用，不需要得到简书的同意。\n2、简书提供的网络服务中包含的标识、版面设计、排版方式、文本、图片、图形等均受著作权、商标权及其它法律保护，未经相关权利人（含简书及其他原始权利人）同意，上述内容均不得在任何平台被直接或间接发布、使用、出于发布或使用目的的改写或再发行，或被用于其他任何商业目的。\n3、为了促进其创作内容的分享和传播，用户将其在简书上发表的全部内容，授予简书免费的、不可撤销的、非独家使用许可，简书有权将该内容用于简书各种形态的产品和服务上，包括但不限于网站以及发表的应用或其他互联网产品。\n个人隐私\n尊重用户个人隐私信息的私有性是简书的一贯原则，简书将通过技术手段、强化内部管理等办法充分保护用户的个人隐私信息，除法律或有法律赋予权限的政府部门要求或事先得到用户明确授权等原因外，简书保证不对外公开或向第三方透露用户个人隐私信息，或用户在使用服务时存储的非公开内容。\n同时，为了运营和改善简书的技术与服务，简书将可能会自行收集使用或向第三方提供用户的非个人隐私信息，这将有助于简书向用户提供更好的用户体验和服务质量。\n侵权举报\n1、处理原则\n简书高度重视自由表达和企业正当权利的平衡。依照法律规定删除违法信息是简书社区的法定义务，简书社区亦未与任何中介机构合作开展此项业务。\n2、受理范围\n受理简书社区内侵犯企业或个人合法权益的侵权举报，包括但不限于涉及个人隐私、造谣与诽谤、商业侵权。"
        
        // 动态计算label高度
        
        // 设置highLabel的最大宽和高
        let protocolLabelMaxSize = CGSize(width: UIScreen.main.bounds.width, height: 9999)
        
        //计算highLabel的实际frame
        let realSize = protocolLabel.sizeThatFits(protocolLabelMaxSize)//根据highLabel的最大宽和高计算highLabel实际尺寸
        protocolLabel.frame = CGRect(x: 0, y: 0, width: realSize.width, height: realSize.height)
        
        //计算scrollview的内容部分宽度，高度
        scrollV.contentSize = CGSize(width: protocolLabel.frame.width, height: protocolLabel.frame.height)
        
        scrollV.addSubview(protocolLabel)
        view.addSubview(scrollV)
        
        scrollV.snp.makeConstraints { (make) in
            make.edges.equalTo(view)
        }
//        protocolLabel.snp.makeConstraints { (make) in
//            make.edges.equalTo(view)
//            make.width.equalTo(scrollV)
//        }
    }
}
