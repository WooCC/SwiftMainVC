//
//  OfflineViewController.swift
//  yinuo
//
//  Created by Tim on 2018/1/10.
//  Copyright © 2018年 yinuo. All rights reserved.
//  线下

import UIKit
import Cosmos

class OfflineVC: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        setupNav()
        setupView()
    }

}

extension OfflineVC {
    private func setupNav() {
        
        // 导航左按钮
        let leftItemBtn = UIButton()
        leftItemBtn.adjustsImageWhenHighlighted = false
        leftItemBtn.frame = CGRect(x: 0, y: 0, width: 80, height: 30)
//        leftItemBtn.backgroundColor = UIColor.green
        leftItemBtn.titleLabel?.font = UIFont.systemFont(ofSize: 13.0)
        leftItemBtn.setImage(UIImage(named: "navMap"), for: .normal)
        leftItemBtn.setTitle("广州市", for: .normal)
        leftItemBtn.imageEdgeInsets = UIEdgeInsetsMake(0, -15, 0, 0)
        leftItemBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 6, 0, 0)
        leftItemBtn.addTarget(self, action: #selector(leftItemClick), for: .touchUpInside)
//        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: leftItemBtn)
        //用于消除左边空隙
        let spacer = UIBarButtonItem(barButtonSystemItem: .fixedSpace, target: nil, action: nil)
        spacer.width = -10;
        navigationItem.leftBarButtonItems = [spacer, UIBarButtonItem(customView: leftItemBtn)]
        
        
        // 导航中间控件
        let titleBtn = UIButton(frame: CGRect(x: 0, y: 0, width: 264, height: 33))
        titleBtn.setBackgroundImage(UIImage(named: "navSearch2"), for: .normal)
        titleBtn.setTitle("搜索店铺", for: .normal)
        titleBtn.setTitleColor(UIColor.yinuoTopicColor(), for: .normal)
        titleBtn.titleLabel?.font = UIFont.systemFont(ofSize: 12.0)
        titleBtn.contentHorizontalAlignment = .left
        titleBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 35, 0, 0)
        titleBtn.adjustsImageWhenHighlighted = false
        titleBtn.addTarget(self, action: #selector(searchClick), for: .touchUpInside)
        navigationItem.titleView = titleBtn
    }
    private func setupView() {
        view.backgroundColor = UIColor.white
    }
    
}

extension OfflineVC {
    
}

extension OfflineVC {
    @objc private func moreShopClick() {
        println("more shop click")
    }
    @objc private func leftItemClick() {
        println("map click")
    }
    @objc private func searchClick() {
        println("search click")
    }
}
