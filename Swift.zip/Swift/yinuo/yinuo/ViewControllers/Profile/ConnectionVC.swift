//
//  ConnectionVC.swift
//  yinuo
//
//  Created by tim on 2018/3/19.
//  Copyright © 2018年 yinuo. All rights reserved.
//  我的人脉

import UIKit
import ObjectMapper
import RxSwift
import Moya
import MJRefresh

class ConnectionVC: UITableViewController {

    private lazy var mjHeader = MJRefreshNormalHeader()
    private lazy var mjFooter = MJRefreshAutoNormalFooter()
    var listObjArr: [ConnectionListModel]?
    private var num1 = 0
    private var num2 = 0
    let disposeBag = DisposeBag()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupNav()
        setupUI()
        getData()
    }
    
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerV = ConnectionHeaderView()
        headerV.num1L.text = "\(num1)"
        headerV.num2L.text = "\(num2)"
        headerV.resultRespontBlock = { tag in
            self.getData(page: 1, count: 20, type: tag - 1)
        }
        return headerV
    }
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 170
    }
    
    private func setupNav() {
        title = "我的人脉"
    }
    
    private func setupUI() {
        tableView.separatorStyle = .none
        tableView.showsVerticalScrollIndicator = false
        tableView.rowHeight = 70.0
        view.backgroundColor = UIColor.yinuoViewBackgroundColor()
        
        // 注册Cell
        tableView.registerClassOf(ConnectionCell.self)
        
        // 上下拉刷新
        mjHeader.setRefreshingTarget(self, refreshingAction: #selector(headerLoad))
        tableView.mj_header = mjHeader
        mjFooter.setRefreshingTarget(self, refreshingAction: #selector(footerLoad))
        tableView.mj_footer = mjFooter
    }
    
    private func getData(page: Int = 1, count: Int = 20, type: Int = 0) {

        YiNuoBeginLoading()
        
        let provider = ApiProfile.provider
        provider.rx.request(.getConnectionList(page: page, count: count, type: type)).filterSuccessfulStatusCodes().mapObject(ResultModel<ConnectionModel>.self).subscribe(onSuccess: { (response) in

            if response.code != 0 {
                YiNuoHUD.inform(response.errorMsg)
            }else {
                // 正确
                YiNuoEndLoading()
                
                let listData: ConnectionModel = response.data!
                self.listObjArr = listData.list
                self.num1 = listData.one
                self.num2 = listData.two
                self.tableView?.reloadData()
                
            }
        }) { (error) in
            
            YiNuoHUD.error("网络错误")
        }.disposed(by: disposeBag)
        
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return listObjArr?.count ?? 0
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let connectionCell: ConnectionCell = tableView.dequeueReusableCell()
        connectionCell.connectionListModel = listObjArr?[indexPath.row]
        return connectionCell
    }

}

extension ConnectionVC {
    @objc private func headerLoad() {
        getData(page: 0, count: 20, type: 0)
    }
    
    @objc private func footerLoad() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            
            self.mjFooter.endRefreshingWithNoMoreData()
        }
    }
}
