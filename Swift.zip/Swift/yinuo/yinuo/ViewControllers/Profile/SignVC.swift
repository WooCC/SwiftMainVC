//
//  SignVC.swift
//  yinuo
//
//  Created by tim on 2018/3/8.
//  Copyright © 2018年 yinuo. All rights reserved.
//  手写签名

import UIKit

class SignVC: UIViewController {
    
    private lazy var saveBtn = UIButton()
    private lazy var clearBtn = UIButton()
    private lazy var cancleBtn = UIButton()
    private lazy var drawV = DrawSignView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor.gray
        
        saveBtn.setTitle("保存", for: .normal)
        saveBtn.setTitleColor(UIColor.black, for: .normal)
        saveBtn.backgroundColor = UIColor.brown
        saveBtn.addTarget(self, action: #selector(saveDraw), for: .touchUpInside)
        
        clearBtn.setTitle("清除", for: .normal)
        clearBtn.setTitleColor(UIColor.black, for: .normal)
        clearBtn.backgroundColor = UIColor.brown
        clearBtn.addTarget(self, action: #selector(clearDraw), for: .touchUpInside)
        
        cancleBtn.setTitle("取消", for: .normal)
        cancleBtn.setTitleColor(UIColor.black, for: .normal)
        cancleBtn.backgroundColor = UIColor.brown
        cancleBtn.addTarget(self, action: #selector(cancleDraw), for: .touchUpInside)
        
        view.addSubview(drawV)
        view.addSubview(saveBtn)
        view.addSubview(clearBtn)
        view.addSubview(cancleBtn)
        
        drawV.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(300)
        }
        saveBtn.snp.makeConstraints { (make) in
            make.width.equalTo((SCREEN_WIDTH - 5*2 - 10*2)/3)
            make.height.equalTo(30)
            make.bottom.equalToSuperview()
            make.centerX.equalToSuperview()
        }
        clearBtn.snp.makeConstraints { (make) in
            make.width.height.bottom.equalTo(saveBtn)
            make.left.equalToSuperview().offset(5)
        }
        cancleBtn.snp.makeConstraints { (make) in
            make.width.height.bottom.equalTo(saveBtn)
            make.right.equalToSuperview().offset(-5)
        }
        
    }
    
}

extension SignVC {
    @objc private func saveDraw() {
        let signImg = drawV.getSignImage()
        UIImageWriteToSavedPhotosAlbum(signImg, self, #selector(saveImage(image:didFinishSavingWithError:contextInfo:)), nil)
    }
    
    @objc private func clearDraw() {
        drawV.clearSign()
    }
    
    @objc private func cancleDraw() {
        drawV.clearSign()
        dismiss(animated: true, completion: nil)
    }
    
    @objc func saveImage(image: UIImage, didFinishSavingWithError: NSError?, contextInfo: AnyObject) {
        guard didFinishSavingWithError == nil else {
            YiNuoError("签名保存失败")
            return
        }
        YiNuoSuccess("签名保存成功")
    }
}
