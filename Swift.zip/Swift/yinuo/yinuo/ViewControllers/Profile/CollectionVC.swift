//
//  CollectionVC.swift
//  yinuo
//
//  Created by tim on 2018/2/28.
//  Copyright © 2018年 yinuo. All rights reserved.
//  收藏商品/店铺

import UIKit

class CollectionVC: UIViewController {

    private lazy var titlesV = UIView()
    private lazy var titleUnderlineV = UIView()
    private lazy var scrollV = UIScrollView()
    private lazy var bottomV = UIView()
    var bottomViewH: CGFloat = 60.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupNav()
        setupAllChildVC()
        setupScrollView()
        setupTitlesView()
        setupBottomView()
    }
    

}

extension CollectionVC {
    private func setupNav() {
        title = "我的收藏"
        navigationController?.navigationBar.tintColor = UIColor.white
        
        let rightBarBtn = UIButton()
        rightBarBtn.setTitle("编辑", for: .normal)
        rightBarBtn.addTarget(self, action: #selector(rightBarItemClick(sender:)), for: .touchUpInside)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: rightBarBtn)
    }
    private func setupAllChildVC() {
        addChildViewController(GoodsCollectionVC())
        addChildViewController(ShopsCollectionVC())
    }
    private func setupScrollView() {
        
        scrollV.frame = self.view.bounds
        scrollV.backgroundColor = UIColor.yinuoViewBackgroundColor()
        scrollV.showsVerticalScrollIndicator = false
        scrollV.showsHorizontalScrollIndicator = false
        scrollV.isPagingEnabled = true
        scrollV.delegate = self
        scrollV.bounces = false
        view.addSubview(scrollV)
        
        // 添加子控制器的View
        let childVCCount = childViewControllers.count
        let scrollViewW = scrollV.yinuo_width
        let scrollViewH = scrollV.yinuo_height
        for i in 0..<childVCCount {
            var childVCView: UIView?
            let vc = childViewControllers[i]

            if vc is UICollectionViewController {
                if let collectionV = vc as? UICollectionViewController {
                    childVCView = collectionV.collectionView
                }
            }else{
                childVCView = vc.view
            }
            
            childVCView?.frame = CGRect(x: scrollViewW * CGFloat(i), y: 0, width: scrollViewW, height: scrollViewH)
            scrollV.addSubview(childVCView!)
        }
        scrollV.contentSize = CGSize(width: CGFloat(childVCCount) * scrollViewW, height: 0)
    }
    private func setupTitlesView() {
        titlesV.backgroundColor = UIColor(white: 1.0, alpha: 0.9)
        titlesV.frame = CGRect(x: 0, y: 0, width: self.view.yinuo_width, height: YiNuoConfig.Profile.titlesViewH)
        view.addSubview(titlesV)
        
        setupTitleButton()
        setupTitleUnderLine()
        
    }
    private func setupTitleButton() {
        let titles = ["收藏商品", "收藏商家"]
        let btnW = titlesV.yinuo_width/2
        let btnH = titlesV.yinuo_height
        for i in 0..<titles.count {
            let titleBtn = TitleButton()
            titleBtn.tag = i
            titleBtn.addTarget(self, action: #selector(titleBtnClick(sender:)), for: .touchUpInside)
            titleBtn.frame = CGRect(x: CGFloat(i) * btnW, y: 0, width: btnW, height: btnH)
            titleBtn.setTitle(titles[i], for: .normal)
            titlesV.addSubview(titleBtn)
//            if i == 0 {
//                titleBtn.isSelected = true
//            }
        }
        
        
        
    }
    private func setupTitleUnderLine() {
        
        if let firstTitleBtn = titlesV.subviews.first as? TitleButton {
            titleUnderlineV.backgroundColor = firstTitleBtn.titleColor(for: .selected)
            titlesV.addSubview(titleUnderlineV)
            
            firstTitleBtn.titleLabel?.sizeToFit() // 解决iOS8后button中titleLabel未完全初始化而导致获取frame空
            titleUnderlineV.snp.makeConstraints { (make) in
                make.width.equalTo(firstTitleBtn.titleLabel!.yinuo_width + 20)
                make.height.equalTo(2)
                make.bottom.equalToSuperview()
                make.centerX.equalTo(firstTitleBtn)
            }
            firstTitleBtn.isSelected = true

        }
        
    }
    private func setupBottomView() {
        bottomV.backgroundColor = UIColor.white
//        let topLineLayer = CALayer()
//        topLineLayer.frame = CGRect(x: 0, y: 0, width: bottomView.yinuo_width, height: 0.5)
//        topLineLayer.backgroundColor = UIColor.red.cgColor
//        bottomView.layer.addSublayer(topLineLayer)
        bottomV.isHidden = true
        view.addSubview(bottomV)
        
        bottomV.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(bottomViewH)
        }
    }
}

extension CollectionVC {
    @objc private func rightBarItemClick(sender: UIButton) {
        
        sender.isSelected = !sender.isSelected
        let title = sender.isSelected ? "取消" : "编辑"
        sender.setTitle(title, for: .normal)
        bottomV.isHidden = sender.isSelected ? false : true
        
        let index = scrollV.contentOffset.x / scrollV.yinuo_width
        let childView = scrollV.subviews[Int(index)]
        
        if let tableView = childView as? UITableView {
            // 在编辑模式下多选
            tableView.allowsMultipleSelectionDuringEditing = !tableView.isEditing
            tableView.setEditing(!tableView.isEditing, animated: true)
            // 底部控件遮挡，偏移修改
            let edgeTop: CGFloat = YiNuoConfig.Profile.titlesViewH
            let edgeBottom: CGFloat = sender.isSelected ? bottomViewH + NavigationBarHeight : 0
            tableView.contentInset = UIEdgeInsets(top: edgeTop, left: 0, bottom: edgeBottom, right: 0)
        }
        
        
        if let collectionView = childView as? UICollectionView {
            let vc = childViewControllers[Int(index)] as! GoodsCollectionVC
            for (index, dataObj) in vc.dataObjArr!.enumerated() {
                // 显示/隐藏可选按钮
                dataObj.isHidden = !sender.isSelected
                dataObj.isSelect = false
                // 清除选中状态
                let indexPath = IndexPath(row: index, section: 0)
                if let collectionCell = collectionView.cellForItem(at: indexPath) as? GoodsCollectionCell {
                    collectionCell.selBtn.isSelected = false
                }
            }
            vc.collectionView?.reloadData()
            
        }
        
        
        
        
    }
    @objc func titleBtnClick(sender: TitleButton) {
        // 清除所有按钮选中
        for view in titlesV.subviews {
            if let btn = view as? TitleButton {
                btn.isSelected = false
            }
        }
        // 当前选中
        sender.isSelected = true
        
        // 动画
        let offsexX = scrollV.yinuo_width * CGFloat(sender.tag)
        UIView.animate(withDuration: 0.25) {
            // 处理下划线
            self.titleUnderlineV.snp.remakeConstraints { (make) in
                make.width.equalTo(sender.titleLabel!.yinuo_width + 20)
                make.height.equalTo(2)
                make.bottom.equalToSuperview()
                make.centerX.equalTo(sender)
            }
            // 主内容区
            self.scrollV.contentOffset = CGPoint(x: offsexX, y: self.scrollV.contentOffset.y)
            
            self.view.layoutIfNeeded()
        }
    }
}

extension CollectionVC: UIScrollViewDelegate {
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let index = scrollView.contentOffset.x / scrollView.yinuo_width
        let titleBtn = titlesV.subviews[Int(index)] as! TitleButton
        titleBtnClick(sender: titleBtn)
    }
    
}
