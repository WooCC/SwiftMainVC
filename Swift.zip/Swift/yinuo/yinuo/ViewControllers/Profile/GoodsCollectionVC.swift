//
//  GoodsCollectionVC.swift
//  yinuo
//
//  Created by tim on 2018/3/1.
//  Copyright © 2018年 yinuo. All rights reserved.
//  商品收藏列表

import UIKit
import ObjectMapper

private let reuseIdentifier = "GoodsCollectCell"

class GoodsCollectionVC: UICollectionViewController {
    
    var dataObjArr: [GoodsCollectionModel]?
    
    init(){
        
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 5                      //设置最小间距(行间距)
        layout.minimumInteritemSpacing = 5                 //设置最小间距(左右间距)
        layout.itemSize = CGSize(width: 185, height: 255)     //cell大小
        layout.sectionInset = UIEdgeInsets(top: 10, left: 0, bottom: 10, right: 0) // 内边距0
        layout.scrollDirection = .vertical
        
        super.init(collectionViewLayout: layout)
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        collectionView!.allowsMultipleSelection = true         // 允许用户多选
        collectionView!.backgroundColor = UIColor.yinuoViewBackgroundColor()
        collectionView!.showsVerticalScrollIndicator = false
        collectionView!.register(GoodsCollectionCell.self, forCellWithReuseIdentifier: reuseIdentifier)
        collectionView?.contentInset = UIEdgeInsets(top: YiNuoConfig.Profile.titlesViewH, left: 0, bottom: TabbarHeight+5, right: 0)
        
        getData()
    }

}

extension GoodsCollectionVC {
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return dataObjArr!.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifier, for: indexPath) as! GoodsCollectionCell
        cell.goodsModel = dataObjArr?[indexPath.row]
        return cell
    }
    
    /**
     * Cell选中调用该方法
     */
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let cell = collectionView.cellForItem(at: indexPath) as! GoodsCollectionCell
        changeSelectStateWithIndexPath(indexPath: indexPath)
    }
    /**
     * Cell取消选中调用该方法
     */
    override func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        changeSelectStateWithIndexPath(indexPath: indexPath)
    }
}

extension GoodsCollectionVC {
    /**
     * Cell根据Cell选中状态来改变Cell上Button按钮的状态
     */
    private func changeSelectStateWithIndexPath(indexPath: IndexPath) {
        //获取当前变化的Cell
        let currentSelecteCell = collectionView?.cellForItem(at: indexPath)  as! GoodsCollectionCell
        currentSelecteCell.selBtn.isSelected = currentSelecteCell.isSelected
        // 修改模型数据
        let dataObj = dataObjArr![indexPath.row]
        dataObj.isSelect = true
        
        if currentSelecteCell.isSelected == true {
            println("第\(indexPath.row)个Cell被选中")
        }
        if currentSelecteCell.isSelected == false {
            println("第\(indexPath.row)个Cell被取消")
        }
    }
    
    private func getData() {
        var items = [
            ["imgName": "goods_collect1", "title": "1经典宽松拼色一字领女士毛呢衫藏青色+浅棕色", "price": "792.00"],
            ["imgName": "goods_collect1", "title": "2经典宽松拼色一字领女士毛呢衫藏青色+浅棕色", "price": "792.00"],
            ["imgName": "goods_collect1", "title": "3经典宽松拼色一字领女士毛呢衫藏青色+浅棕色", "price": "792.00"],
            ["imgName": "goods_collect1", "title": "4经典宽松拼色一字领女士毛呢衫藏青色+浅棕色", "price": "792.00"],
            ["imgName": "goods_collect1", "title": "5经典宽松拼色一字领女士毛呢衫藏青色+浅棕色", "price": "792.00"],
            ["imgName": "goods_collect1", "title": "6经典宽松拼色一字领女士毛呢衫藏青色+浅棕色", "price": "792.00"],
            ["imgName": "goods_collect1", "title": "7经典宽松拼色一字领女士毛呢衫藏青色+浅棕色", "price": "792.00"],
            ["imgName": "goods_collect1", "title": "8经典宽松拼色一字领女士毛呢衫藏青色+浅棕色", "price": "792.00"],
            ["imgName": "goods_collect1", "title": "9经典宽松拼色一字领女士毛呢衫藏青色+浅棕色", "price": "792.00"],
            ["imgName": "goods_collect1", "title": "10经典宽松拼色一字领女士毛呢衫藏青色+浅棕色", "price": "792.00"],
            ["imgName": "goods_collect1", "title": "11经典宽松拼色一字领女士毛呢衫藏青色+浅棕色", "price": "792.00"],
            ["imgName": "goods_collect1", "title": "12经典宽松拼色一字领女士毛呢衫藏青色+浅棕色", "price": "792.00"],
            ["imgName": "goods_collect1", "title": "13经典宽松拼色一字领女士毛呢衫藏青色+浅棕色", "price": "792.00"],
            ["imgName": "goods_collect1", "title": "14经典宽松拼色一字领女士毛呢衫藏青色+浅棕色", "price": "792.00"]
        ]
        //        http://www.hangge.com/blog/cache/detail_1673.html
        dataObjArr = Mapper<GoodsCollectionModel>().mapArray(JSONArray: items)
        collectionView?.reloadData()
    }
}
