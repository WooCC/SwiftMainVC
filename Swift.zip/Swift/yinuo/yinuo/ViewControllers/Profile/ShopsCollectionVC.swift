//
//  ShopsCollectionVC.swift
//  yinuo
//
//  Created by tim on 2018/3/1.
//  Copyright © 2018年 yinuo. All rights reserved.
//  店铺收藏列表

import UIKit

class ShopsCollectionVC: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor.white
        
        setupUI()
    }

}

extension ShopsCollectionVC {
    
    private func setupUI() {
        tableView.contentInset = UIEdgeInsets(top: YiNuoConfig.Profile.titlesViewH, left: 0, bottom: TabbarHeight+10, right: 0)
        tableView.rowHeight = 115
        tableView.separatorStyle = .none
        tableView.backgroundColor = UIColor.yinuoViewBackgroundColor()
    }
}

extension ShopsCollectionVC {
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 15
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let ID = "ShopCollectionCell";
        var cell = tableView.dequeueReusableCell(withIdentifier: ID) as? ShopsCollectionCell
        if cell == nil {
            cell = ShopsCollectionCell(style: .default, reuseIdentifier: ID)
        }
        cell?.imgV.image = UIImage(named: "shop_col1")
        cell?.nameL.text = "悦诗风吟"
        cell?.descL.text = "123445"
        
        return cell!;
    }
}
