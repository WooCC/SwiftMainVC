//
//  RankingVC.swift
//  yinuo
//
//  Created by Tim on 2018/2/7.
//  Copyright © 2018年 yinuo. All rights reserved.
//  排行榜

import UIKit

class RankingVC: UITableViewController {

    lazy var titleArr = {
        return [["title":"当日地区销售排行", "subTitle":"排行TOP前200"],["title":"角色分布图", "subTitle":""]]
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupNav()
        setupUI()
    }
    
}

extension RankingVC {
    private func setupNav() {
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
    }
    private func setupUI() {
        
        if #available(iOS 11.0, *) {
            tableView.contentInsetAdjustmentBehavior = .never
        } else {
            automaticallyAdjustsScrollViewInsets = false;
        }
        tableView.contentInset = UIEdgeInsetsMake(0, 0, NavigationBarHeight, 0)
        
        tableView.separatorStyle = .none
        tableView.showsVerticalScrollIndicator = false
        view.backgroundColor = UIColor.yinuoViewBackgroundColor()
        
        tableView.tableHeaderView = RankingHeaderView(frame: CGRect(x: 0, y: 0, width: 0, height: 155))
        tableView.tableFooterView = RankingFooterView(frame: CGRect(x: 0, y: 0, width: 0, height: 115))
        
    }
}

extension RankingVC {
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        if indexPath.section == 0 {
            let identifier = "RankingNoticeCell"
            let cell = RankingNoticeCell(style: .default, reuseIdentifier: identifier)
            return cell
        }else if indexPath.section == 1 {
            let identifier = "RankingCell"
            let cell = RankingCell(style: .default, reuseIdentifier: identifier)
            var titleDic = titleArr[indexPath.row]
            cell.titleL?.text = titleDic["title"]!
            cell.subTitleL?.text = titleDic["subTitle"]!
            cell.imgBtn?.setImage(UIImage(named: "rankingAd\(indexPath.row + 1)"), for: .normal)
            cell.imgBtn?.addTarget(self, action: #selector(cellClick), for: .touchUpInside)
            return cell
        }
        
        return UITableViewCell()
    }
    
    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 1 {
            return 2
        }
        return 1
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 {
            return 40
        }else if indexPath.section == 1 {
            return 118
        }
        return 0
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0 {
            return 10
        }
        return 0
    }
    
    override func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        if section == 1 {
            return 10
        }
        return 0
    }
    
    // 解决 ios11 header/footer section高度无效
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return UIView()
    }
    override func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
    
}

extension RankingVC {
    @objc private func cellClick() {
        println("cell click")
    }
}
