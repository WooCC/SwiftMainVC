//
//  BackCardManageVC.swift
//  yinuo
//
//  Created by 吴承炽 on 2018/3/20.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit
import ObjectMapper

class BankCardManageVC: YiNuoUIViewController {
    
    //中间间距
    var topOffset = 1.0
    
    var containerScrollView = UIScrollView()
    
    //登录密码
    var accountNameView = YiNuoTitleInputIconTextField()
    //支付密码
    var bankCardView = YiNuoTitleInputIconTextField()
    
    required override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil);
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupView()
    }
}

extension BankCardManageVC {
    
    private func setupView() {
        self.title = "添加银行卡"
        self.view.backgroundColor = UIColor.yinuoViewBackgroundColor()
        
//        let rightItemImg = UIImage(named: "add_icon")?.withRenderingMode(.alwaysOriginal)
//        navigationItem.rightBarButtonItem = UIBarButtonItem(image: rightItemImg, style: .plain, target: self, action: #selector(msgBtnClick))
        
        let rightItemImg = UIButton()
        rightItemImg.adjustsImageWhenHighlighted = false
        rightItemImg.frame = CGRect(x: 0, y: 0, width: 80, height: 30)
        //        leftItemBtn.backgroundColor = UIColor.green
        rightItemImg.titleLabel?.font = UIFont.systemFont(ofSize: 13.0)
        rightItemImg.setImage(UIImage(named: "add_icon"), for: .normal)
        rightItemImg.setTitle("添加", for: .normal)
        rightItemImg.imageEdgeInsets = UIEdgeInsetsMake(0, -15, 0, 0)
        rightItemImg.titleEdgeInsets = UIEdgeInsetsMake(0, 6, 0, 0)
        rightItemImg.addTarget(self, action: #selector(msgBtnClick), for: .touchUpInside)
        //        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: leftItemBtn)
        //用于消除左边空隙
        let spacer = UIBarButtonItem(barButtonSystemItem: .fixedSpace, target: nil, action: nil)
        spacer.width = -10;
        navigationItem.rightBarButtonItems = [spacer, UIBarButtonItem(customView: rightItemImg)]
        
        
        self.view.addSubview(containerScrollView)
        
        containerScrollView.addSubview(accountNameView)
        containerScrollView.addSubview(bankCardView)
        
        accountNameView.setTitle(text: "开户姓名")
        accountNameView.setPlaceholder(text: "请输入开户姓名")
        accountNameView.setContent(text: "")
        accountNameView.showIcon(show: false)
        
        bankCardView.setTitle(text: "银行卡号")
        bankCardView.setPlaceholder(text: "请输入银行卡号")
        bankCardView.setContent(text: "")
        bankCardView.showIcon(show: false)
//        accountNameView.addTarget(self, action:#selector(loginCodeButtonAction(sender:)), for:.touchUpInside)
//        bankCardView.addTarget(self, action:#selector(payCodeButtonAction(sender:)), for:.touchUpInside)
        
        containerScrollView.snp.makeConstraints { (make) in
            make.width.equalToSuperview()
            make.height.equalTo(50)
            make.left.right.top.bottom.equalToSuperview().offset(0)
        }
        accountNameView.snp.makeConstraints { (make) in
            make.width.equalToSuperview()
            make.height.equalTo(50)
            make.left.right.equalTo(0)
            make.top.equalTo(topOffset)
        }
        bankCardView.snp.makeConstraints { (make) in
            make.width.equalToSuperview()
            make.height.equalTo(50)
            make.left.right.equalTo(0)
            make.top.equalTo(accountNameView.snp.bottom).offset(topOffset)
        }
    }
    
    @objc func loginCodeButtonAction(sender : UIButton?) {
        let vc = ProfileSecurityLoginCodeChoiceVC()
        navigationController?.pushViewController(vc, animated: true)
    }
    
    @objc func payCodeButtonAction(sender : UIButton?) {
        let vc = ProfileSecurityPayCodeChoiceVC()
        navigationController?.pushViewController(vc, animated: true)
    }
    
}

extension BankCardManageVC {
    @objc private func msgBtnClick() {
        println("顶部按钮")
        let bankCardDetailVc = BankCardDetailVC()
        navigationController?.pushViewController(bankCardDetailVc, animated: true)
//        let loginNav = YiNuoNavigationViewController(rootViewController: loginVc)
//        present(loginNav, animated: true, completion: nil)
}
}
