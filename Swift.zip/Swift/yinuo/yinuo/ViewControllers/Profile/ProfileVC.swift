//
//  ProfileVC.swift
//  yinuo
//
//  Created by Tim on 2018/1/21.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit
import ObjectMapper
import MJRefresh
import DeviceKit

class ProfileVC: UIViewController {
    
//    private lazy var mjHeader = MJRefreshNormalHeader()
//    var menuObjArr: [[ProfileMenuModel]]?
//    var recommendObjArr: [ProfileRecommendModel]?
    
//    init(){
//        super.init(collectionViewLayout: UICollectionViewFlowLayout())
//    }
    
//    required init?(coder aDecoder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupNav()
        setupView()
        getTestData()
    }
    
}

extension ProfileVC {
    private func setupNav() {
        navigationController?.navigationBar.isTranslucent = false // 关闭半透明
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)  // 删除导航下方分割线
        self.navigationController?.navigationBar.shadowImage = UIImage()
    }
    private func setupView() {
       self.view.backgroundColor = UIColor.yinuoViewBackgroundColor()
    }
    
    private func getTestData() {
       
    }
    
    
   
}

