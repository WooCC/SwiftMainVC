//
//  RegistrationCodeVC.swift
//  yinuo
//
//  Created by Tim on 2018/3/5.
//  Copyright © 2018年 yinuo. All rights reserved.
//  注册码

import UIKit
import CoreImage

class RegistrationCodeVC: UIViewController {

    private var QRCodeImgV: UIImageView?
    private var logoImg: UIImage?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor.white
        
        setupNav()
        setupUI()
        
    }
    
    private func setupNav() {
        title = "注册码"
        
        //item颜色
        navigationController?.navigationBar.tintColor = UIColor.white
    }
    
    private func setupUI() {
        
        let linkString = "http://www.yinuoshangcheng.com"
        QRCodeImgV = UIImageView()
        logoImg = UIImage(named: "qrcode")
        view.addSubview(QRCodeImgV!)
        
        DispatchQueue.global().async {
            // 异步图片合成
            let image = linkString.generateQRCode(size: 200, color: UIColor.black, bgColor: UIColor.white, logo: self.logoImg, radius: 5, borderLineWidth: 1, borderLineColor: UIColor.white, boderWidth: 4, borderColor: UIColor.white)
            DispatchQueue.main.async(execute: {
                // 回到主线程
                self.QRCodeImgV?.image = image
            })
            
        }
        
        
        QRCodeImgV?.snp.makeConstraints { (make) in
            make.width.height.equalTo(200)
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(150)
        }
    }
    
    

}
