//
//  HomeViewController.swift
//  yinuo
//
//  Created by Tim on 2018/1/10.
//  Copyright © 2018年 yinuo. All rights reserved.
//  首页(线上)

import UIKit
import MJRefresh
import Moya
import RxSwift

class HomeVC: UITableViewController {
    
//    private lazy var mjHeader = MJRefreshNormalHeader()
//    private lazy var mjFooter = MJRefreshAutoNormalFooter()
//    let disposeBag = DisposeBag()
    
    // MARK:- 系统回调函数
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupNav()
        setupUI()
        
    }
    
}

// MARK:- 设置UI界面
extension HomeVC {
    private func setupNav() {
        // 设置导航Item
        let leftItemImg = UIImage(named: "navQRCode")?.withRenderingMode(.alwaysOriginal)
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: leftItemImg, style: .plain, target: self, action: #selector(qrcodeClick))
        let rightItemImg = UIImage(named: "navMessage")?.withRenderingMode(.alwaysOriginal)
        navigationItem.rightBarButtonItem = UIBarButtonItem(image: rightItemImg, style: .plain, target: self, action: #selector(msgBtnClick))
        
        
        // 设置中间的titleView
        let titleBtn = UIButton(frame: CGRect(x: 0, y: 0, width: 264, height: 33))
        titleBtn.setBackgroundImage(UIImage(named: "navSearch"), for: .normal)
        titleBtn.setTitle("搜索商品/店铺", for: .normal)
        titleBtn.setTitleColor(UIColor.yinuoInputPlaceholderTextColor(), for: .normal)
        titleBtn.titleLabel?.font = yinuoFont(12.0)
        titleBtn.contentHorizontalAlignment = .left
        titleBtn.titleEdgeInsets = UIEdgeInsetsMake(0, 15, 0, 0)
        titleBtn.adjustsImageWhenHighlighted = false
        titleBtn.addTarget(self, action: #selector(searchClick), for: .touchUpInside)
        navigationItem.titleView = titleBtn
    }
    
    private func setupUI() {
        tableView.separatorStyle = .none
        tableView.showsVerticalScrollIndicator = false
        view.backgroundColor = UIColor.yinuoViewBackgroundColor()
        
        // 注册Cell
        tableView.registerClassOf(HomeCell.self)
        tableView.registerClassOf(HomeSliderCell.self)
        tableView.registerClassOf(HomeMenuCell.self)
        
        // 上下拉刷新
//        mjHeader.setRefreshingTarget(self, refreshingAction: #selector(headerLoad))
//        tableView.mj_header = mjHeader
//        mjFooter.setRefreshingTarget(self, refreshingAction: #selector(footerLoad))
//        //        //是否自动加载（默认为true，即表格滑到底部就自动加载）
//        //        mjFooter.isAutomaticallyRefresh = false
//        tableView.mj_footer = mjFooter
        
    }
}

// MARK:- 事件监听
extension HomeVC {
    @objc private func msgBtnClick() {
        println("msg click")
        let loginVc = LoginVC()
        let loginNav = YiNuoNavigationViewController(rootViewController: loginVc)
        present(loginNav, animated: true, completion: nil)
    }
    @objc private func qrcodeClick() {
        let scanQRCodeVc = ScanQRCodeVC()
        let scanNav = UINavigationController(rootViewController: scanQRCodeVc)
        present(scanNav, animated: true, completion: nil)
        println("qrcode click")
    }
    @objc private func searchClick() {
        println("search click")
    }
    @objc private func headerLoad() {
        println("headerLoad")
        YiNuoBeginLoading()
//        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
//            self.mjHeader.endRefreshing()
//            YiNuoEndLoading()
//        }
        
    }
    @objc private func footerLoad() {
        println("footerLoad")
//        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
//            self.mjFooter.endRefreshingWithNoMoreData()
//        }
        
    }
}

extension HomeVC {
    
   
    
}

