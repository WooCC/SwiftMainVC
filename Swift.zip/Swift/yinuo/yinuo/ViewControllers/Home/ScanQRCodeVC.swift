//
//  ScanQRCodeVC.swift
//  yinuo
//
//  Created by Tim on 2018/1/14.
//  Copyright © 2018年 yinuo. All rights reserved.
//  扫描二维码

import UIKit

class ScanQRCodeVC: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor.white
        
        setupNav()
    }
    
    // 设置导航栏
    private func setupNav() {
        
        navigationController?.navigationBar.barStyle = .black       //状态栏颜色
        navigationController?.navigationBar.barTintColor = UIColor.yinuoNavBarTintColor()       // 导航颜色
        navigationController?.navigationBar.tintColor = UIColor.white   //item颜色
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "关闭", style: .plain, target: self, action: #selector(closeItemClick))
        
        title = "扫码"
    }
    
    // 关闭界面
    @objc private func closeItemClick() {
        dismiss(animated: true, completion: nil)
    }

}
