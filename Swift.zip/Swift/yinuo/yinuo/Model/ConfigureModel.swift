//
//  ConfigureModel.swift
//  yinuo
//
//  Created by tim on 2018/3/15.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import ObjectMapper
import Alamofire

class ConfigureModel: BaseJsonModel {
    var serverTime: Int = 0             // 服务器时间戳
    var signSalt: String?               // api接口中URL签名盐值
    var startupAdImg: String?           // 启动广告图
    
    override func mapping(map: Map) {
        serverTime          <- map["serverTime"]
        signSalt            <- map["signSalt"]
        startupAdImg        <- map["startupAdImg"]
    }
}
