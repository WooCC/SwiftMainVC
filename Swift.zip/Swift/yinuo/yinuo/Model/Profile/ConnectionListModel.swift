//
//  ConnectionListModel.swift
//  yinuo
//
//  Created by tim on 2018/3/20.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import ObjectMapper

class ConnectionListModel: BaseJsonModel {
    
    var img: String?                      // 主图
    var tel: String?                      // 手机
    var level: String?                    // 等级
    var time: String?                     // 时间
    
    override func mapping(map: Map) {
        img               <- map["img"]
        tel               <- map["tel"]
        level             <- map["level"]
        time              <- map["time"]
    }
}
