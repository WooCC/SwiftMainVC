//
//  ProfileRecommendModel.swift
//  yinuo
//
//  Created by tim on 2018/3/8.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import ObjectMapper

class ProfileRecommendModel: BaseJsonModel {
    
    var image: String?                      // 主图
    var title: String?                      // 标题
    var brand: String?                      // 品牌
    var isFreeDelivery: Bool = false        // 是否包邮
    var salesVolume: Int = 0                // 销量
    var price: Double = 0                   // 价格
    var loveNum: Double = 0                 // 爱心数
    
    override func mapping(map: Map) {
        image               <- map["image"]
        title               <- map["title"]
        brand               <- map["brand"]
        isFreeDelivery      <- map["isFreeDelivery"]
        salesVolume         <- map["salesVolume"]
        price               <- map["price"]
        loveNum             <- map["loveNum"]
    }
}
