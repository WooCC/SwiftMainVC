//
//  ConnectionModel.swift
//  yinuo
//
//  Created by tim on 2018/3/20.
//  Copyright © 2018年 yinuo. All rights reserved.
//  我的人脉模型

import ObjectMapper

class ConnectionModel: BaseJsonModel {
    
    var one: Int = 0
    var two: Int = 0
    var list: [ConnectionListModel]?
    
    override func mapping(map: Map) {
        one               <- map["one"]
        two               <- map["two"]
        list             <- map["list"]
    }
}
