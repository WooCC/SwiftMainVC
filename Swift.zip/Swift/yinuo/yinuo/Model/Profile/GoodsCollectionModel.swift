//
//  GoodsCollectionModel.swift
//  yinuo
//
//  Created by Tim on 2018/3/4.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import ObjectMapper

class GoodsCollectionModel: BaseJsonModel {
    var imgName: String?        // 商品图片
    var title: String?          // 商品标题
    var price: String?          // 商品价格
    var isHidden = true         // 是否隐藏选中按钮
    var isSelect = false        // 是否选中
    
    override func mapping(map: Map) {
        imgName     <- map["imgName"]
        title       <- map["title"]
        price       <- map["price"]
        isHidden    <- map["isHidden"]
        isSelect    <- map["isSelect"]
    }
}
