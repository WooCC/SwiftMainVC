//
//  ProfileMenuModel.swift
//  yinuo
//
//  Created by tim on 2018/3/8.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import ObjectMapper

class ProfileMenuModel: BaseJsonModel {
    
    var title: String?
    var image: String?
    
    override func mapping(map: Map) {
        title <- map["title"]
        image <- map["image"]
    }
}
