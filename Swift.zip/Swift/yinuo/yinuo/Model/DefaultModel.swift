//
//  DefaultModel.swift
//  yinuo
//
//  Created by tim on 2018/3/21.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import ObjectMapper
import Alamofire

class DefaultModel: BaseJsonModel {
    override func mapping(map: Map) {
    }
}
