//
//  HomeMenuModel.swift
//  yinuo
//
//  Created by tim on 2018/3/9.
//  Copyright © 2018年 yinuo. All rights reserved.
//  首页菜单模型

import ObjectMapper

class HomeMenuModel: BaseJsonModel {
    var image: String?        // 菜单图片
    var title: String?        // 标题
    
    override func mapping(map: Map) {
        image     <- map["image"]
        title       <- map["title"]
    }
}
