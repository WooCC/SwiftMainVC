//
//  ReceiptAddressModel.swift
//  yinuo
//
//  Created by 吴承炽 on 2018/3/20.
//  Copyright © 2018年 yinuo. All rights reserved.
//
//["name": "饭饭", "telephone": "13718192844","tag": "公司", "address": "广东省广州市天河区天河东215号", "isDefault": false, "count": 2]
import ObjectMapper

class ReceiptAddressModel: BaseJsonModel {
    //    var alreadyAddShoppingCart: Bool = false        // 是否已经加入购物车
    var name: String?                  // 商品图片名称
    var telephone: String?                  // 商品标题
    var tag: String?                   // 商品描述
    var address: String?                  // 商品购买个数,默认0
//    var price: Double = 0                // 销售价
//    var marketPrice: Double = 0          // 市场价
//    var love: Double = 0                 // 爱心数量
    var isDefault: Bool = false          // 是否选中，默认没有选中
    
    override func mapping(map: Map) {
        name       <- map["name"]
        telephone       <- map["telephone"]
        tag        <- map["tag"]
        address       <- map["address"]
//        price       <- map["price"]
//        marketPrice <- map["marketPrice"]
//        love        <- map["love"]
        isDefault    <- map["isDefault"]
    }
}

