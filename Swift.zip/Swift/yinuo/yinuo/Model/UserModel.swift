//
//  UserModel.swift
//  yinuo
//
//  Created by Tim on 2018/1/28.
//  Copyright © 2018年 yinuo. All rights reserved.
//  用户数据模型

//import Foundation
import ObjectMapper
import Alamofire

class UserModel: BaseJsonModel {
    var id: Int = 0                 // 用户ID
    var userPhone: String?          // 用户手机
    var username: String?           // 用户名
    var avatar: String?             // 头像
    var level: String?              // 等级
    var maxLoveNum: Double = 0      // 最大爱心数
    var created: String?            // 注册时间
    
    override func mapping(map: Map) {
        id              <- map["id"]
        userPhone       <- map["userPhone"]
        username        <- map["username"]
        avatar          <- map["avatar"]
        level           <- map["level"]
        maxLoveNum      <- map["maxLoveNum"]
        created         <- map["created"]
    }
}
