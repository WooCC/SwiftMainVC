//
//  GoodsCartModel.swift
//  yinuo
//
//  Created by tim on 2018/3/6.
//  Copyright © 2018年 yinuo. All rights reserved.
//  商品模型

import ObjectMapper

class GoodsCartModel: BaseJsonModel {
//    var alreadyAddShoppingCart: Bool = false        // 是否已经加入购物车
    var image: String?                  // 商品图片名称
    var title: String?                  // 商品标题
    var desc: String?                   // 商品描述
    var count: Int = 1                  // 商品购买个数,默认0
    var price: Double = 0                // 销售价
    var marketPrice: Double = 0          // 市场价
    var love: Double = 0                 // 爱心数量
    var isSelect: Bool = false          // 是否选中，默认没有选中
    
    override func mapping(map: Map) {
        image       <- map["image"]
        title       <- map["title"]
        desc        <- map["desc"]
        count       <- map["count"]
        price       <- map["price"]
        marketPrice <- map["marketPrice"]
        love        <- map["love"]
        isSelect    <- map["isSelect"]
    }
}
