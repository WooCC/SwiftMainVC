//
//  ResultModel.swift
//  yinuo
//
//  Created by 谭锦添 on 2018/2/5.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import ObjectMapper
import Alamofire

class ResultModel<T: Mappable>: BaseJsonModel {
    var code: Int = 0
    var errorMsg: String?
    var data: T?
    
    override func mapping(map: Map) {
        code        <- map["code"]
        errorMsg    <- map["errorMsg"]
        data        <- map["data"]
    }
}
