//
//  BaseModel.swift
//  yinuo
//
//  Created by Tim on 2018/1/28.
//  Copyright © 2018年 yinuo. All rights reserved.
//  json模型基类

import ObjectMapper

class BaseJsonModel: Mappable {
    
    required init?(map: Map) {
        
    }
    func mapping(map: Map) {
        
    }
}
