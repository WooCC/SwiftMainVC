//
//  Reusable.swift
//  yinuo
//
//  Created by Tim on 2018/1/26.
//  Copyright © 2018年 yinuo. All rights reserved.
//  UITableView UICollectionView 标志位相关文件

import UIKit

protocol Reusable: class {
    
    static var yinuo_reuseIdentifier: String { get }
}

extension UITableViewCell: Reusable {
    
    static var yinuo_reuseIdentifier: String {
        return String(describing: self)
    }
}

extension UITableViewHeaderFooterView: Reusable {
    
    static var yinuo_reuseIdentifier: String {
        return String(describing: self)
    }
}

extension UICollectionReusableView: Reusable {
    
    static var yinuo_reuseIdentifier: String {
        return String(describing: self)
    }
}
