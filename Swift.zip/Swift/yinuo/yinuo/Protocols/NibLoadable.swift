//
//  NibLoadable.swift
//  yinuo
//
//  Created by Tim on 2018/1/26.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit

protocol NibLoadable {
    
    static var yinuo_nibName: String { get }
}

extension UITableViewCell: NibLoadable {
    
    static var yinuo_nibName: String {
        return String(describing: self)
    }
}

extension UICollectionReusableView: NibLoadable {
    
    static var yinuo_nibName: String {
        return String(describing: self)
    }
}
