//
//  AppDelegate.swift
//  yinuo
//
//  Created by Tim on 2018/1/10.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit
import IQKeyboardManagerSwift
//import Fabric
//import Crashlytics

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    var window: UIWindow?
    
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        //创建Window
        window = UIWindow(frame: UIScreen.main.bounds)
        
        // 版本号判断
        let currentVersion = Bundle.releaseVersionNumber
        let lastVersion = YiNuoSettings.sharedInstance["APPVersion"]
        if currentVersion == lastVersion {
            window?.rootViewController = YiNuoTabBarController()
        }else {
            window?.rootViewController = NewFeatureVC()
            YiNuoSettings.sharedInstance["APPVersion"] = currentVersion
        }
        window?.makeKeyAndVisible()
        
        // 启动广告
        let adV = LaunchAdV(frame: CGRect(x: 0, y: 0, width: SCREEN_WIDTH, height: SCREEN_HEIGHT))
        window?.addSubview(adV)
        
        
        // IQKeyboard配置
        IQKeyboardManager.sharedManager().enable = true // 总开关
        IQKeyboardManager.sharedManager().shouldResignOnTouchOutside = true // 点击背景收键盘
        IQKeyboardManager.sharedManager().enableAutoToolbar = true // 工具条
        
        // 初始化HUD
        YiNuoHUD.initYiNuoHUD()
        
        /**
         DEBUG 显示FPS
         非DEBUG 统计任何信息
         */
        #if DEBUG
            let fpsLabel = YiNuoFPSLabel(frame: CGRect(x: 15, y: SCREEN_HEIGHT - 80, width: 55, height: 20));
            self.window?.addSubview(fpsLabel);
        #else
            Fabric.with([Crashlytics.self])
        #endif
        
        return true
    }
    
    
}

