//
//  YiNuoAPI+Profile.swift
//  yinuo
//
//  Created by tim on 2018/3/20.
//  Copyright © 2018年 yinuo. All rights reserved.
//  个人中心

import Moya

enum ApiProfile {
    case getConnectionList(page: Int, count: Int, type: Int)
}

extension ApiProfile: YNTargetType {
    
    var path: String {
        switch self {
        case .getConnectionList(_, _, _):
            return "/Connection/connList"
        }
    }
    
}
