//
//  YiNuoAPI+User.swift
//  yinuo
//
//  Created by Tim on 2018/2/2.
//  Copyright © 2018年 yinuo. All rights reserved.
//  登录

import Moya

enum ApiUser {
    case sendCode(type: Int, phone: String)
    case login(phone: String, password: String)
    case checkReg(referrerPhone: String, phone: String, code: String)
    case register(refPhone: String, phone: String, password: String)
    case getUserInfo(phone: String)
}

extension ApiUser: YNTargetType {
    
    // 各个请求的具体路径, path字段会追加至baseURL后面
    var path: String {
        switch self {
        case .sendCode(_, _):
            return "/Code/sendCode"
        case .login(_, _):
            return "/login"
        case .checkReg(_, _, _):
            return "/User/checkReg"
        case .register(refPhone: _, phone: _, password: _):
            return "/User/register"

        case .getUserInfo(phone: _):
            return "/getUserInfo"
        }
    }
    var task: Task {
        switch self {
        case .checkReg(let refPhone, let phone, let code):
            var params: [String : String] = [:]
            params["referrerPhone"] = refPhone == "" ? nil : refPhone
            params["phone"] = phone
            params["code"] = code
            return .requestParameters(parameters: params, encoding: URLEncoding.default)
        case .register(let refPhone, let phone, let password):
            var params: [String : String] = [:]
            params["referrerPhone"] = refPhone == "" ? nil : refPhone
            params["phone"] = phone
            params["pass"] = password
            return .requestParameters(parameters: params, encoding: URLEncoding.default)
        default:
            return .requestPlain
        }
    }
    
}

