//
//  YiNuoAPI+Online.swift
//  yinuo
//
//  Created by Tim on 2018/1/29.
//  Copyright © 2018年 yinuo. All rights reserved.
//  线上模块接口

import Moya

// 定义一个枚举，存放网络请求
enum ApiOnline {
    case getDantangList(String)
    case getNewsList
    case getMoreNews(String)
}

extension ApiOnline: YNTargetType {
    
    // 各个请求的具体路径, path字段会追加至baseURL后面
    var path: String {
        switch self {
        case .getDantangList(let page):
            return "v1/channels/\(page)/items"
        case .getNewsList:
            return "4/news/latest"
        case .getMoreNews(let date):
            return "4/news/before/" + date
            
        }
    }
    
}

