//
//  YiNuoAPI+Code.swift
//  yinuo
//
//  Created by tim on 2018/3/21.
//  Copyright © 2018年 yinuo. All rights reserved.
//  验证码

import Moya

enum ApiCode {
    case sendCode(phone: String, type: Int)
}

extension ApiCode: YNTargetType {
    
    var path: String {
        switch self {
        case .sendCode(_, _):
            return "/Code/sendCode"
        }
    }
    var task: Task {
        switch self {
        case .sendCode(let phone, let type):
            var params: [String : AnyObject] = [:]
            params["phone"] = phone as AnyObject
            params["type"] = type as AnyObject
            return .requestParameters(parameters: params, encoding: URLEncoding.default)
        default:
            return .requestPlain
        }
    }
    
}
