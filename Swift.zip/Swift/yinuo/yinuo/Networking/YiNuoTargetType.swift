//
//  YiNuoTargetType.swift
//  yinuo
//
//  Created by Tim on 2018/1/29.
//  Copyright © 2018年 yinuo. All rights reserved.
//  配置Moya的TargetType

import Moya

// 继承协议
protocol YNTargetType: TargetType {

}

// 请求相关的默认配置
extension YNTargetType {
    
    // 服务器地址
    var baseURL: URL {
//        return URL.init(string: "https://api.yinuoshangcheng.com")!
        return URL.init(string: "http://localhost:8888/yinuo/api.php")!
    }
    
    // 请求类型
    var method: Moya.Method {
        return .get
    }
    
    // 参数编码方式(这里使用URL的默认方式)
    var parameterEncoding: ParameterEncoding {
        return URLEncoding.default
    }
    
    // 做单元测试模拟的数据，只会在单元测试文件中有作用
    var sampleData: Data {
        return Data()
    }
    
    // 请求任务事件 (请求：request 下载：upload 上传：download)
    var task: Task {
        return .requestPlain
    }
    
    // 是否执行Alamofire验证,默认值为false
    var validate: Bool {
        return false
    }
    
    // 请求头
    var headers: [String: String]? {
        return nil;
    }
    
    // Moya插件
    static var networkActivityPlugin: PluginType {
        // 状态栏菊花
        return NetworkActivityPlugin(networkActivityClosure: { (change: NetworkActivityChangeType, target: TargetType) in
            switch change {
            case .began:
                UIApplication.shared.isNetworkActivityIndicatorVisible = true
            case .ended:
                UIApplication.shared.isNetworkActivityIndicatorVisible = false
            }
        })
    }
    
    static func endpointClosure<T:TargetType>(_ target: T) -> Endpoint{
        let defaultEndpoint = MoyaProvider<T>.defaultEndpointMapping(for: target)
        //API请求 默认携带的参数
        let defaultParameters: [String : Any] = ["OS": "iOS"]
        return defaultEndpoint.adding(newHTTPHeaderFields: defaultParameters as! [String : String])
    }
    
    /// 实现此协议的类，将自动获得用该类实例化的 provider 对象
    static var provider: MoyaProvider<Self> {
        return MoyaProvider<Self>(endpointClosure: endpointClosure, plugins: [networkActivityPlugin])
        // 模拟数据，1秒延迟效果
//        return MoyaProvider<Self>(endpointClosure: endpointClosure, stubClosure: MoyaProvider.delayedStub(1), plugins: [networkActivityPlugin])
    }
    
}
