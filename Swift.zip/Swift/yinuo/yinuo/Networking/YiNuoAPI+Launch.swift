//
//  YiNuoAPI+Launch.swift
//  yinuo
//
//  Created by tim on 2018/3/14.
//  Copyright © 2018年 yinuo. All rights reserved.
//  APP启动相关

import Moya

enum ApiLaunch {
    case configure()        // APP请求配置
    case guidePage()        // 引导页
    case appVersion()       // APP版本
}

extension ApiLaunch: YNTargetType {
    
    // 各个请求的具体路径, path字段会追加至baseURL后面
    var path: String {
        switch self {
        case .configure():
            return "/Configure/configure"
        case .guidePage():
            return "/guidePage"
        case .appVersion():
            return "/appVersion"
        }
    }
    
}
