//
//  Error.swift
//  yinuo
//
//  Created by Tim on 2018/2/5.
//  Copyright © 2018年 yinuo. All rights reserved.
//  请求数据错误代号

import Foundation

struct YNError {
    enum Code: Int {
        case urlError                 = 10000           // URL错误
        case networkRequestFailed     = 10001           // 网络请求失败
        case paramError               = 10003           // JSON解析失败
        
    }
    
    let errorCode: Code
}
