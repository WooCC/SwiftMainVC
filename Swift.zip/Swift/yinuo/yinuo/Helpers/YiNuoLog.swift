//
//  YiNuoLog.swift
//  yinuo
//
//  Created by Tim on 2018/1/25.
//  Copyright © 2018年 yinuo. All rights reserved.
//  自定义Log输出

import Foundation

// autoclosure 自动闭包，调用传参时，参数可消除{}
func println(_ item: @autoclosure () -> Any) {
    #if DEBUG
        Swift.print(item())
    #endif
}
