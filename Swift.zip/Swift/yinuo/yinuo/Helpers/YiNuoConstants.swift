//
//  YiNuoConstants.swift
//  yinuo
//
//  Created by Rayco on 2018/1/25.
//  Copyright © 2018年 yinuo. All rights reserved.
//  全局配置

import Foundation

final class YiNuoConstants {
    
    //修改密码类型
    static let TYPE_MODIFY_LOGIN_PASSWORD = 0
    static let TYPE_FORGOT_LOGIN_PASSWORD = 1
    static let TYPE_SET_PAY_PASSWORD = 2
    static let TYPE_MODIFY_PAY_PASSWORD = 3
    static let TYPE_FORGOT_PAY_PASSWORD = 4

    //店铺类型
    static let TYPE_STORE_COMPANY = 0 //企业店铺
    static let TYPE_STORE_PERSONAL = 1 //个人店铺
  
    //扫描类型
    static let TYPE_SCAN_IDCARD = 0 //扫描身份证
    static let TYPE_SCAN_BANKCARD = 1 //扫描银行卡号
    
    //上传图片类型
    static let TYPE_UPLOAD_ZHIZHI = 0 //上传资质
    static let TYPE_UPLOAD_COMPANYCERTIFICATE = 1 //上传营业执照
    
    //店铺审核状态
    static let TYPE_STORE_APPLY_NONE = -1 //无审核状态
    static let TYPE_STORE_APPLY_ING = 0 //审核中
    static let TYPE_STORE_APPLY_FAIL = 1 //审核失败
    static let TYPE_STORE_APPLY_PASS = 2 //审核成功
    
    //短信验证码类型
    static let TYPE_CODE_REG = 1            // 注册
    static let TYPE_CODE_LOGIN = 2          // 登录
    static let TYPE_CODE_PASS_FORGET = 3    // 忘记密码
}
