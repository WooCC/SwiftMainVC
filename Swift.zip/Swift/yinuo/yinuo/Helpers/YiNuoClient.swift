//
//  YiNuoClient.swift
//  yinuo
//
//  Created by Tim on 2018/1/26.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit

class YiNuoClient: NSObject {
    static let sharedInstance = YiNuoClient()
    
//    var centerVC : HomeVC? = nil
//    var centerNav : YiNuoNavigationViewController? = nil
//    
//    // 当前程序中，最上层的 NavigationController
//    var topNavigationController : UINavigationController {
//        get{
//            return YiNuoClient.getTopNavigationController(YiNuoClient.sharedInstance.centerNav!)
//        }
//    }
//    
//    // 获得最上层NavigationController
//    fileprivate class func getTopNavigationController(_ currentNavigationController:UINavigationController) -> UINavigationController {
//        
//        if let topNav = currentNavigationController.visibleViewController?.navigationController {
//            if topNav != currentNavigationController && topNav.isKind(of: UINavigationController.self){
//                return getTopNavigationController(topNav)
//            }
//        }
//        
//        return currentNavigationController
//    }
}
