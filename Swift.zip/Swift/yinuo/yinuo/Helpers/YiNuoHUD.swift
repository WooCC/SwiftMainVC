//
//  YiNuoHUD.swift
//  yinuo
//
//  Created by Tim on 2018/1/25.
//  Copyright © 2018年 yinuo. All rights reserved.
//  自定义弹框

import Foundation
import SVProgressHUD

open class YiNuoHUD: NSObject {
    
    
    class func initYiNuoHUD() {
        SVProgressHUD.setForegroundColor(UIColor(white: 1, alpha: 1))
        SVProgressHUD.setBackgroundColor(UIColor(white: 0.15, alpha: 0.85))
        SVProgressHUD.setFont(UIFont.systemFont(ofSize: 14.0))
        SVProgressHUD.setDefaultMaskType(.none)
        SVProgressHUD.setMinimumDismissTimeInterval(1.5)
    }
    
    open class func show() {
        SVProgressHUD.show()
        SVProgressHUD.setDefaultMaskType(.none)
    }
    
    open class func showWithClearMask() {
        SVProgressHUD.show()
        SVProgressHUD.setDefaultMaskType(.clear)
    }
    
    open class func dismiss() {
        SVProgressHUD.dismiss()
    }
    
    open class func showWithStatus(_ status:String!) {
        SVProgressHUD.show(withStatus: status)
    }
    
    open class func success(_ status:String!) {
        SVProgressHUD.showSuccess(withStatus: status)
    }
    
    open class func error(_ status:String!) {
        SVProgressHUD.showError(withStatus: status)
    }
    
    open class func inform(_ status:String!) {
        SVProgressHUD.showInfo(withStatus: status)
        SVProgressHUD.displayDuration(for: status)
    }
}


public func YiNuoSuccess(_ status:String!) {
    YiNuoHUD.success(status)
}

public func YiNuoError(_ status:String!) {
    YiNuoHUD.error(status)
}

public func YiNuoInform(_ status:String!) {
    YiNuoHUD.inform(status)
}

public func YiNuoBeginLoading() {
    YiNuoHUD.show()
}

public func YiNuoBeginLoadingWithStatus(_ status:String!) {
    YiNuoHUD.showWithStatus(status)
}

public func YiNuoEndLoading() {
    YiNuoHUD.dismiss()
}
