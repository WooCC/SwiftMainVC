//
//  YiNuoResponse.swift
//  yinuo
//
//  Created by Tim on 2018/1/28.
//  Copyright © 2018年 yinuo. All rights reserved.
//

class YiNuoResponse: NSObject {
    var success: Bool = false
    var message: String = "No message"
    
    init(success: Bool) {
        super.init()
        self.success = success
    }
    
    init(success: Bool, message: String?) {
        super.init()
        self.success = success
        if let message = message{
            self.message = message
        }
    }
}

class YiNuoValueResponse<T>: YiNuoResponse {
    var value:T?
    
    override init(success: Bool) {
        super.init(success: success)
    }
    
    override init(success: Bool, message: String?) {
        super.init(success: success)
        if let message = message {
            self.message = message
        }
    }
    // 便利构造函数
    convenience init(value: T, success: Bool) {
        self.init(success: success)
        self.value = value
    }
    // 便利构造函数
    convenience init(value: T, success: Bool, message: String?) {
        self.init(value: value, success: success)
        if let message = message {
            self.message = message
        }
    }
}
