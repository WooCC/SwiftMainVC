//
//  YiNuoHelpers.swift
//  yinuo
//
//  Created by Tim on 2018/1/26.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import Foundation
import DeviceKit

//屏幕宽度
let SCREEN_WIDTH = UIScreen.main.bounds.size.width;

//屏幕高度
let SCREEN_HEIGHT = UIScreen.main.bounds.size.height;

//屏幕缩放比
let SCREEN_SCALE = UIScreen.main.scale

//NavagationBar高度
let NavigationBarHeight: CGFloat = {
    let device = Device()
    if device.isOneOf([.iPhoneX, Device.simulator(.iPhoneX)]) {
        return 88
    }
    return 64
}()

// Tabbar高度
let TabbarHeight: CGFloat = {
    let device = Device()
    if device.isOneOf([.iPhoneX, Device.simulator(.iPhoneX)]) {
        return 83
    }
    return 49
}()

// 适配iPhone X Tabbar距离底部的距离(如：底部有操作按钮等使用场景)
let TabbarSafeBottomMargin: CGFloat = {
    let device = Device()
    if device.isOneOf([.iPhoneX, Device.simulator(.iPhoneX)]) {
        return 34.0
    }
    return 0.0
}()

// 字体
func yinuoFont(_ fontSize: CGFloat) -> UIFont {
    return UIFont.systemFont(ofSize: fontSize);
}

//用户代理，使用这个切换是获取 m站点 还是www站数据
let USER_AGENT = "Mozilla/5.0 (iPhone; CPU iPhone OS 8_0 like Mac OS X) AppleWebKit/600.1.3 (KHTML, like Gecko) Version/8.0 Mobile/12A4345d Safari/600.1.4";
let MOBILE_CLIENT_HEADERS = ["user-agent":USER_AGENT]
//站点地址,客户端只有https,禁用http
let YINUOURL = "https://www.yinuoshangcheng.com/"
