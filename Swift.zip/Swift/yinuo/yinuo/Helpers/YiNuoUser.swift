//
//  YiNuoUser.swift
//  yinuo
//
//  Created by Tim on 2018/1/28.
//  Copyright © 2018年 yinuo. All rights reserved.
//

import UIKit
import Alamofire

let kUserPhone = "me.fin.userphone"

class YiNuoUser: NSObject {
    static let sharedInstance = YiNuoUser()
    
    @objc dynamic var userPhone: String?            // 用户帐号
    @objc dynamic var notificationCount: Int = 0    // 通知数
    private var _user: UserModel?               // 用户模型
    var user: UserModel? {
        get {
            return self._user
        }
        set {
            //保证给user赋值是在主线程进行的
            //原因是 有很多UI可能会监听这个属性，这个属性发生更改时，那些UI也会相应的修改自己，所以要在主线程操作
//            DispatchQueue.main.sync {
                self._user = newValue
                self.userPhone = newValue?.userPhone
//            }
        }
    }
    
    
    
    // MARK:- 系统回调函数
    private override init() {
        super.init()
//        DispatchQueue.main.sync {
            self.setup()
            //如果客户端是登录状态，则去验证一下登录有没有过期
            if self.isLogin {
                self.verifyLoginStatus()
            }
//        }
    }
    func setup(){
        self.userPhone = YiNuoSettings.sharedInstance[kUserPhone]
    }
    var isLogin: Bool {
        get {
            if let len = self.userPhone?.count , len > 0 {
                return true
            }else {
                return false
            }
        }
    }
    
    /// 确保登录
    func ensureLoginWithHandler(_ handler:()->()) {
        guard isLogin else {
            YiNuoInform("请先登录")
            return;
        }
        handler()
    }
    
    /// 退出登录
    func loginOut() {
        self.user = nil
        self.userPhone = nil
        self.notificationCount = 0
        YiNuoSettings.sharedInstance[kUserPhone] = nil
    }
    
    /**
     验证客户端登录状态
     - returns: ture: 正常登录 ,false: 登录过期，没登录
     */
    func verifyLoginStatus() {
        Alamofire.request(YINUOURL + "new",  headers: MOBILE_CLIENT_HEADERS).responseString(encoding: nil) { (response) -> Void in
            if response.request?.url?.absoluteString == response.response?.url?.absoluteString {
                //登录正常
            }else {
                //没有登录 ,注销客户端
                DispatchQueue.main.sync(execute: {
                    self.loginOut()
                })
            }
        }
    }
}
