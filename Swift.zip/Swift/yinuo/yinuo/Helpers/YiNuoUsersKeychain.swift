//
//  YiNuoUsersKeychain.swift
//  yinuo
//
//  Created by Tim on 2018/1/27.
//  Copyright © 2018年 yinuo. All rights reserved.
//  keychain保存多个用户个人信息(单例)

import UIKit
import KeychainSwift

class YiNuoUsersKeychain {
    
    static let sharedInstance = YiNuoUsersKeychain()
    fileprivate let keychain = KeychainSwift()
    fileprivate(set) var users:[String: LocalSecurityAccountModel] = [:]
    
    fileprivate init() {
        let _ = loadUsersDict()
    }
    
    // 保存用户信息
    func addUser(_ username: String, password: String, avata: String? = nil) {
        let user = LocalSecurityAccountModel()
        user.username = username
        user.password = password
        user.avatar = avata
        self.addUser(user)
    }
    func addUser(_ user: LocalSecurityAccountModel){
        if let username = user.username , let _ = user.password {
            self.users[username] = user
            self.saveUsersDict()
        }else {
            // 断言nil
            assert(false, "username & password must not be 'nil'")
        }
    }
    static let usersKey = "me.fin.testDict"
    func saveUsersDict(){
        let data = NSMutableData()
        // 归档自定义对象
        let archiver = NSKeyedArchiver(forWritingWith: data)
        archiver.encode(self.users)
        archiver.finishEncoding()
        // 保存到keychain
        keychain.set(data as Data, forKey: YiNuoUsersKeychain.usersKey);
    }
    
    // 读取所有用户信息
    func loadUsersDict() -> [String: LocalSecurityAccountModel]{
        if users.count <= 0 {
            // keychain获取用户数据
            let data = keychain.getData(YiNuoUsersKeychain.usersKey)
            if let data = data{
                // 解归档自定义对象
                let archiver = NSKeyedUnarchiver(forReadingWith: data)
                let usersDict = archiver.decodeObject()
                archiver.finishDecoding()
                
                if let usersDict = usersDict as? [String : LocalSecurityAccountModel] {
                    self.users = usersDict
                }
            }
        }
        return self.users
    }
    
    // 删除指定用户
    func removeUser(_ username:String){
        self.users.removeValue(forKey: username)
        self.saveUsersDict()
    }
    // 删除所有用户
    func removeAll(){
        self.users = [:]
        self.saveUsersDict()
    }
    // 修改用户信息
    func update(_ username:String,password:String? = nil,avatar:String? = nil){
        if let user = self.users[username] {
            if let password = password {
                user.password = password
            }
            if let avatar = avatar {
                user.avatar = avatar
            }
            self.saveUsersDict()
        }
    }
    
}


/// 序列化后保存进keychain中的 账户model
class LocalSecurityAccountModel: NSObject, NSCoding {
    
    var username:String?
    var password:String?
    var avatar:String?
    
    override init(){
    
    }
    
    // 取出数据
    required init?(coder aDecoder: NSCoder){
        self.username = aDecoder.decodeObject(forKey: "username") as? String
        self.password = aDecoder.decodeObject(forKey: "password") as? String
        self.avatar = aDecoder.decodeObject(forKey: "avatar") as? String
    }
    
    // 存储数据
    func encode(with aCoder: NSCoder){
        aCoder.encode(self.username, forKey: "username")
        aCoder.encode(self.password, forKey: "password")
        aCoder.encode(self.avatar, forKey: "avatar")
    }
}
