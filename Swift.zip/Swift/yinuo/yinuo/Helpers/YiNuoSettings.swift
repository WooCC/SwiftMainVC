//
//  YiNuoSettings.swift
//  yinuo
//
//  Created by Tim on 2018/1/27.
//  Copyright © 2018年 yinuo. All rights reserved.
//  UserDefaults单例
//  保存一些轻量数据，如：手机号、版本号等

import UIKit

let keyPrefix =  "YiNuoSettings."

class YiNuoSettings: NSObject {
    
    static let sharedInstance = YiNuoSettings()
    
    private override init(){
        super.init()
    }
    
    // 自定义下标
    subscript(key:String) -> String? {
        get {
            return UserDefaults.standard.object(forKey: keyPrefix + key) as? String
        }
        set {
            UserDefaults.standard.setValue(newValue, forKey: keyPrefix + key )
        }
    }
}
