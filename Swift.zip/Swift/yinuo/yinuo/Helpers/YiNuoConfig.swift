//
//  YiNuoConfig.swift
//  yinuo
//
//  Created by Tim on 2018/1/25.
//  Copyright © 2018年 yinuo. All rights reserved.
//  全局配置

import Foundation

final class YiNuoConfig {
    
//    static let apiURL = "https://api.yinuoshangcheng.com"
    static let apiURL = "http://localhost:8888/yinuo"
    static let appURL = "itms-apps://itunes.apple.com/app/id" + "xxxxx"
    
    struct Notification {
        static let OAuthResult = "YiNuoConfig.Notification.OAuthResult"
        static let createdFeed = "YiNuoConfig.Notification.createdFeed"
        static let deletedFeed = "YiNuoConfig.Notification.deletedFeed"
        static let switchedToOthersFromContactsTab = "YiNuoConfig.Notification.switchedToOthersFromContactsTab"
        static let blockedFeedsByCreator = "YiNuoConfig.Notification.blockedFeedsByCreator"
    }
    
    // 屏幕大小
    class func getScreenRect() -> CGRect {
        return UIScreen.main.bounds
    }
    
    // 验证码长度
    class func verifyCodeLength() -> Int {
        return 4
    }
    
    // 密码最短长度
    class func verifyPasswordMinLength() -> Int {
        return 6
    }
    
    // 密码最短长度
    class func verifyPasswordMaxLength() -> Int {
        return 18
    }
    
    // 发送验证码按钮等待时间
    class func callMeInSeconds() -> Int {
        return 10
    }
    
    // 启动广告等待时间
    class func launchAdInSeconds() -> Int {
        return 3
    }
    
    // 头像最大尺寸
    class func avatarMaxSize() -> CGSize {
        return CGSize(width: 414, height: 414)
    }
    
    // "登录"流程相关配置参数
    struct Login {
        static let leftInset: CGFloat = 38.0       // 输入框内左边距
        static let rightInset: CGFloat = 150.0     // 输入框内右边距
    }
    
    // "首页"相关配置参数
    struct Home {
        static let sliderH: CGFloat = 135           // 轮播高度
        static let menuH: CGFloat = 185             // 菜单高度
        static let shopH: CGFloat = 135             // 口碑好店内容高度
        static let shopTitleH: CGFloat = 22         // 口碑好店标题高度
        static let shopTitleL: CGFloat = 12         // 口碑好店标题左边距
    }
    
    // "个人中心"相关配置参数
    struct Profile {
        static let titlesViewH: CGFloat = 40    //"我的收藏"中Tab标题高度
    }
}

